// ══════════════════════════════════════════════════════════════
// ══════ CALL SERVER — WebRTC Signaling + Chat Pribadi ══════
// ══════════════════════════════════════════════════════════════
// File ini di-mount dari index.js:
//   mountCallServer({ app, io, activeKeys, loadDatabase })
// Bertugas handle:
//   - Chat pribadi antar user (relay via Socket.IO)
//   - WebRTC signaling (offer / answer / ICE / end / reject)
// ══════════════════════════════════════════════════════════════

const { Server } = require('socket.io');

// Map: username → Set<socketId>
const onlineUsers = new Map();

function mountCallServer({ app, io, activeKeys, loadDatabase }) {
  // Namespace khusus /call — biar ga nabrak namespace default
  const callNs = io.of('/call');

  // ══════ MIDDLEWARE: AUTH SESSION KEY ══════
  callNs.use((socket, next) => {
    const { key } = socket.handshake.auth || {};
    const info = activeKeys[key];

    if (!info) {
      console.warn(`[CALL] Auth failed — invalid key`);
      return next(new Error('Invalid session key'));
    }

    socket.username = info.username;
    socket.sessionKey = key;
    next();
  });

  // ══════ CONNECTION HANDLER ══════
  callNs.on('connection', (socket) => {
    const username = socket.username;

    // Tambahin ke online list
    if (!onlineUsers.has(username)) onlineUsers.set(username, new Set());
    onlineUsers.get(username).add(socket.id);

    console.log(`[CALL] ✅ ${username} connected (${socket.id})`);

    // Broadcast user online ke semua client
    callNs.emit('user_online', { username });

    // Kirim daftar user yang lagi online
    socket.emit('online_list', {
      users: Array.from(onlineUsers.keys()),
    });

    // ══════════════════════════════════════════════════
    // 📩 CHAT PRIBADI
    // ══════════════════════════════════════════════════
    socket.on('private_message', (data) => {
      const { to, message, type } = data || {};
      if (!to || !message) return;

      const payload = {
        id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        from: username,
        to,
        message: String(message).slice(0, 500),
        type: type || 'text',
        timestamp: new Date().toISOString(),
      };

      // Echo balik ke pengirim
      socket.emit('private_message', { ...payload, fromMe: true });

      // Kirim ke penerima kalo online
      const receiverSockets = onlineUsers.get(to);
      if (receiverSockets && receiverSockets.size > 0) {
        receiverSockets.forEach((sid) => {
          callNs.to(sid).emit('private_message', { ...payload, fromMe: false });
        });
      }
    });

    // ══════════════════════════════════════════════════
    // 📞 WEBRTC SIGNALING
    // ══════════════════════════════════════════════════

    // Caller → kirim offer
    socket.on('call_offer', ({ to, offer, type }) => {
      if (!to || !offer) return;

      const receiverSockets = onlineUsers.get(to);
      if (!receiverSockets || receiverSockets.size === 0) {
        // Penerima offline → kasih tau caller
        return socket.emit('call_unavailable', { to });
      }

      receiverSockets.forEach((sid) => {
        callNs.to(sid).emit('incoming_call', {
          from: username,
          offer,
          type: type || 'audio', // 'audio' | 'video'
        });
      });

      console.log(`[CALL] ${username} → ${to} (${type || 'audio'}) — offer sent`);
    });

    // Callee → kirim answer
    socket.on('call_answer', ({ to, answer }) => {
      if (!to || !answer) return;

      const receiverSockets = onlineUsers.get(to);
      if (!receiverSockets) return;

      receiverSockets.forEach((sid) => {
        callNs.to(sid).emit('call_answered', { from: username, answer });
      });
    });

    // ICE candidate (dua arah)
    socket.on('call_ice', ({ to, candidate }) => {
      if (!to || !candidate) return;

      const receiverSockets = onlineUsers.get(to);
      if (!receiverSockets) return;

      receiverSockets.forEach((sid) => {
        callNs.to(sid).emit('call_ice', { from: username, candidate });
      });
    });

    // End call
    socket.on('call_end', ({ to }) => {
      if (!to) return;

      const receiverSockets = onlineUsers.get(to);
      if (!receiverSockets) return;

      receiverSockets.forEach((sid) => {
        callNs.to(sid).emit('call_ended', { from: username });
      });

      console.log(`[CALL] ${username} ended call with ${to}`);
    });

    // Reject call
    socket.on('call_reject', ({ to }) => {
      if (!to) return;

      const receiverSockets = onlineUsers.get(to);
      if (!receiverSockets) return;

      receiverSockets.forEach((sid) => {
        callNs.to(sid).emit('call_rejected', { from: username });
      });

      console.log(`[CALL] ${username} rejected call from ${to}`);
    });

    // ══════════════════════════════════════════════════
    // 🔌 DISCONNECT
    // ══════════════════════════════════════════════════
    socket.on('disconnect', () => {
      const sockets = onlineUsers.get(username);
      if (sockets) {
        sockets.delete(socket.id);

        // Kalo user udah ga punya socket aktif, hapus dari list
        if (sockets.size === 0) {
          onlineUsers.delete(username);
          callNs.emit('user_offline', { username });
        }
      }
      console.log(`[CALL] ❌ ${username} disconnected (${socket.id})`);
    });
  });

  console.log('[CALL] Namespace /call terpasang ✅');
}

module.exports = { mountCallServer };