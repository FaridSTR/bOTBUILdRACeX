// chat_server.js
// ═══════════════════════════════════════════════════════════
//  CHAT SERVER — Group, Private, Status
//  Mount ke Express app dari index.js
// ═══════════════════════════════════════════════════════════

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ─── File database ────────────────────────────────────────
const CHAT_DIR = path.join(__dirname, 'chat_data');
const GROUP_CHAT_FILE = path.join(CHAT_DIR, 'group_chat.json');
const PRIVATE_CHAT_FILE = path.join(CHAT_DIR, 'private_chat.json');
const STATUS_FILE = path.join(CHAT_DIR, 'status.json');
const BLOCKED_FILE = path.join(CHAT_DIR, 'blocked.json');
const MEDIA_DIR = path.join(CHAT_DIR, 'media');

// Buat folder kalo belum ada
if (!fs.existsSync(CHAT_DIR)) fs.mkdirSync(CHAT_DIR, { recursive: true });
if (!fs.existsSync(MEDIA_DIR)) fs.mkdirSync(MEDIA_DIR, { recursive: true });

// ─── Helper: Load/save JSON ───────────────────────────────
function loadJson(file, def = []) {
  try {
    if (!fs.existsSync(file)) return def;
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch { return def; }
}

function saveJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// ─── Helper: Sanitize ─────────────────────────────────────
function sanitize(str, max = 2000) {
  return String(str || '').replace(/[<>]/g, '').slice(0, max);
}

// ─── Helper: Gen ID ───────────────────────────────────────
let _lastId = Date.now();
function genId() { return ++_lastId; }

// ─── Helper: Auto-clean status > 24 jam ───────────────────
function cleanOldStatus() {
  const cutoff = Date.now() - 24 * 60 * 60 * 1000;
  const statuses = loadJson(STATUS_FILE, []);
  const filtered = statuses.filter(s => (s.timestamp || 0) > cutoff);
  if (filtered.length !== statuses.length) saveJson(STATUS_FILE, filtered);
}

// Auto-clean tiap 1 jam
setInterval(cleanOldStatus, 60 * 60 * 1000);

// ═══════════════════════════════════════════════════════════
//  MAIN EXPORT
// ═══════════════════════════════════════════════════════════
module.exports = function mountChat(app) {
  const express = require('express');

  // ─── Helper: Validasi session key ───────────────────────
  // Dapet activeKeys dari index.js (global scope)
  function getUserByKey(key) {
    if (typeof global.activeKeys === 'undefined') return null;
    const info = global.activeKeys[key];
    if (!info) return null;

    // Baca database user
    const dbPath = path.join(__dirname, 'database.json');
    try {
      const db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
      const user = db.find(u => u.username === info.username);
      return user ? { username: user.username, role: user.role || 'member' } : null;
    } catch { return null; }
  }

  // ─── Body parser untuk base64 besar ─────────────────────
  app.use('/groupchat', express.json({ limit: '30mb' }));
  app.use('/private', express.json({ limit: '30mb' }));
  app.use('/status', express.json({ limit: '30mb' }));

  // ═══════════════════════════════════════════════════════════
  //  GROUP CHAT
  // ═══════════════════════════════════════════════════════════

  // POST /groupchat/sendMessage
  app.post('/groupchat/sendMessage', (req, res) => {
    const { key, room = 'global', message, mediaBase64, mimeType } = req.body || {};
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });

    let mediaUrl = null;
    let type = 'text';

    // Simpan media kalo ada
    if (mediaBase64 && mimeType) {
      try {
        const ext = mimeType.split('/')[1]?.split(';')[0] || 'bin';
        const fileName = `g_${Date.now()}_${crypto.randomBytes(4).toString('hex')}.${ext}`;
        const filePath = path.join(MEDIA_DIR, fileName);
        fs.writeFileSync(filePath, Buffer.from(mediaBase64, 'base64'));
        mediaUrl = `/chat_media/${fileName}`;
        type = mimeType.startsWith('video') ? 'video' : 'image';
      } catch (e) {
        return res.json({ valid: false, error: 'Gagal simpan media' });
      }
    }

    const msg = {
      id: genId(),
      username: user.username,
      room: sanitize(room, 50),
      role: user.role,
      message: sanitize(message, 2000),
      type,
      mimeType: mimeType || null,
      mediaUrl,
      time: new Date().toISOString(),
      edited: false,
      reactions: {}
    };

    if (!msg.message && !msg.mediaUrl) return res.json({ valid: false, error: 'Pesan kosong' });

    const list = loadJson(GROUP_CHAT_FILE, []);
    list.push(msg);
    // Simpan max 2000 pesan terakhir
    if (list.length > 2000) list.splice(0, list.length - 2000);
    saveJson(GROUP_CHAT_FILE, list);

    res.json({ valid: true, data: msg });
  });

  // GET /groupchat/getMessages?key=xxx&room=global&lastId=0
  app.get('/groupchat/getMessages', (req, res) => {
    const { key, room = 'global', lastId = '0' } = req.query;
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });

    const lastIdNum = parseInt(lastId) || 0;
    const list = loadJson(GROUP_CHAT_FILE, []);
    const filtered = list.filter(m => m.room === room && m.id > lastIdNum);

    res.json({ valid: true, data: filtered });
  });

  // POST /groupchat/reactMessage
  app.post('/groupchat/reactMessage', (req, res) => {
    const { key, messageId, emoji } = req.body || {};
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });

    const list = loadJson(GROUP_CHAT_FILE, []);
    const msg = list.find(m => m.id === parseInt(messageId));
    if (!msg) return res.json({ valid: false, error: 'Pesan tidak ditemukan' });

    if (!msg.reactions) msg.reactions = {};
    if (!msg.reactions[emoji]) msg.reactions[emoji] = [];

    const idx = msg.reactions[emoji].indexOf(user.username);
    if (idx >= 0) {
      msg.reactions[emoji].splice(idx, 1);
      if (msg.reactions[emoji].length === 0) delete msg.reactions[emoji];
    } else {
      msg.reactions[emoji].push(user.username);
    }

    saveJson(GROUP_CHAT_FILE, list);
    res.json({ valid: true });
  });

  // POST /groupchat/editMessage
  app.post('/groupchat/editMessage', (req, res) => {
    const { key, messageId, message } = req.body || {};
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });

    const list = loadJson(GROUP_CHAT_FILE, []);
    const msg = list.find(m => m.id === parseInt(messageId));
    if (!msg) return res.json({ valid: false, error: 'Pesan tidak ditemukan' });
    if (msg.username !== user.username) return res.json({ valid: false, error: 'Bukan pesan lu' });

    msg.message = sanitize(message, 2000);
    msg.edited = true;
    saveJson(GROUP_CHAT_FILE, list);
    res.json({ valid: true });
  });

  // ═══════════════════════════════════════════════════════════
  //  PRIVATE CHAT
  // ═══════════════════════════════════════════════════════════

  // GET /private/getConversations?key=xxx
  app.get('/private/getConversations', (req, res) => {
    const { key } = req.query;
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });

    const list = loadJson(PRIVATE_CHAT_FILE, []);
    const myMsgs = list.filter(m => m.from === user.username || m.to === user.username);

    // Group by peer
    const peerMap = {};
    myMsgs.forEach(m => {
      const peer = m.from === user.username ? m.to : m.from;
      if (!peerMap[peer] || new Date(m.time) > new Date(peerMap[peer].lastMessage?.time || 0)) {
        peerMap[peer] = {
          peer,
          lastMessage: {
            message: m.message,
            time: m.time,
            from: m.from
          }
        };
      }
    });

    const convs = Object.values(peerMap).sort((a, b) =>
      new Date(b.lastMessage.time) - new Date(a.lastMessage.time)
    );

    res.json({ valid: true, data: convs });
  });

  // GET /private/getUsers?key=xxx
  app.get('/private/getUsers', (req, res) => {
    const { key } = req.query;
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });

    try {
      const db = JSON.parse(fs.readFileSync(path.join(__dirname, 'database.json'), 'utf8'));
      const users = db
        .filter(u => u.username !== user.username)
        .map(u => ({ username: u.username, role: u.role || 'member' }));
      res.json({ valid: true, data: users });
    } catch {
      res.json({ valid: true, data: [] });
    }
  });

  // GET /private/getMessages?key=xxx&withUser=yyy&lastId=0
  app.get('/private/getMessages', (req, res) => {
    const { key, withUser, lastId = '0' } = req.query;
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });
    if (!withUser) return res.json({ valid: false, error: 'withUser required' });

    const lastIdNum = parseInt(lastId) || 0;
    const list = loadJson(PRIVATE_CHAT_FILE, []);
    const filtered = list.filter(m =>
      ((m.from === user.username && m.to === withUser) ||
        (m.from === withUser && m.to === user.username)) &&
      m.id > lastIdNum
    );

    res.json({ valid: true, data: filtered });
  });

  // POST /private/sendMessage
  app.post('/private/sendMessage', (req, res) => {
    const { key, to, message, mediaBase64, mimeType } = req.body || {};
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });
    if (!to) return res.json({ valid: false, error: 'to required' });

    // Cek blocked
    const blocked = loadJson(BLOCKED_FILE, {});
    if ((blocked[to] || []).includes(user.username)) {
      return res.json({ valid: false, error: 'Kamu diblokir oleh user ini' });
    }

    let mediaUrl = null;
    let type = 'text';
    if (mediaBase64 && mimeType) {
      try {
        const ext = mimeType.split('/')[1]?.split(';')[0] || 'bin';
        const fileName = `p_${Date.now()}_${crypto.randomBytes(4).toString('hex')}.${ext}`;
        const filePath = path.join(MEDIA_DIR, fileName);
        fs.writeFileSync(filePath, Buffer.from(mediaBase64, 'base64'));
        mediaUrl = `/chat_media/${fileName}`;
        type = mimeType.startsWith('video') ? 'video' : 'image';
      } catch {
        return res.json({ valid: false, error: 'Gagal simpan media' });
      }
    }

    const msg = {
      id: genId(),
      from: user.username,
      to,
      message: sanitize(message, 2000),
      type,
      mimeType: mimeType || null,
      mediaUrl,
      time: new Date().toISOString(),
      edited: false,
      reactions: {}
    };

    if (!msg.message && !msg.mediaUrl) return res.json({ valid: false, error: 'Pesan kosong' });

    const list = loadJson(PRIVATE_CHAT_FILE, []);
    list.push(msg);
    if (list.length > 5000) list.splice(0, list.length - 5000);
    saveJson(PRIVATE_CHAT_FILE, list);

    res.json({ valid: true, data: msg });
  });

  // POST /private/reactMessage
  app.post('/private/reactMessage', (req, res) => {
    const { key, messageId, emoji } = req.body || {};
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });

    const list = loadJson(PRIVATE_CHAT_FILE, []);
    const msg = list.find(m => m.id === parseInt(messageId));
    if (!msg) return res.json({ valid: false, error: 'Pesan tidak ditemukan' });

    if (!msg.reactions) msg.reactions = {};
    if (!msg.reactions[emoji]) msg.reactions[emoji] = [];
    const idx = msg.reactions[emoji].indexOf(user.username);
    if (idx >= 0) {
      msg.reactions[emoji].splice(idx, 1);
      if (msg.reactions[emoji].length === 0) delete msg.reactions[emoji];
    } else {
      msg.reactions[emoji].push(user.username);
    }

    saveJson(PRIVATE_CHAT_FILE, list);
    res.json({ valid: true });
  });

  // POST /private/editMessage
  app.post('/private/editMessage', (req, res) => {
    const { key, messageId, message } = req.body || {};
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });

    const list = loadJson(PRIVATE_CHAT_FILE, []);
    const msg = list.find(m => m.id === parseInt(messageId));
    if (!msg) return res.json({ valid: false, error: 'Pesan tidak ditemukan' });
    if (msg.from !== user.username) return res.json({ valid: false, error: 'Bukan pesan lu' });

    msg.message = sanitize(message, 2000);
    msg.edited = true;
    saveJson(PRIVATE_CHAT_FILE, list);
    res.json({ valid: true });
  });

  // POST /private/blockUser
  app.post('/private/blockUser', (req, res) => {
    const { key, target } = req.body || {};
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });

    const blocked = loadJson(BLOCKED_FILE, {});
    if (!blocked[user.username]) blocked[user.username] = [];
    if (!blocked[user.username].includes(target)) blocked[user.username].push(target);
    saveJson(BLOCKED_FILE, blocked);
    res.json({ valid: true });
  });

  // POST /private/unblockUser
  app.post('/private/unblockUser', (req, res) => {
    const { key, target } = req.body || {};
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });

    const blocked = loadJson(BLOCKED_FILE, {});
    if (blocked[user.username]) {
      blocked[user.username] = blocked[user.username].filter(u => u !== target);
    }
    saveJson(BLOCKED_FILE, blocked);
    res.json({ valid: true });
  });

  // GET /private/getBlocked?key=xxx
  app.get('/private/getBlocked', (req, res) => {
    const { key } = req.query;
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });

    const blocked = loadJson(BLOCKED_FILE, {});
    res.json({ valid: true, data: blocked[user.username] || [] });
  });

  // ═══════════════════════════════════════════════════════════
  //  STATUS
  // ═══════════════════════════════════════════════════════════

  // POST /status/post
  app.post('/status/post', (req, res) => {
    const { key, caption, type = 'text', mediaBase64, mimeType } = req.body || {};
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });

    let mediaUrl = null;
    if (mediaBase64 && mimeType && type !== 'text') {
      try {
        const ext = mimeType.split('/')[1]?.split(';')[0] || 'bin';
        const fileName = `s_${Date.now()}_${crypto.randomBytes(4).toString('hex')}.${ext}`;
        const filePath = path.join(MEDIA_DIR, fileName);
        fs.writeFileSync(filePath, Buffer.from(mediaBase64, 'base64'));
        mediaUrl = `/chat_media/${fileName}`;
      } catch {
        return res.json({ valid: false, error: 'Gagal simpan media' });
      }
    }

    const status = {
      id: genId(),
      username: user.username,
      role: user.role,
      type,
      caption: sanitize(caption, 500),
      mediaUrl,
      viewers: [],
      timestamp: Date.now(),
      time: new Date().toISOString()
    };

    if (!status.caption && !status.mediaUrl) return res.json({ valid: false, error: 'Status kosong' });

    const list = loadJson(STATUS_FILE, []);
    list.push(status);
    saveJson(STATUS_FILE, list);

    res.json({ valid: true, data: status });
  });

  // GET /status/getAll?key=xxx
  app.get('/status/getAll', (req, res) => {
    const { key } = req.query;
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });

    cleanOldStatus();
    const list = loadJson(STATUS_FILE, []);

    // Group by username
    const grouped = {};
    list.forEach(s => {
      if (!grouped[s.username]) {
        grouped[s.username] = {
          username: s.username,
          role: s.role,
          items: []
        };
      }
      grouped[s.username].items.push(s);
    });

    res.json({ valid: true, data: Object.values(grouped) });
  });

  // POST /status/view
  app.post('/status/view', (req, res) => {
    const { key, statusId } = req.body || {};
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });

    const list = loadJson(STATUS_FILE, []);
    const status = list.find(s => s.id === parseInt(statusId));
    if (!status) return res.json({ valid: false, error: 'Status tidak ditemukan' });

    if (!status.viewers.includes(user.username)) {
      status.viewers.push(user.username);
      saveJson(STATUS_FILE, list);
    }

    res.json({ valid: true });
  });

  // DELETE /status/delete?key=xxx&statusId=yyy
  app.delete('/status/delete', (req, res) => {
    const { key, statusId } = req.query;
    const user = getUserByKey(key);
    if (!user) return res.json({ valid: false, error: 'Invalid key' });

    let list = loadJson(STATUS_FILE, []);
    const status = list.find(s => s.id === parseInt(statusId));
    if (!status) return res.json({ valid: false, error: 'Status tidak ditemukan' });

    const isOwner = status.username === user.username;
    const isDev = ['developer', 'high owner', 'owner'].includes(user.role);
    if (!isOwner && !isDev) return res.json({ valid: false, error: 'Bukan status lu' });

    // Hapus media kalo ada
    if (status.mediaUrl) {
      const mediaPath = path.join(MEDIA_DIR, path.basename(status.mediaUrl));
      if (fs.existsSync(mediaPath)) fs.unlinkSync(mediaPath);
    }

    list = list.filter(s => s.id !== parseInt(statusId));
    saveJson(STATUS_FILE, list);
    res.json({ valid: true });
  });

  // ─── Serve media statis ─────────────────────────────────
  app.use('/chat_media', express.static(MEDIA_DIR));

  console.log('[CHAT] ✅ Chat server mounted');
};