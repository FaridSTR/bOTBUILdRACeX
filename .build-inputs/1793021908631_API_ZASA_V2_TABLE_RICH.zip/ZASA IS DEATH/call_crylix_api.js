// call_crylix_api.js
// API untuk fitur Call Crylix (chat, voice/video call, group, story)

const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');
const WebSocket = require('ws');

module.exports = function mountCallCrylix({
  app,
  wss,
  wsClients,
  activeKeys,
  loadDatabase,
  saveDatabase,
  sanitize,
  saveChat,
  chatList,
}) {

  // ── Setup folder upload ──
  const BASE_DIR = __dirname;
  const VOICE_DIR = path.join(BASE_DIR, 'uploads', 'cal-voice');
  const STORY_DIR = path.join(BASE_DIR, 'uploads', 'cal-story');
  fs.mkdirSync(VOICE_DIR, { recursive: true });
  fs.mkdirSync(STORY_DIR, { recursive: true });

  const CAL_GROUPS_FILE = path.join(BASE_DIR, 'cal_groups.json');
  const CAL_CONTACTS_FILE = path.join(BASE_DIR, 'cal_contacts.json');
  const CAL_STORIES_FILE = path.join(BASE_DIR, 'cal_stories.json');
  const CAL_GROUP_MESSAGES_FILE = path.join(BASE_DIR, 'cal_group_messages.json');

  function calLoad(file, fallback = []) {
    try {
      return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : fallback;
    } catch (_) { return fallback; }
  }
  function calSave(file, data) {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
  }
  function calUserByKey(key) {
    const info = activeKeys[key];
    if (!info) return null;
    const db = loadDatabase();
    return db.find(u => u.username === info.username) || null;
  }

  // ── Multer setup ──
  const storyUpload = multer({
    storage: multer.diskStorage({
      destination: (_req, _file, cb) => cb(null, STORY_DIR),
      filename: (_req, file, cb) => {
        const ext = path.extname(file.originalname || '') || '.jpg';
        cb(null, `story_${Date.now()}_${crypto.randomBytes(5).toString('hex')}${ext}`);
      }
    }),
    limits: { fileSize: 25 * 1024 * 1024 }
  });

  const voiceUpload = multer({
    storage: multer.diskStorage({
      destination: (_req, _file, cb) => cb(null, VOICE_DIR),
      filename: (_req, file, cb) => {
        const ext = path.extname(file.originalname || '') || '.m4a';
        cb(null, `voice_${Date.now()}_${crypto.randomBytes(5).toString('hex')}${ext}`);
      }
    }),
    limits: { fileSize: 5 * 1024 * 1024 }
  });

  // ── Static serve ──
  app.use('/uploads/cal-voice', express.static(VOICE_DIR));
  app.use('/uploads/cal-story', express.static(STORY_DIR));

  // ── API: User Directory ──
  app.get('/api/cal/users', (req, res) => {
    const keyInfo = activeKeys[req.query.key];
    if (!keyInfo) return res.json({ success: false, message: 'Invalid session key' });
    const db = loadDatabase();
    const me = db.find(u => u.username === keyInfo.username);
    if (!me) return res.json({ success: false, message: 'User not found' });
    const users = db
      .filter(u => u && u.username && u.username !== me.username)
      .map(u => ({ username: u.username, role: u.role || 'member' }));
    res.json({ success: true, users });
  });

  // ── API: Contacts ──
  app.get('/api/cal/contacts', (req, res) => {
    const me = calUserByKey(req.query.key);
    if (!me) return res.status(401).json({ success: false, message: 'Invalid session key' });
    const contacts = calLoad(CAL_CONTACTS_FILE).filter(x => x.owner === me.username);
    res.json({ success: true, contacts });
  });

  app.post('/api/cal/contacts', express.json(), (req, res) => {
    const me = calUserByKey(req.body.key);
    const username = String(req.body.username || '').trim();
    if (!me) return res.status(401).json({ success: false, message: 'Invalid session key' });
    if (!username || username === me.username) return res.status(400).json({ success: false });
    const db = loadDatabase();
    if (!db.some(u => u.username === username)) return res.status(404).json({ success: false });
    const contacts = calLoad(CAL_CONTACTS_FILE);
    if (!contacts.some(x => x.owner === me.username && x.username === username)) {
      contacts.push({ id: `contact_${Date.now()}`, owner: me.username, username, createdAt: Date.now() });
    }
    calSave(CAL_CONTACTS_FILE, contacts);
    res.json({ success: true });
  });

  // ── API: Groups ──
  app.get('/api/cal/groups', (req, res) => {
    const me = calUserByKey(req.query.key);
    if (!me) return res.status(401).json({ success: false });
    const groups = calLoad(CAL_GROUPS_FILE).filter(g => Array.isArray(g.members) && g.members.includes(me.username));
    res.json({ success: true, groups });
  });

  app.post('/api/cal/groups', express.json(), (req, res) => {
    const me = calUserByKey(req.body.key);
    if (!me) return res.status(401).json({ success: false });
    const name = sanitize(req.body.name || '').trim();
    if (!name) return res.status(400).json({ success: false });
    const db = loadDatabase();
    const requested = Array.isArray(req.body.members) ? req.body.members.map(String) : [];
    const members = [...new Set([me.username, ...requested])].filter(u => db.some(x => x.username === u));
    const groups = calLoad(CAL_GROUPS_FILE);
    const group = {
      id: `group_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
      name, owner: me.username, members, admins: [me.username], createdAt: Date.now()
    };
    groups.push(group);
    calSave(CAL_GROUPS_FILE, groups);

    for (const member of members) {
      const ws = wsClients[member];
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'group_created', group }));
      }
    }
    res.json({ success: true, group });
  });

  app.get('/api/cal/groups/:id', (req, res) => {
    const me = calUserByKey(req.query.key);
    if (!me) return res.status(401).json({ success: false });
    const group = calLoad(CAL_GROUPS_FILE).find(g => g.id === req.params.id && g.members.includes(me.username));
    if (!group) return res.status(404).json({ success: false });
    res.json({ success: true, group });
  });

  app.get('/api/cal/groups/:id/messages', (req, res) => {
    const me = calUserByKey(req.query.key);
    if (!me) return res.status(401).json({ success: false });
    const groups = calLoad(CAL_GROUPS_FILE);
    const g = groups.find(x => x.id === req.params.id && x.members.includes(me.username));
    if (!g) return res.status(404).json({ success: false });
    const all = calLoad(CAL_GROUP_MESSAGES_FILE);
    res.json({ success: true, messages: all.filter(x => x.groupId === g.id).slice(-200) });
  });

  app.post('/api/cal/groups/:id/members', express.json(), (req, res) => {
    const me = calUserByKey(req.body.key);
    if (!me) return res.status(401).json({ success: false });
    const groups = calLoad(CAL_GROUPS_FILE);
    const idx = groups.findIndex(g => g.id === req.params.id);
    if (idx < 0) return res.status(404).json({ success: false });
    const g = groups[idx];
    if (!g.members.includes(me.username) || !g.admins.includes(me.username)) {
      return res.status(403).json({ success: false, message: 'Admin only' });
    }
    const db = loadDatabase();
    const add = String(req.body.username || '').trim();
    if (!db.some(u => u.username === add)) return res.status(404).json({ success: false });
    if (!g.members.includes(add)) g.members.push(add);
    calSave(CAL_GROUPS_FILE, groups);
    res.json({ success: true, group: g });
  });

  app.post('/api/cal/groups/:id/rename', express.json(), (req, res) => {
    const me = calUserByKey(req.body.key);
    if (!me) return res.status(401).json({ success: false });
    const groups = calLoad(CAL_GROUPS_FILE);
    const g = groups.find(x => x.id === req.params.id);
    if (!g || !g.members.includes(me.username)) return res.status(404).json({ success: false });
    if (!g.admins.includes(me.username)) return res.status(403).json({ success: false });
    g.name = sanitize(req.body.name || '').trim().slice(0, 60);
    if (!g.name) return res.status(400).json({ success: false });
    calSave(CAL_GROUPS_FILE, groups);
    res.json({ success: true, group: g });
  });

  // ── API: Stories ──
  app.get('/api/cal/stories', (req, res) => {
    const me = calUserByKey(req.query.key);
    if (!me) return res.status(401).json({ success: false });
    const now = Date.now();
    const stories = calLoad(CAL_STORIES_FILE).filter(s => s.expiredAt > now);
    const grouped = {};
    for (const s of stories) {
      if (!grouped[s.username]) grouped[s.username] = { username: s.username, stories: [] };
      grouped[s.username].stories.push({
        ...s,
        isSeen: s.viewers.includes(me.username) || s.username === me.username
      });
    }
    res.json({ success: true, users: Object.values(grouped) });
  });

  app.post('/api/cal/stories', storyUpload.single('media'), (req, res) => {
    const me = calUserByKey(req.body.key);
    if (!me) return res.status(401).json({ success: false });
    if (!req.file) return res.status(400).json({ success: false, message: 'Media required' });
    const stories = calLoad(CAL_STORIES_FILE);
    const story = {
      id: `calstory_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
      username: me.username,
      mediaUrl: `/uploads/cal-story/${req.file.filename}`,
      mediaType: req.file.mimetype.startsWith('video/') ? 'video' : 'image',
      caption: sanitize(req.body.caption || '').slice(0, 120),
      createdAt: Date.now(),
      expiredAt: Date.now() + 86400000,
      viewers: []
    };
    stories.push(story);
    calSave(CAL_STORIES_FILE, stories);

    for (const client of Object.values(wsClients)) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({ type: 'cal_story_created', story }));
      }
    }
    res.json({ success: true, story });
  });

  app.post('/api/cal/stories/view', express.json(), (req, res) => {
    const me = calUserByKey(req.body.key);
    if (!me) return res.status(401).json({ success: false });
    const stories = calLoad(CAL_STORIES_FILE);
    const s = stories.find(x => x.id === req.body.storyId);
    if (!s) return res.status(404).json({ success: false });
    if (s.username !== me.username && !s.viewers.includes(me.username)) {
      s.viewers.push(me.username);
      calSave(CAL_STORIES_FILE, stories);
    }
    res.json({ success: true });
  });

  setInterval(() => {
    const now = Date.now();
    const stories = calLoad(CAL_STORIES_FILE);
    const keep = stories.filter(s => s.expiredAt > now);
    if (keep.length !== stories.length) calSave(CAL_STORIES_FILE, keep);
  }, 5 * 60 * 1000);

  // ── API: Voice Note ──
  app.post('/api/cal/voice', voiceUpload.single('audio'), (req, res) => {
    const keyInfo = activeKeys[req.body.key];
    const to = String(req.body.to || '').trim();
    if (!keyInfo) return res.status(401).json({ success: false });
    if (!req.file || !to) return res.status(400).json({ success: false });
    const db = loadDatabase();
    const me = db.find(u => u.username === keyInfo.username);
    const target = db.find(u => u.username === to);
    if (!me || !target) {
      try { fs.unlinkSync(req.file.path); } catch (_) {}
      return res.status(404).json({ success: false });
    }
    const voiceUrl = `${req.protocol}://${req.get('host')}/uploads/cal-voice/${encodeURIComponent(req.file.filename)}`;
    const message = {
      id: `voice-${me.username}-${Date.now()}`,
      from: me.username, to, voiceUrl,
      time: new Date().toISOString()
    };
    chatList.push(message);
    saveChat();

    const receiver = wsClients[to];
    if (receiver && receiver.readyState === WebSocket.OPEN) {
      receiver.send(JSON.stringify({ type: 'voice_message', message }));
    }
    res.json({ success: true, data: message });
  });

  // ── WS: WebRTC Signaling + Group Chat ──
  wss.on('connection', function (ws) {
    let username = null;

    ws.on('message', function (msg) {
      try {
        const data = JSON.parse(msg);

        if (data.type === 'auth') {
          username = activeKeys[data.key]?.username || null;
          return;
        }

        // ── WebRTC Signaling (Voice/Video/Group Call) ──
        if (['call_invite', 'video_call_invite', 'call_accept', 'call_reject',
             'call_offer', 'call_answer', 'call_ice', 'call_end'].includes(data.type)) {
          const to = String(data.to || '').trim();
          if (!username || !to || !wsClients[to]) return;

          const allowed = new Set([
            'call_invite', 'video_call_invite', 'call_accept', 'call_reject',
            'call_offer', 'call_answer', 'call_ice', 'call_end'
          ]);
          const payload = { ...data, from: username };
          for (const k of Object.keys(payload)) {
            if (!allowed.has(data.type) && k !== 'type') delete payload[k];
          }
          if (data.type === 'call_offer' || data.type === 'call_answer') {
            if (typeof payload.sdp !== 'string' || payload.sdp.length > 20000) return;
          }
          if (data.type === 'call_ice' && JSON.stringify(payload.candidate || {}).length > 5000) return;
          wsClients[to].send(JSON.stringify(payload));
          return;
        }

        // ── Group Chat + Group Call Signaling ──
        if (data.type === 'group_chat' ||
            ['group_call_invite', 'group_call_join', 'group_call_offer',
             'group_call_answer', 'group_call_ice', 'group_call_leave'].includes(data.type)) {
          const groups = calLoad(CAL_GROUPS_FILE);
          const group = groups.find(g =>
            g.id === String(data.groupId || '') &&
            Array.isArray(g.members) && g.members.includes(username)
          );
          if (!group) return;

          const base = { ...data, from: username };

          if (data.type === 'group_chat') {
            const message = sanitize(data.message || '').slice(0, 1000);
            if (!message) return;
            base.message = {
              id: `gmsg_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
              from: username, message, time: new Date().toISOString()
            };
            const groupMessages = calLoad(CAL_GROUP_MESSAGES_FILE);
            groupMessages.push({ ...base.message, groupId: group.id });
            calSave(CAL_GROUP_MESSAGES_FILE, groupMessages.slice(-5000));
          }

          for (const member of group.members) {
            if (member === username) continue;
            const client = wsClients[member];
            if (client && client.readyState === WebSocket.OPEN) {
              if (['group_call_offer', 'group_call_answer', 'group_call_ice'].includes(data.type)) {
                if (data.to && String(data.to) !== member) continue;
              }
              client.send(JSON.stringify(base));
            }
          }
          return;
        }

      } catch (e) {
        console.error('[CallCrylix WS]', e.message);
      }
    });
  });

  console.log('📞 Call Crylix API mounted: chat, voice/video/group call, story');
};